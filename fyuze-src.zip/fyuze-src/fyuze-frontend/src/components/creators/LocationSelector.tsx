import React, { useState, useEffect } from "react";
import { ChevronDown, MapPin, CheckCircle, Loader2 } from "lucide-react";
import { useLocations, useCountryCityPairs } from "../../hooks";
import { useTheme } from "../../contexts/ThemeContext";

interface LocationSelectorProps {
  value: string; // Format: "country,city" or empty string
  onChange: (location: string) => void;
}

export const LocationSelector: React.FC<LocationSelectorProps> = ({
  value,
  onChange,
}) => {
  const { isDark } = useTheme();

  // Parse current value
  const [selectedCountry, selectedCity] = value ? value.split(",") : ["", ""];

  // Local state for country selection
  const [countryValue, setCountryValue] = useState(selectedCountry);
  const [cityValue, setCityValue] = useState(selectedCity);

  // Dropdown states
  const [isCountryOpen, setIsCountryOpen] = useState(false);
  const [isCityOpen, setIsCityOpen] = useState(false);

  // Fetch countries
  const { data: countriesData, isLoading: loadingCountries } =
    useLocations("country");

  // Fetch cities when country is selected
  const { data: citiesData, isLoading: loadingCities } =
    useCountryCityPairs(countryValue);

  // Extract countries from the response
  const countries = countriesData?.data || [];

  // Extract cities from the response
  const cities = citiesData?.data || [];

  // Update parent when country or city changes
  useEffect(() => {
    if (countryValue && cityValue) {
      onChange(`${countryValue},${cityValue}`);
    } else if (countryValue && !cityValue) {
      onChange(countryValue);
    } else {
      onChange("");
    }
  }, [countryValue, cityValue, onChange]);

  // Handle country selection
  const handleCountryChange = (country: string) => {
    setCountryValue(country);
    setCityValue(""); // Reset city when country changes
  };

  // Handle city selection
  const handleCityChange = (city: string) => {
    setCityValue(city);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* Country Dropdown */}
      <div className="relative">
        <button
          onClick={() => setIsCountryOpen(!isCountryOpen)}
          disabled={loadingCountries}
          className={`w-full px-4 md:px-5 py-3 md:py-3.5 border-2 rounded-xl focus:ring-2 focus:outline-none focus:ring-orange-500/40 appearance-none transition-all duration-300 text-left flex items-center justify-between text-sm md:text-base  ${
            isDark
              ? "bg-gray-700/50 border-gray-600 text-white hover:border-orange-400"
              : "bg-white/70 border-orange-200 text-gray-900 hover:border-orange-300"
          } ${loadingCountries ? "opacity-50 cursor-not-allowed" : ""}`}
        >
          <div className="flex items-center gap-3">
            <MapPin
              className={`w-4 h-4 ${
                isDark ? "text-orange-400" : "text-purple-600"
              }`}
            />
            <span className="truncate">
              {loadingCountries
                ? "Loading countries..."
                : countryValue || "Select Country"}
            </span>
          </div>
          {loadingCountries ? (
            <Loader2 className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0 ml-2 animate-spin" />
          ) : (
            <ChevronDown
              className={`w-4 h-4 md:w-5 md:h-5 flex-shrink-0 ml-2 transition-transform duration-300 ${
                isCountryOpen ? "rotate-180" : ""
              }`}
            />
          )}
        </button>

        {isCountryOpen && (
          <div
            className={`absolute top-full left-0 right-0 mt-2 rounded-xl border-2 shadow-2xl z-[100] overflow-hidden animate-in slide-in-from-top-2 duration-200 ${
              isDark
                ? "bg-gray-800/95 backdrop-blur-xl border-gray-600/60 shadow-orange-500/10"
                : "bg-white/95 backdrop-blur-xl border-orange-200/60 shadow-purple-500/10"
            }`}
          >
            <div className="  max-h-48 md:max-h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-orange-400 scrollbar-track-transparent">
              <button
                onClick={() => {
                  handleCountryChange("");
                  setIsCountryOpen(false);
                }}
                className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base group ${
                  isDark
                    ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                    : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                } ${
                  !countryValue
                    ? isDark
                      ? "bg-orange-500/10 text-orange-300"
                      : "bg-purple-100 text-purple-700"
                    : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  <MapPin
                    className={`w-4 h-4 ${
                      isDark ? "text-orange-400" : "text-purple-600"
                    }`}
                  />
                  <span>All Countries</span>
                  {!countryValue && (
                    <CheckCircle className="w-4 h-4 text-green-500 ml-auto" />
                  )}
                </div>
              </button>
              {countries.map((country: any) => (
                <button
                  key={country.id}
                  onClick={() => {
                    handleCountryChange(country.name);
                    setIsCountryOpen(false);
                  }}
                  className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base group ${
                    isDark
                      ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                      : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                  } ${
                    countryValue === country.name
                      ? isDark
                        ? "bg-gradient-to-r from-orange-500/20 to-purple-500/20 text-orange-300"
                        : "bg-gradient-to-r from-purple-100 to-orange-50 text-purple-700"
                      : ""
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                        countryValue === country.name
                          ? isDark
                            ? "bg-orange-400"
                            : "bg-purple-600"
                          : isDark
                          ? "bg-gray-600"
                          : "bg-gray-300"
                      }`}
                    />
                    <span>{country.name}</span>
                    {countryValue === country.name && (
                      <CheckCircle className="w-4 h-4 text-green-500 ml-auto animate-in zoom-in-50 duration-200" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* City Dropdown */}
      <div className="relative">
        <button
          onClick={() => setIsCityOpen(!isCityOpen)}
          disabled={!countryValue || loadingCities}
          className={`w-full px-4 md:px-5 py-3 md:py-3.5 border-2 rounded-xl focus:ring-2 focus:outline-none focus:ring-orange-500/40 appearance-none transition-all duration-300 text-left flex items-center justify-between text-sm md:text-base  ${
            isDark
              ? "bg-gray-700/50 border-gray-600 text-white hover:border-orange-400"
              : "bg-white/70 border-orange-200 text-gray-900 hover:border-orange-300"
          } ${
            !countryValue || loadingCities
              ? "opacity-50 cursor-not-allowed"
              : ""
          }`}
        >
          <div className="flex items-center gap-3">
            <MapPin
              className={`w-4 h-4 ${
                isDark ? "text-orange-400" : "text-purple-600"
              }`}
            />
            <span className="truncate">
              {!countryValue
                ? "Select country first"
                : loadingCities
                ? "Loading cities..."
                : cityValue || "Select City (Optional)"}
            </span>
          </div>
          {loadingCities ? (
            <Loader2 className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0 ml-2 animate-spin" />
          ) : (
            <ChevronDown
              className={`w-4 h-4 md:w-5 md:h-5 flex-shrink-0 ml-2 transition-transform duration-300 ${
                isCityOpen ? "rotate-180" : ""
              }`}
            />
          )}
        </button>

        {isCityOpen && countryValue && (
          <div
            className={`absolute top-full left-0 right-0 mt-2 rounded-xl border-2 shadow-2xl z-[100] overflow-hidden animate-in slide-in-from-top-2 duration-200 ${
              isDark
                ? "bg-gray-800/95 backdrop-blur-xl border-gray-600/60 shadow-orange-500/10"
                : "bg-white/95 backdrop-blur-xl border-orange-200/60 shadow-purple-500/10"
            }`}
          >
            <div className="max-h-48 md:max-h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-orange-400 scrollbar-track-transparent">
              <button
                onClick={() => {
                  handleCityChange("");
                  setIsCityOpen(false);
                }}
                className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base group ${
                  isDark
                    ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                    : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                } ${
                  !cityValue
                    ? isDark
                      ? "bg-orange-500/10 text-orange-300"
                      : "bg-purple-100 text-purple-700"
                    : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  <MapPin
                    className={`w-4 h-4 ${
                      isDark ? "text-orange-400" : "text-purple-600"
                    }`}
                  />
                  <span>All Cities</span>
                  {!cityValue && (
                    <CheckCircle className="w-4 h-4 text-green-500 ml-auto" />
                  )}
                </div>
              </button>
              {cities.map((cityData: any, index: number) => (
                <button
                  key={index}
                  onClick={() => {
                    handleCityChange(cityData.city);
                    setIsCityOpen(false);
                  }}
                  className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base group ${
                    isDark
                      ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                      : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                  } ${
                    cityValue === cityData.city
                      ? isDark
                        ? "bg-gradient-to-r from-orange-500/20 to-purple-500/20 text-orange-300"
                        : "bg-gradient-to-r from-purple-100 to-orange-50 text-purple-700"
                      : ""
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                        cityValue === cityData.city
                          ? isDark
                            ? "bg-orange-400"
                            : "bg-purple-600"
                          : isDark
                          ? "bg-gray-600"
                          : "bg-gray-300"
                      }`}
                    />
                    <span>{cityData.city}</span>
                    {cityValue === cityData.city && (
                      <CheckCircle className="w-4 h-4 text-green-500 ml-auto animate-in zoom-in-50 duration-200" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
