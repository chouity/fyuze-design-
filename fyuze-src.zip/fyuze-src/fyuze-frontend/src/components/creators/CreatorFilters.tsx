import React, {
  useState,
  useCallback,
  useMemo,
  useEffect,
  useRef,
} from "react";
import {
  Search,
  Filter,
  ChevronDown,
  X,
  Globe,
  Users,
  CheckCircle,
} from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import { LocationSelector } from "..";
import { useCategories, usePlatforms } from "../../hooks/useSupabaseQuery";

interface Platform {
  platform: string;
}
interface Category {
  category: string;
}
export interface CreatorFiltersProps {
  filters: {
    search: string;
    platform: string;
    category: string;
    location: string;
    verified: boolean | null;
    followers_min: string;
    followers_max: string;
    engagement_rate_min: string;
    engagement_rate_max: string;
    audience_gender: string;
    audience_age_min: string;
    audience_age_max: string;
  };
  showAdvancedFilters: boolean;
  onFilterChange: (key: string, value: any) => void;
  onToggleAdvanced: () => void;
  onClearFilters: () => void;
}

export const CreatorFilters: React.FC<CreatorFiltersProps> = React.memo(
  ({
    filters,
    showAdvancedFilters,
    onFilterChange,
    onToggleAdvanced,
    onClearFilters,
  }) => {
    // Theme hook
    const { isDark } = useTheme();

    const { data: platformsData } = usePlatforms();
    const { data: categoriesData } = useCategories();

    // State for dropdowns
    const [isPlatformOpen, setIsPlatformOpen] = useState(false);
    const [isCategoryOpen, setIsCategoryOpen] = useState(false);
    const [isVerifiedOpen, setIsVerifiedOpen] = useState(false);

    // Refs for click-outside detection
    const platformRef = useRef<HTMLDivElement>(null);
    const categoryRef = useRef<HTMLDivElement>(null);
    const verifiedRef = useRef<HTMLDivElement>(null);

    // State for K/M selection
    const [followersMinUnit, setFollowersMinUnit] = useState<"K" | "M">("K");
    const [followersMaxUnit, setFollowersMaxUnit] = useState<"K" | "M">("M");

    // Memoized data processing (to be used in place of direct data access)
    const platforms = useMemo(() => platformsData?.data || [], [platformsData]);
    const categories = useMemo(
      () => categoriesData?.data || [],
      [categoriesData]
    );

    // Close all dropdowns when any other action happens
    const closeAllDropdowns = useCallback(() => {
      setIsPlatformOpen(false);
      setIsCategoryOpen(false);
      setIsVerifiedOpen(false);
    }, []);

    // Memoized callback for location changes to prevent infinite re-renders
    const handleLocationChange = useCallback(
      (location: string) => {
        closeAllDropdowns();
        onFilterChange("location", location);
      },
      [onFilterChange, closeAllDropdowns]
    );

    // Handler for followers input with number parsing and K/M
    const handleFollowersChange = useCallback(
      (
        field: "followers_min" | "followers_max",
        value: string,
        unit: "K" | "M"
      ) => {
        // Only allow numbers and decimal
        const sanitized = value.replace(/[^\d.]/g, "");
        const num = sanitized ? Number(sanitized) : NaN;
        if (!isNaN(num)) {
          const multiplied = unit === "K" ? num * 1000 : num * 1000000;
          onFilterChange(field, multiplied.toString());
        } else {
          onFilterChange(field, "");
        }
      },
      [onFilterChange]
    );

    // Click-outside effect for Platform dropdown
    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (
          platformRef.current &&
          !platformRef.current.contains(event.target as Node)
        ) {
          setIsPlatformOpen(false);
        }
      };

      if (isPlatformOpen) {
        document.addEventListener("mousedown", handleClickOutside);
        return () =>
          document.removeEventListener("mousedown", handleClickOutside);
      }
    }, [isPlatformOpen]);

    // Click-outside effect for Category dropdown
    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (
          categoryRef.current &&
          !categoryRef.current.contains(event.target as Node)
        ) {
          setIsCategoryOpen(false);
        }
      };

      if (isCategoryOpen) {
        document.addEventListener("mousedown", handleClickOutside);
        return () =>
          document.removeEventListener("mousedown", handleClickOutside);
      }
    }, [isCategoryOpen]);

    // Click-outside effect for Verified dropdown
    useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
        if (
          verifiedRef.current &&
          !verifiedRef.current.contains(event.target as Node)
        ) {
          setIsVerifiedOpen(false);
        }
      };

      if (isVerifiedOpen) {
        document.addEventListener("mousedown", handleClickOutside);
        return () =>
          document.removeEventListener("mousedown", handleClickOutside);
      }
    }, [isVerifiedOpen]);
    return (
      <div
        className={`rounded-3xl shadow-2xl border p-4 md:p-8 mb-8 transition-all duration-500 ${
          isDark
            ? "bg-gradient-to-br from-gray-800/95 via-gray-900/95 to-purple-900/95 backdrop-blur-xl border-gray-700/50 text-white"
            : "bg-gradient-to-br from-white/95 via-orange-50/95 to-red-50/95 backdrop-blur-xl border-orange-200/50 text-gray-900"
        }`}
      >
        <div className="space-y-6 md:space-y-8">
          {/* Header */}
          {/* <div className="text-center">
          <h2
            className={`text-xl md:text-2xl font-bold mb-2 ${
              isDark ? "text-orange-400" : "text-purple-600"
            }`}
          >
            Find Your Perfect Creator
          </h2>
          <p
            className={`text-xs md:text-sm ${
              isDark ? "text-gray-300" : "text-gray-600"
            }`}
          >
            Use our advanced filters to discover the ideal influencers for your
            brand
          </p>
        </div> */}

          {/* Search Bar with enhanced design */}
          <div className="relative group">
            <div
              className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${
                isDark
                  ? "from-orange-500/20 to-purple-500/20"
                  : "from-orange-400/20 to-purple-400/20"
              } opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl`}
            ></div>
            <div className="relative">
              <Search
                className={`absolute left-4 md:left-6 top-1/2 transform -translate-y-1/2 w-5 h-5 md:w-6 md:h-6 transition-colors duration-300 ${
                  isDark
                    ? "text-orange-400  group-hover:text-orange-300"
                    : "text-purple-600 focus:  group-hover:text-purple-700"
                }`}
              />
              <input
                type="text"
                placeholder="Search by name, username, bio..."
                value={filters.search}
                onChange={(e) => onFilterChange("search", e.target.value)}
                onFocus={closeAllDropdowns}
                className={`w-full max-h-20 pl-12 md:pl-16 pr-4 md:pr-8 py-4 md:py-5 border-2 rounded-2xl focus:ring-2 focus:scale-[1.02] focus:outline-none transition-all duration-300 text-base md:text-lg  ${
                  isDark
                    ? "bg-gray-800/70 border-gray-600/50 text-white placeholder-gray-400  focus:ring-orange-500/40"
                    : "bg-white/80 border-orange-200 text-gray-900 placeholder-gray-500  focus:ring-orange-500/40 "
                }`}
              />
            </div>
          </div>

          {/* Enhanced Location Selector with better UX */}
          <div className="space-y-3 md:space-y-4">
            <div className="flex items-center gap-2 md:gap-3">
              <Globe
                className={`w-5 h-5 md:w-6 md:h-6 ${
                  isDark ? "text-orange-400" : "text-purple-600"
                }`}
              />
              <label
                className={`text-base md:text-lg font-semibold ${
                  isDark ? "text-gray-200" : "text-gray-800"
                }`}
              >
                Select Location
              </label>
            </div>
            <div
              className={`p-4 md:p-6 rounded-2xl border-2 transition-all duration-300 ${
                isDark
                  ? "bg-gray-800/50 border-gray-600/50 hover:border-orange-400/50"
                  : "bg-white/70 border-orange-200/50 hover:border-purple-300/50"
              }`}
            >
              <LocationSelector
                value={filters.location}
                onChange={handleLocationChange}
              />
            </div>
          </div>

          {/* Enhanced Filter Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {/* Platform Card */}
            <div
              ref={platformRef}
              className={`relative group z-20 ${
                isDark
                  ? "bg-gray-800/60 hover:bg-gray-700/60"
                  : "bg-white/80 hover:bg-white/90"
              } rounded-2xl border-2 transition-all duration-300 p-4 md:p-6 hover:shadow-xl hover:scale-[1.02] ${
                isDark
                  ? "border-gray-600/50 hover:border-orange-400/50"
                  : "border-orange-200/50 hover:border-purple-300/50"
              }`}
            >
              <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                <div
                  className={`p-1.5 md:p-2 rounded-xl ${
                    isDark ? "bg-orange-500/20" : "bg-purple-100"
                  }`}
                >
                  <Globe
                    className={`w-4 h-4 md:w-5 md:h-5 ${
                      isDark ? "text-orange-400" : "text-purple-600"
                    }`}
                  />
                </div>
                <h3
                  className={`text-sm md:text-base font-semibold ${
                    isDark ? "text-gray-200" : "text-gray-800"
                  }`}
                >
                  Platform
                </h3>
              </div>

              <div className="relative">
                <button
                  onClick={() => {
                    setIsCategoryOpen(false);
                    setIsVerifiedOpen(false);
                    setIsPlatformOpen(!isPlatformOpen);
                  }}
                  className={`w-full px-3 md:px-4 py-2.5 md:py-3 border-2 rounded-xl focus:ring-2 focus:outline-none  focus:ring-orange-500/40 appearance-none transition-all duration-300 text-left flex items-center justify-between text-sm md:text-base ${
                    isDark
                      ? "bg-gray-700/50 border-gray-600 text-white hover:border-orange-400"
                      : "bg-white/70 border-orange-200 text-gray-900 hover:border-orange-300"
                  }`}
                >
                  <span
                    className={`truncate ${
                      filters.platform || "text-gray-400"
                    }`}
                  >
                    {filters.platform || "Select platform"}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 md:w-5 md:h-5 flex-shrink-0 ml-2 transition-transform duration-300 ${
                      isPlatformOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {isPlatformOpen && (
                  <div
                    className={`absolute top-full left-0 right-0 mt-2 rounded-xl border-2 shadow-2xl z-[100] overflow-hidden animate-in slide-in-from-top-2 duration-200 ${
                      isDark
                        ? "bg-gray-800/95 backdrop-blur-xl border-gray-600/60 shadow-orange-500/10"
                        : "bg-white/95 backdrop-blur-xl border-orange-200/60 shadow-purple-500/10"
                    }`}
                  >
                    <div className="max-h-48 md:max-h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-orange-400 scrollbar-track-transparent">
                      <button
                        onClick={() => {
                          onFilterChange("platform", "");
                          setIsPlatformOpen(false);
                        }}
                        className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base font-medium ${
                          isDark
                            ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                            : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                        } ${
                          !filters.platform
                            ? isDark
                              ? "bg-orange-500/10 text-orange-300"
                              : "bg-purple-100 text-purple-700"
                            : ""
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Globe
                            className={`w-4 h-4 ${
                              isDark ? "text-orange-400" : "text-purple-600"
                            }`}
                          />
                          <span>All Platforms</span>
                          {!filters.platform && (
                            <CheckCircle className="w-4 h-4 text-green-500 ml-auto" />
                          )}
                        </div>
                      </button>
                      {platforms?.map((item: Platform) => (
                        <button
                          key={item.platform}
                          onClick={() => {
                            onFilterChange("platform", item.platform);
                            setIsPlatformOpen(false);
                          }}
                          className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base group ${
                            isDark
                              ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                              : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                          } ${
                            filters.platform === item.platform
                              ? isDark
                                ? "bg-gradient-to-r from-orange-500/20 to-purple-500/20 text-orange-300"
                                : "bg-gradient-to-r from-purple-100 to-orange-50 text-purple-700"
                              : ""
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                                filters.platform === item.platform
                                  ? isDark
                                    ? "bg-orange-400"
                                    : "bg-purple-600"
                                  : isDark
                                  ? "bg-gray-600"
                                  : "bg-gray-300"
                              }`}
                            />
                            <span className="font-medium">{item.platform}</span>
                            {filters.platform === item.platform && (
                              <CheckCircle className="w-4 h-4 text-green-500 ml-auto animate-in zoom-in-50 duration-200" />
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Category Card */}
            <div
              ref={categoryRef}
              className={`relative group z-20 ${
                isDark
                  ? "bg-gray-800/60 hover:bg-gray-700/60"
                  : "bg-white/80 hover:bg-white/90"
              } rounded-2xl border-2 transition-all duration-300 p-4 md:p-6 hover:shadow-xl hover:scale-[1.02] ${
                isDark
                  ? "border-gray-600/50 hover:border-orange-400/50"
                  : "border-orange-200/50 hover:border-purple-300/50"
              }`}
            >
              <div className="flex items-center gap-3 mb-4">
                <div
                  className={`p-2 rounded-xl ${
                    isDark ? "bg-orange-500/20" : "bg-purple-100"
                  }`}
                >
                  <Filter
                    className={`w-5 h-5 ${
                      isDark ? "text-orange-400" : "text-purple-600"
                    }`}
                  />
                </div>
                <h3
                  className={`text-sm md:text-base font-semibold ${
                    isDark ? "text-gray-200" : "text-gray-800"
                  }`}
                >
                  Category
                </h3>
              </div>

              <div className="relative">
                <button
                  onClick={() => {
                    setIsPlatformOpen(false);
                    setIsVerifiedOpen(false);
                    setIsCategoryOpen(!isCategoryOpen);
                  }}
                  className={`w-full px-3 md:px-4 py-2.5 md:py-3 border-2 rounded-xl focus:ring-2 focus:outline-none  focus:ring-orange-500/40 appearance-none transition-all duration-300 text-left flex items-center justify-between text-sm md:text-base ${
                    isDark
                      ? "bg-gray-700/50 border-gray-600 text-white hover:border-orange-400"
                      : "bg-white/70 border-orange-200 text-gray-900 hover:border-orange-300"
                  }`}
                >
                  <span
                    className={`truncate ${
                      filters.category || "text-gray-400"
                    }`}
                  >
                    {filters.category || "Select category"}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 md:w-5 md:h-5 flex-shrink-0 ml-2 transition-transform duration-300 ${
                      isCategoryOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {isCategoryOpen && (
                  <div
                    className={`absolute top-full left-0 right-0 mt-2 rounded-xl border-2 shadow-2xl z-[100] overflow-hidden animate-in slide-in-from-top-2 duration-200 ${
                      isDark
                        ? "bg-gray-800/95 backdrop-blur-xl border-gray-600/60 shadow-orange-500/10"
                        : "bg-white/95 backdrop-blur-xl border-orange-200/60 shadow-purple-500/10"
                    }`}
                  >
                    <div className="max-h-48 md:max-h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-orange-400 scrollbar-track-transparent">
                      <button
                        onClick={() => {
                          onFilterChange("category", "");
                          setIsCategoryOpen(false);
                        }}
                        className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base font-medium ${
                          isDark
                            ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                            : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                        } ${
                          !filters.category
                            ? isDark
                              ? "bg-orange-500/10 text-orange-300"
                              : "bg-purple-100 text-purple-700"
                            : ""
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Filter
                            className={`w-4 h-4 ${
                              isDark ? "text-orange-400" : "text-purple-600"
                            }`}
                          />
                          <span>All Categories</span>
                          {!filters.category && (
                            <CheckCircle className="w-4 h-4 text-green-500 ml-auto" />
                          )}
                        </div>
                      </button>
                      {categories?.map((category: Category) => (
                        <button
                          key={category.category}
                          onClick={() => {
                            onFilterChange("category", category.category);
                            setIsCategoryOpen(false);
                          }}
                          className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base group ${
                            isDark
                              ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                              : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                          } ${
                            filters.category === category.category
                              ? isDark
                                ? "bg-gradient-to-r from-orange-500/20 to-purple-500/20 text-orange-300"
                                : "bg-gradient-to-r from-purple-100 to-orange-50 text-purple-700"
                              : ""
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                                filters.category === category.category
                                  ? isDark
                                    ? "bg-orange-400"
                                    : "bg-purple-600"
                                  : isDark
                                  ? "bg-gray-600"
                                  : "bg-gray-300"
                              }`}
                            />
                            <span className="font-medium">
                              {category.category}
                            </span>
                            {filters.category === category.category && (
                              <CheckCircle className="w-4 h-4 text-green-500 ml-auto animate-in zoom-in-50 duration-200" />
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Verified Status Card */}
            <div
              ref={verifiedRef}
              className={`relative group z-20 ${
                isDark
                  ? "bg-gray-800/60 hover:bg-gray-700/60"
                  : "bg-white/80 hover:bg-white/90"
              } rounded-2xl border-2 transition-all duration-300 p-4 md:p-6 hover:shadow-xl hover:scale-[1.02] ${
                isDark
                  ? "border-gray-600/50 hover:border-orange-400/50"
                  : "border-orange-200/50 hover:border-purple-300/50"
              }`}
            >
              <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                <div
                  className={`p-2 rounded-xl ${
                    isDark ? "bg-orange-500/20" : "bg-purple-100"
                  }`}
                >
                  <CheckCircle
                    className={`w-5 h-5 ${
                      isDark ? "text-orange-400" : "text-purple-600"
                    }`}
                  />
                </div>
                <h3
                  className={`text-sm md:text-base font-semibold ${
                    isDark ? "text-gray-200" : "text-gray-800"
                  }`}
                >
                  Verification
                </h3>
              </div>

              <div className="relative">
                <button
                  onClick={() => {
                    setIsPlatformOpen(false);
                    setIsCategoryOpen(false);
                    setIsVerifiedOpen(!isVerifiedOpen);
                  }}
                  className={`w-full px-3 md:px-4 py-2.5 md:py-3 border-2 rounded-xl focus:ring-2 focus:outline-none focus:ring-orange-500/40 appearance-none transition-all duration-300 text-left flex items-center justify-between text-sm md:text-base ${
                    isDark
                      ? "bg-gray-700/50 border-gray-600 text-white hover:border-orange-400"
                      : "bg-white/70 border-orange-200 text-gray-900 hover:border-orange-300"
                  }`}
                >
                  <span className="truncate">
                    {filters.verified === null
                      ? "All Creators"
                      : filters.verified
                      ? "Verified Only"
                      : "Unverified Only"}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 md:w-5 md:h-5 flex-shrink-0 ml-2 transition-transform duration-300 ${
                      isVerifiedOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {isVerifiedOpen && (
                  <div
                    className={`absolute top-full left-0 right-0 mt-2 rounded-xl border-2 shadow-2xl z-[100] overflow-hidden animate-in slide-in-from-top-2 duration-200 ${
                      isDark
                        ? "bg-gray-800/95 backdrop-blur-xl border-gray-600/60 shadow-orange-500/10"
                        : "bg-white/95 backdrop-blur-xl border-orange-200/60 shadow-purple-500/10"
                    }`}
                  >
                    {[
                      { value: null, label: "All Creators" },
                      { value: true, label: "Verified Only" },
                      { value: false, label: "Unverified Only" },
                    ].map((option) => (
                      <button
                        key={option.label}
                        onClick={() => {
                          onFilterChange("verified", option.value);
                          setIsVerifiedOpen(false);
                        }}
                        className={`w-full px-4 md:px-5 py-3 md:py-4 text-left transition-all duration-200 text-sm md:text-base group ${
                          isDark
                            ? "hover:bg-gradient-to-r hover:from-orange-500/20 hover:to-purple-500/20 text-gray-200 hover:text-white"
                            : "hover:bg-gradient-to-r hover:from-purple-500/10 hover:to-orange-500/10 text-gray-700 hover:text-gray-900"
                        } ${
                          filters.verified === option.value
                            ? isDark
                              ? "bg-gradient-to-r from-orange-500/20 to-purple-500/20 text-orange-300"
                              : "bg-gradient-to-r from-purple-100 to-orange-50 text-purple-700"
                            : ""
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                              filters.verified === option.value
                                ? isDark
                                  ? "bg-orange-400"
                                  : "bg-purple-600"
                                : isDark
                                ? "bg-gray-600"
                                : "bg-gray-300"
                            }`}
                          />
                          <span>{option.label}</span>
                          {filters.verified === option.value && (
                            <CheckCircle className="w-4 h-4 text-green-500 ml-auto animate-in zoom-in-50 duration-200" />
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Enhanced Control Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 md:gap-4 pt-4 md:pt-6 border-t-2 border-gray-200/30">
            <button
              onClick={() => {
                closeAllDropdowns();
                onToggleAdvanced();
              }}
              className={`group relative z-10 flex items-center justify-center gap-2 md:gap-3 px-4 py-3 rounded-xl md:rounded-2xl font-semibold text-sm md:text-base transition-all duration-300 hover:scale-105 hover:shadow-xl cursor-pointer ${
                isDark
                  ? "bg-orange-400 hover:orange-400/50 text-white"
                  : "bg-orange-400 hover:orange-400/50 text-white"
              }`}
            >
              <div
                className={`p-1.5 md:p-2 rounded-lg md:rounded-xl ${
                  isDark ? "bg-white/20" : "bg-white/30"
                }`}
              >
                <Filter className="w-4 h-4 md:w-5 md:h-5" />
              </div>
              <span>Advanced Filters</span>
              <ChevronDown
                className={`w-4 h-4 md:w-5 md:h-5 transform transition-transform duration-300 ${
                  showAdvancedFilters ? "rotate-180" : ""
                }`}
              />
              <div className="absolute inset-0 bg-white/10 rounded-xl md:rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>

            <button
              onClick={() => {
                closeAllDropdowns();
                onClearFilters();
              }}
              className={`group relative z-10 flex items-center justify-center gap-2 md:gap-3 px-4 py-3 rounded-xl md:rounded-2xl font-semibold text-sm md:text-base transition-all duration-300 hover:scale-105 border-2 ${
                isDark
                  ? "border-gray-600 bg-gray-800/50 text-gray-300 hover:border-gray-500 hover:bg-gray-700/50 hover:text-white"
                  : "border-gray-300 bg-white/50 text-gray-600 hover:border-gray-400 hover:bg-white/70 hover:text-gray-800"
              }`}
            >
              <X className="w-4 h-4 md:w-5 md:h-5" />
              <span>Clear All</span>
            </button>
          </div>

          {/* Enhanced Advanced Filters */}
          {showAdvancedFilters && (
            <div
              className={`pt-6 md:pt-8 border-t-2 border-gray-200/30 animate-in slide-in-from-top-4 duration-500 ${
                isDark ? "bg-gray-800/30" : "bg-white/30"
              } rounded-xl md:rounded-2xl p-4 md:p-6 backdrop-blur-sm`}
            >
              <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
                <Users
                  className={`w-5 h-5 md:w-6 md:h-6 ${
                    isDark ? "text-orange-400" : "text-purple-600"
                  }`}
                />
                <h3
                  className={`text-lg md:text-xl font-semibold ${
                    isDark ? "text-gray-200" : "text-gray-800"
                  }`}
                >
                  Follower Range
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                {/* Min Followers */}
                <div
                  className={`p-4 md:p-6 rounded-xl md:rounded-2xl border-2 transition-all duration-300 ${
                    isDark
                      ? "bg-gray-700/50 border-gray-600/50 hover:border-orange-400/50"
                      : "bg-white/70 border-gray-200/50 hover:border-purple-300/50"
                  }`}
                >
                  <label
                    className={`block text-sm font-semibold mb-3 md:mb-4 ${
                      isDark ? "text-gray-300" : "text-gray-700"
                    }`}
                  >
                    Minimum Followers
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="e.g., 1"
                      value={
                        filters.followers_min
                          ? (
                              parseInt(filters.followers_min) /
                              (followersMinUnit === "K" ? 1000 : 1000000)
                            ).toString()
                          : ""
                      }
                      onChange={(e) =>
                        handleFollowersChange(
                          "followers_min",
                          e.target.value,
                          followersMinUnit
                        )
                      }
                      className={`w-full px-4 md:px-6 py-3 md:py-4 pr-16 md:pr-20 border-2 rounded-xl focus:ring-2 focus:outline-none focus:ring-orange-500/40  transition-all duration-300 text-base md:text-lg ${
                        isDark
                          ? "bg-gray-800/70 border-gray-600 text-white placeholder-gray-400 hover:border-orange-400"
                          : "bg-white/80 border-orange-200 text-gray-900 placeholder-gray-500 hover:border-orange-300"
                      }`}
                    />
                    <div className="absolute right-2 md:right-3 top-1/2 transform -translate-y-1/2 flex">
                      <button
                        type="button"
                        onClick={() => setFollowersMinUnit("K")}
                        className={`px-2 md:px-3 py-1 text-xs md:text-sm font-bold rounded-l-lg transition-colors cursor-pointer ${
                          followersMinUnit === "K"
                            ? isDark
                              ? "bg-orange-500 text-white"
                              : "bg-purple-500 text-white"
                            : isDark
                            ? "bg-gray-600 text-gray-300 hover:bg-gray-500"
                            : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                        }`}
                      >
                        K
                      </button>
                      <button
                        type="button"
                        onClick={() => setFollowersMinUnit("M")}
                        className={`px-2 md:px-3 py-1 text-xs md:text-sm font-bold rounded-r-lg transition-colors cursor-pointer ${
                          followersMinUnit === "M"
                            ? isDark
                              ? "bg-orange-500 text-white"
                              : "bg-purple-500 text-white"
                            : isDark
                            ? "bg-gray-600 text-gray-300 hover:bg-gray-500"
                            : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                        }`}
                      >
                        M
                      </button>
                    </div>
                  </div>
                </div>

                {/* Max Followers */}
                <div
                  className={`p-4 md:p-6 rounded-xl md:rounded-2xl border-2 transition-all focus:outline-none duration-300 ${
                    isDark
                      ? "bg-gray-700/50 border-gray-600/50 hover:border-orange-400/50"
                      : "bg-white/70 border-gray-200/50 hover:border-purple-300/50"
                  }`}
                >
                  <label
                    className={`block text-sm font-semibold mb-3 md:mb-4 ${
                      isDark ? "text-gray-300" : "text-gray-700"
                    }`}
                  >
                    Maximum Followers
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="e.g., 100"
                      value={
                        filters.followers_max
                          ? (
                              parseInt(filters.followers_max) /
                              (followersMaxUnit === "K" ? 1000 : 1000000)
                            ).toString()
                          : ""
                      }
                      onChange={(e) =>
                        handleFollowersChange(
                          "followers_max",
                          e.target.value,
                          followersMaxUnit
                        )
                      }
                      className={`w-full px-6 py-4 pr-20 border-2 rounded-xl focus:ring-2 focus:outline-none focus:ring-orange-500/40  transition-all duration-300 text-lg ${
                        isDark
                          ? "bg-gray-800/70 border-gray-600 text-white placeholder-gray-400 hover:border-orange-400"
                          : "bg-white/80 border-orange-200 text-gray-900 placeholder-gray-500 hover:border-orange-300"
                      }`}
                    />
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex">
                      <button
                        type="button"
                        onClick={() => setFollowersMaxUnit("K")}
                        className={`px-3 py-1 text-sm font-bold rounded-l-lg transition-colors cursor-pointer ${
                          followersMaxUnit === "K"
                            ? isDark
                              ? "bg-orange-500 text-white"
                              : "bg-purple-500 text-white"
                            : isDark
                            ? "bg-gray-600 text-gray-300 hover:bg-gray-500"
                            : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                        }`}
                      >
                        K
                      </button>
                      <button
                        type="button"
                        onClick={() => setFollowersMaxUnit("M")}
                        className={`px-3 py-1 text-sm font-bold rounded-r-lg transition-colors cursor-pointer ${
                          followersMaxUnit === "M"
                            ? isDark
                              ? "bg-orange-500 text-white"
                              : "bg-purple-500 text-white"
                            : isDark
                            ? "bg-gray-600 text-gray-300 hover:bg-gray-500"
                            : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                        }`}
                      >
                        M
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Audience Gender Filter */}
              <div className="mt-6 md:mt-8">
                <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
                  <Users
                    className={`w-5 h-5 md:w-6 md:h-6 ${
                      isDark ? "text-orange-400" : "text-purple-600"
                    }`}
                  />
                  <h3
                    className={`text-lg md:text-xl font-semibold ${
                      isDark ? "text-gray-200" : "text-gray-800"
                    }`}
                  >
                    Audience Demographics
                  </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                  {/* Gender Filter */}
                  <div
                    className={`p-4 md:p-6 rounded-xl md:rounded-2xl border-2 transition-all duration-300 ${
                      isDark
                        ? "bg-gray-700/50 border-gray-600/50 hover:border-orange-400/50"
                        : "bg-white/70 border-gray-200/50 hover:border-purple-300/50"
                    }`}
                  >
                    <label
                      className={`block text-sm font-semibold mb-3 md:mb-4 ${
                        isDark ? "text-gray-300" : "text-gray-700"
                      }`}
                    >
                      Audience Gender
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { value: "any", label: "Any" },
                        { value: "male", label: "Male" },
                        { value: "female", label: "Female" },
                      ].map((option) => (
                        <button
                          key={option.value}
                          onClick={() =>
                            onFilterChange("audience_gender", option.value)
                          }
                          className={`px-3 md:px-4 py-2 md:py-3 text-sm md:text-base font-medium rounded-lg transition-all duration-200 ${
                            filters.audience_gender === option.value
                              ? isDark
                                ? "bg-orange-500 text-white shadow-lg"
                                : "bg-purple-500 text-white shadow-lg"
                              : isDark
                              ? "bg-gray-600/50 text-gray-300 hover:bg-gray-500/50"
                              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Age Range Slider */}
                  <div
                    className={`p-4 md:p-6 rounded-xl md:rounded-2xl border-2 transition-all duration-300 ${
                      isDark
                        ? "bg-gray-700/50 border-gray-600/50 hover:border-orange-400/50"
                        : "bg-white/70 border-gray-200/50 hover:border-purple-300/50"
                    }`}
                  >
                    <label
                      className={`block text-sm font-semibold mb-3 md:mb-4 ${
                        isDark ? "text-gray-300" : "text-gray-700"
                      }`}
                    >
                      Audience Age Range
                    </label>
                    <div className="space-y-4">
                      {/* Age Range Display */}
                      <div className="flex items-center justify-between text-sm">
                        <span
                          className={isDark ? "text-gray-400" : "text-gray-600"}
                        >
                          18 - 65 years
                        </span>
                        <span
                          className={`font-medium ${
                            isDark ? "text-orange-400" : "text-purple-600"
                          }`}
                        >
                          Current: 18 - 65
                        </span>
                      </div>

                      {/* Custom Slider */}
                      <div className="relative">
                        <div
                          className={`h-2 rounded-full ${
                            isDark ? "bg-gray-600" : "bg-gray-300"
                          }`}
                        >
                          <div
                            className={`h-2 rounded-full ${
                              isDark ? "bg-orange-500" : "bg-purple-500"
                            }`}
                            style={{ width: "100%" }}
                          ></div>
                        </div>

                        {/* Slider Thumbs */}
                        <div className="relative">
                          <div
                            className={`absolute top-1/2 transform -translate-y-1/2 w-5 h-5 rounded-full border-2 shadow-lg cursor-pointer transition-all duration-200 ${
                              isDark
                                ? "bg-orange-500 border-orange-300 hover:bg-orange-400"
                                : "bg-purple-500 border-purple-300 hover:bg-purple-400"
                            }`}
                            style={{ left: "0%" }}
                          ></div>
                          <div
                            className={`absolute top-1/2 transform -translate-y-1/2 w-5 h-5 rounded-full border-2 shadow-lg cursor-pointer transition-all duration-200 ${
                              isDark
                                ? "bg-orange-500 border-orange-300 hover:bg-orange-400"
                                : "bg-purple-500 border-purple-300 hover:bg-purple-400"
                            }`}
                            style={{
                              left: "100%",
                              transform: "translate(-100%, -50%)",
                            }}
                          ></div>
                        </div>
                      </div>

                      {/* Age Labels */}
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>18</span>
                        <span>25</span>
                        <span>35</span>
                        <span>45</span>
                        <span>55</span>
                        <span>65+</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
);

export default CreatorFilters;
