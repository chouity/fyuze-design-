import React from "react";
import { Users, List, Grid3X3 } from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";

export interface ResultsHeaderProps {
  loading: boolean;
  totalResults: number;
  viewMode: "table" | "cards";
  onViewModeChange: (mode: "table" | "cards") => void;
}

export const ResultsHeader: React.FC<ResultsHeaderProps> = ({
  loading,
  totalResults,
  viewMode,
  onViewModeChange,
}) => {
  const { isDark } = useTheme();
  return (
    <div
      className={`px-4 md:px-6 py-3 md:py-4 border-b ${
        isDark
          ? "bg-gradient-to-br from-gray-800/95 via-gray-900/95 to-purple-900/95 backdrop-blur-xl border-gray-700/50 text-white"
          : "bg-gradient-to-br from-white/95 via-orange-50/95 to-red-50/95 backdrop-blur-xl border-orange-200/50 text-gray-900"
      }`}
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
        <div className="flex items-center">
          <Users
            className={`w-4 h-4 md:w-5 md:h-5 mr-2 ${
              isDark ? "text-gray-300" : "text-gray-500"
            }`}
          />
          <span
            className={`font-medium text-sm md:text-base ${
              isDark ? "text-gray-200" : "text-gray-900"
            }`}
          >
            {loading ? "Loading..." : `${totalResults} creators found`}
          </span>
        </div>
        <div className="flex items-center gap-3 md:gap-4 cursor-pointer">
          {/* View Toggle - Hidden on mobile since we force cards */}
          <div className="hidden md:flex items-center rounded-lg p-1">
            <button
              onClick={() => onViewModeChange("table")}
              className={`p-1.5 md:p-2 rounded-md transition-colors cursor-pointer ${
                viewMode === "table"
                  ? isDark
                    ? "bg-gray-700 text-orange-400 shadow-sm"
                    : "bg-white text-orange-600 shadow-sm"
                  : isDark
                  ? "text-gray-400 hover:text-gray-200"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <List className="w-3 h-3 md:w-4 md:h-4" />
            </button>
            <button
              onClick={() => onViewModeChange("cards")}
              className={`p-1.5 md:p-2 rounded-md transition-colors cursor-pointer ${
                viewMode === "cards"
                  ? isDark
                    ? "bg-gray-700 text-orange-400 shadow-sm"
                    : "bg-white text-orange-600 shadow-sm"
                  : isDark
                  ? "text-gray-400 hover:text-gray-200"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <Grid3X3 className="w-3 h-3 md:w-4 md:h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsHeader;
