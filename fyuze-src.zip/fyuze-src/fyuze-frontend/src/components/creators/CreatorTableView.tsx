import React from "react";
import { Check } from "lucide-react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useTheme } from "../../contexts/ThemeContext";
import { getPlatformIcon } from "../../config/platforms";
import type { Creator as BaseCreator } from "../../types/influencer";

export interface Creator
  extends Omit<
    BaseCreator,
    "engagement_rate" | "verified" | "id" | "platform"
  > {
  id: string;
  avatar_url?: string;
  profile_pic_url?: string;
  full_name?: string;
  is_verified?: boolean;
  engagement_rate: number | string;
  category?: string;
  contact_email?: string;
  verified?: boolean;
  following?: number;
  platform?: string;
}

export interface CreatorTableViewProps {
  creators: Creator[];
  formatNumber: (num: number) => string;
  dataSource?: "regular" | "ai_search";
}

export const CreatorTableView: React.FC<CreatorTableViewProps> = ({
  creators,
  formatNumber,
}) => {
  const { isDark } = useTheme();

  const handleCreatorClick = (creatorId: string) => {
    // Debug: Log the creator ID being opened
    console.log("CreatorTableView: Opening creator profile for ID:", creatorId);
    // Simply open creator profile in new tab
    window.open(`/creators/${creatorId}`, "_blank");
  };

  // Use dynamic platform icon from the platform configuration
  const renderPlatformIcon = (platform: string) => {
    const iconProps = getPlatformIcon(platform as any);

    if (!iconProps) {
      return (
        <div className="w-6 h-6 bg-gray-500 rounded-full flex items-center justify-center">
          <span className="text-white text-xs font-bold">?</span>
        </div>
      );
    }

    return (
      <div className="w-6 h-6 rounded-full flex items-center justify-center">
        <FontAwesomeIcon {...iconProps} />
      </div>
    );
  };

  const getEngagementBadge = (rate: number) => {
    if (rate >= 5) {
      return (
        <span
          className={`px-2 py-1 rounded-full text-xs font-medium ${
            isDark
              ? "bg-green-900/30 text-green-300"
              : "bg-green-100 text-green-800"
          }`}
        >
          Excellent
        </span>
      );
    } else if (rate >= 3) {
      return (
        <span
          className={`px-2 py-1 rounded-full text-xs font-medium ${
            isDark
              ? "bg-yellow-900/30 text-yellow-300"
              : "bg-yellow-100 text-yellow-800"
          }`}
        >
          Very good
        </span>
      );
    } else {
      return (
        <span
          className={`px-2 py-1 rounded-full text-xs font-medium ${
            isDark ? "bg-red-900/30 text-red-300" : "bg-red-100 text-red-800"
          }`}
        >
          {rate}
        </span>
      );
    }
  };

  const getCategoryIcon = (category: string) => {
    const categoryLower = category?.toLowerCase() || "";

    if (categoryLower.includes("beauty")) {
      return (
        <div className="flex items-center space-x-1">
          <div
            className={`w-4 h-4 rounded flex items-center justify-center ${
              isDark ? "bg-pink-900/30" : "bg-pink-100"
            }`}
          >
            <span
              className={`text-xs ${
                isDark ? "text-pink-300" : "text-pink-600"
              }`}
            >
              💄
            </span>
          </div>
          <span
            className={`text-sm ${isDark ? "text-gray-300" : "text-gray-600"}`}
          >
            Beauty
          </span>
        </div>
      );
    } else if (categoryLower.includes("food")) {
      return (
        <div className="flex items-center space-x-1">
          <div
            className={`w-4 h-4 rounded flex items-center justify-center ${
              isDark ? "bg-orange-900/30" : "bg-orange-100"
            }`}
          >
            <span
              className={`text-xs ${
                isDark ? "text-orange-300" : "text-orange-600"
              }`}
            >
              🍕
            </span>
          </div>
          <span
            className={`text-sm ${isDark ? "text-gray-300" : "text-gray-600"}`}
          >
            Food
          </span>
        </div>
      );
    } else if (categoryLower.includes("fashion")) {
      return (
        <div className="flex items-center space-x-1">
          <div
            className={`w-4 h-4 rounded flex items-center justify-center ${
              isDark ? "bg-purple-900/30" : "bg-purple-100"
            }`}
          >
            <span
              className={`text-xs ${
                isDark ? "text-purple-300" : "text-purple-600"
              }`}
            >
              👗
            </span>
          </div>
          <span
            className={`text-sm ${isDark ? "text-gray-300" : "text-gray-600"}`}
          >
            Fashion
          </span>
        </div>
      );
    } else if (categoryLower.includes("travel")) {
      return (
        <div className="flex items-center space-x-1">
          <div
            className={`w-4 h-4 rounded flex items-center justify-center ${
              isDark ? "bg-blue-900/30" : "bg-blue-100"
            }`}
          >
            <span
              className={`text-xs ${
                isDark ? "text-blue-300" : "text-blue-600"
              }`}
            >
              ✈️
            </span>
          </div>
          <span
            className={`text-sm ${isDark ? "text-gray-300" : "text-gray-600"}`}
          >
            Travel
          </span>
        </div>
      );
    } else if (categoryLower.includes("fitness")) {
      return (
        <div className="flex items-center space-x-1">
          <div
            className={`w-4 h-4 rounded flex items-center justify-center ${
              isDark ? "bg-green-900/30" : "bg-green-100"
            }`}
          >
            <span
              className={`text-xs ${
                isDark ? "text-green-300" : "text-green-600"
              }`}
            >
              💪
            </span>
          </div>
          <span
            className={`text-sm ${isDark ? "text-gray-300" : "text-gray-600"}`}
          >
            Fitness
          </span>
        </div>
      );
    } else {
      return (
        <span
          className={`text-sm ${isDark ? "text-gray-300" : "text-gray-600"}`}
        >
          {category || "-"}
        </span>
      );
    }
  };

  // Create a proxy URL for Instagram images to bypass CORS
  const getProxyImageUrl = (originalUrl: string, proxyIndex: number = 0) => {
    if (!originalUrl) return "/api/placeholder/300/300";

    // Try multiple CORS proxy services as fallbacks
    const proxyServices = [
      // Primary: Weserv.nl (fast and reliable)
      (url: string) =>
        `https://images.weserv.nl/?url=${encodeURIComponent(
          url
        )}&w=300&h=300&fit=cover`,
      // Fallback 1: AllOrigins (good alternative)
      (url: string) =>
        `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
      // Fallback 2: Cors-anywhere (requires headers, might be rate limited)
      (url: string) => `https://cors-anywhere.herokuapp.com/${url}`,
      // Fallback 3: Direct URL (will likely fail but worth trying)
      (url: string) => url,
    ];

    // Return the specified proxy service
    const selectedService =
      proxyServices[Math.min(proxyIndex, proxyServices.length - 1)];
    const result = selectedService(originalUrl);
    return result;
  };

  // Enhanced image URL handler with error recovery
  const getImageUrl = (originalUrl: string) => {
    if (!originalUrl) {
      return "/default-avatar.png";
    }

    // Try primary proxy first
    const proxyUrl = getProxyImageUrl(originalUrl, 0);
    return proxyUrl;
  };

  // Generate custom avatar with initials
  const generateCustomAvatar = (creator: Creator) => {
    const name = creator.name || creator.full_name || creator.username || "U";
    const initials = name
      .split(" ")
      .map((n) => n.charAt(0).toUpperCase())
      .slice(0, 2)
      .join("");

    // Generate a consistent color based on the creator's name
    const colors = [
      "bg-blue-500",
      "bg-green-500",
      "bg-purple-500",
      "bg-pink-500",
      "bg-indigo-500",
      "bg-red-500",
      "bg-yellow-500",
      "bg-teal-500",
      "bg-orange-500",
      "bg-cyan-500",
    ];
    const colorIndex =
      name.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0) %
      colors.length;
    const bgColor = colors[colorIndex];

    return (
      <div
        className={`w-10 h-10 rounded-full ${bgColor} flex items-center justify-center text-white font-semibold text-sm`}
      >
        {initials}
      </div>
    );
  };

  return (
    <div className="overflow-x-auto w-full">
      <table className="w-full min-w-[800px] border-collapse">
        <thead>
          <tr
            className={`border-b ${
              isDark ? "border-gray-700" : "border-gray-200"
            }`}
          >
            <th
              className={`text-left py-3 px-4 font-medium ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              USERNAME
            </th>
            <th
              className={`text-left py-3 px-4 font-medium ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              PLATFORMS
            </th>
            <th
              className={`text-left py-3 px-4 font-medium ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              FOLLOWERS
            </th>
            <th
              className={`text-left py-3 px-4 font-medium ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              ER
            </th>

            <th
              className={`text-left py-3 px-4 font-medium ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              CATEGORY
            </th>
          </tr>
        </thead>
        <tbody>
          {creators.map((creator, index) => (
            <tr
              key={creator.id}
              onClick={() => {
                // Debug: Log the creator object being clicked
                console.log("CreatorTableView: Clicked creator:", creator);
                console.log("CreatorTableView: Creator ID:", creator.id);
                console.log(
                  "CreatorTableView: Creator username:",
                  creator.username
                );
                // Use username for the URL since it's more user-friendly
                const creatorIdentifier = creator.username || creator.id;
                console.log(
                  "CreatorTableView: Using identifier:",
                  creatorIdentifier
                );
                handleCreatorClick(creatorIdentifier);
              }}
              className={`cursor-pointer transition-colors ${
                isDark
                  ? `border-b border-gray-700 hover:bg-gray-700 ${
                      index % 2 === 0 ? "bg-gray-800" : "bg-gray-750"
                    }`
                  : `border-b border-gray-100 hover:bg-gray-50 ${
                      index % 2 === 0 ? "bg-white" : "bg-gray-50"
                    }`
              }`}
            >
              <td className="py-4 px-4">
                <div className="flex items-center">
                  <div className="relative">
                    {creator.avatar_url ||
                    creator.profileData.profile_pic_url ? (
                      <img
                        src={getImageUrl(
                          (creator.avatar_url ||
                            creator.platform_data.profile_pic_url ||
                            creator.profile_pic_url)!
                        )}
                        alt={
                          creator.name || creator.full_name || creator.username
                        }
                        className="w-10 h-10 rounded-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = "none";
                          const parent = target.parentElement;
                          if (parent) {
                            const customAvatar = generateCustomAvatar(creator);
                            // Replace img with custom avatar
                            const avatarContainer =
                              document.createElement("div");
                            avatarContainer.innerHTML =
                              customAvatar.props.children;
                            avatarContainer.className =
                              customAvatar.props.className;
                            parent.replaceChild(avatarContainer, target);
                          }
                        }}
                      />
                    ) : (
                      generateCustomAvatar(creator)
                    )}
                    {(creator.verified || creator.is_verified) && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                        <Check className="w-2.5 h-2.5 text-white" />
                      </div>
                    )}
                  </div>
                  <div className="ml-3">
                    <div
                      className={`font-medium ${
                        isDark ? "text-gray-200" : "text-gray-900"
                      }`}
                    >
                      {creator.name || creator.full_name || creator.username}
                    </div>
                    <div
                      className={`text-sm ${
                        isDark ? "text-gray-400" : "text-gray-500"
                      }`}
                    >
                      @{creator.username}
                    </div>
                  </div>
                </div>
              </td>
              <td className="py-4 px-4">
                <div className="flex items-center space-x-2">
                  {renderPlatformIcon(creator.platform || "")}
                </div>
              </td>
              <td className="py-4 px-4">
                <span
                  className={`font-medium ${
                    isDark ? "text-gray-200" : "text-gray-900"
                  }`}
                >
                  {creator.followers ? formatNumber(creator.followers) : "N/A"}
                </span>
              </td>
              <td className="py-4 px-4">
                {(() => {
                  // Debugging engagement_rate
                  // eslint-disable-next-line no-console
                  let rateNum: number | null = null;
                  if (typeof creator.engagement_rate === "number") {
                    rateNum = creator.engagement_rate;
                  } else if (
                    typeof creator.engagement_rate === "string" &&
                    creator.engagement_rate.trim() !== "" &&
                    !isNaN(Number(creator.engagement_rate))
                  ) {
                    rateNum = parseFloat(creator.engagement_rate);
                  }
                  if (rateNum !== null && !isNaN(rateNum)) {
                    return getEngagementBadge(rateNum);
                  } else {
                    return (
                      <span
                        className={`px-2 py-1 text-xs rounded-full ${
                          isDark
                            ? "bg-gray-700 text-gray-400"
                            : "bg-gray-100 text-gray-500"
                        }`}
                      >
                        {creator.engagement_rate
                          ? creator.engagement_rate
                          : "N/A"}
                      </span>
                    );
                  }
                })()}
                <div
                  className={`text-xs text-start mt-1 pl-4 ${
                    isDark ? "text-gray-400" : "text-gray-500"
                  }`}
                >
                  {/* {creator.engagement_rate}% */}
                </div>
              </td>

              <td className="py-4 px-4">
                <div className="flex items-center space-x-2">
                  {creator.category ? (
                    getCategoryIcon(creator.category)
                  ) : (
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${
                        isDark
                          ? "bg-gray-700 text-gray-400"
                          : "bg-gray-100 text-gray-500"
                      }`}
                    >
                      N/A
                    </span>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CreatorTableView;
