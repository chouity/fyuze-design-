import { useState } from "react";
import {
  // Plus,
  Users,
  // Star,
  // Lock,
  // MessageSquare,
  ChevronDown,
  ChevronRight,
  Menu,
  X,
  UserCheck,
  Briefcase,
  Heart,
  // Eye,
  Archive,
  // Settings,
  Search,
  Database,
} from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import CreatorsDashboard from "../../pages/CreatorDashboardPage";

const ResponsiveSidebar = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { isDark } = useTheme();
  type SectionId = "myLists";
  const [expandedSections, setExpandedSections] = useState<
    Record<SectionId, boolean>
  >({
    myLists: true,
  });
  const [activeItem, setActiveItem] = useState("creator-discovery");
  const [searchTerm, setSearchTerm] = useState("");

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleSection = (section: SectionId) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const handleItemClick = (itemId: string) => {
    setActiveItem(itemId);
    // On mobile, close sidebar after selection
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  };

  const sidebarItems = [
    // {
    //   id: "add-influencers",
    //   label: "Add Influencers",
    //   icon: Plus,
    //   type: "button",
    //   variant: "primary",
    // },
    {
      id: "creator-discovery",
      label: "Creator Discovery",
      icon: Database,
      type: "navigation",
      variant: "primary",
    },
    // {
    //   id: "all-influencers",
    //   label: "All Influencers",
    //   icon: Users,
    //   type: "navigation",
    //   count: 2847,
    // },
    // {
    //   id: "favorites",
    //   label: "Favorites",
    //   icon: Star,
    //   type: "navigation",
    //   count: 23,
    // },
    // {
    //   id: "report-unlocked",
    //   label: "Report Unlocked",
    //   icon: Lock,
    //   type: "navigation",
    //   count: 12,
    // },
    // {
    //   id: "unread",
    //   label: "Unread",
    //   icon: MessageSquare,
    //   type: "navigation",
    //   count: 5,
    // },
  ];

  const listSections = [
    {
      id: "myLists",
      label: "My Lists",
      items: [
        {
          id: "candidates",
          label: "Candidates",
          icon: UserCheck,
          count: 156,
          color: "bg-gray-500",
        },
        {
          id: "professionals",
          label: "Professionals",
          icon: Briefcase,
          count: 89,
          color: "bg-purple-500",
        },
        {
          id: "top-performers",
          label: "Top Performers",
          icon: Heart,
          count: 34,
          color: "bg-red-500",
        },
        {
          id: "archived",
          label: "Archived",
          icon: Archive,
          count: 67,
          color: "bg-yellow-500",
        },
      ],
    },
  ];

  const filteredItems = sidebarItems.filter((item) =>
    item.label.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div
        className={`p-6 border-b ${
          isDark ? "border-gray-700" : "border-gray-200"
        }`}
      >
        <div className="flex items-center justify-between mb-4">
          <h2
            className={`text-xl font-bold ${
              isDark ? "text-gray-200" : "text-gray-900"
            }`}
          >
            Dashboard
          </h2>
          <button
            onClick={toggleSidebar}
            className={`md:hidden p-2 rounded-lg transition-colors ${
              isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
            }`}
          >
            <X
              className={`w-5 h-5 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            />
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search
            className={`absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 ${
              isDark ? "text-gray-400" : "text-gray-400"
            }`}
          />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm ${
              isDark
                ? "border-gray-600 bg-gray-700 text-white placeholder-gray-400"
                : "border-gray-300 bg-white text-gray-900"
            }`}
          />
        </div>
      </div>

      {/* Main Navigation */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-2">
          {filteredItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeItem === item.id;

            if (item.type === "button") {
              return (
                <button
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  className={`w-full flex items-center px-4 py-3 rounded-lg font-medium transition-all duration-200 ${
                    item.variant === "primary"
                      ? "bg-orange-600 text-white hover:bg-orange-700 shadow-sm"
                      : isDark
                      ? "text-gray-300 hover:bg-gray-700"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <Icon className="w-5 h-5 mr-3" />
                  {item.label}
                </button>
              );
            }

            return (
              <button
                key={item.id}
                onClick={() => handleItemClick(item.id)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all duration-200 group ${
                  isActive
                    ? isDark
                      ? "bg-orange-900/30 text-orange-300 border border-orange-700"
                      : "bg-orange-50 text-orange-700 border border-orange-200"
                    : isDark
                    ? "text-gray-300 hover:bg-gray-700"
                    : "text-gray-700 hover:bg-gray-50"
                }`}
              >
                <div className="flex items-center">
                  <Icon
                    className={`w-5 h-5 mr-3 ${
                      isActive
                        ? "text-orange-400"
                        : isDark
                        ? "text-gray-400"
                        : "text-gray-500"
                    }`}
                  />
                  <span className="font-medium">{item.label}</span>
                </div>
                {/* {item.count && (
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-medium ${
                      isActive
                        ? isDark
                          ? "bg-orange-800 text-orange-200"
                          : "bg-orange-100 text-orange-700"
                        : isDark
                        ? "bg-gray-700 text-gray-300"
                        : "bg-gray-100 text-gray-600"
                    }`}
                  >
                    {item.count}
                  </span>
                )} */}
              </button>
            );
          })}
        </div>

        {/* Lists Section */}
        <div className="px-4 pb-4">
          {listSections.map((section) => (
            <div key={section.id} className="mb-4">
              <button
                onClick={() => toggleSection(section.id as SectionId)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-colors group ${
                  isDark
                    ? "text-gray-300 hover:bg-gray-700"
                    : "text-gray-700 hover:bg-gray-50"
                }`}
              >
                <div className="flex items-center">
                  {expandedSections[section.id as SectionId] ? (
                    <ChevronDown
                      className={`w-4 h-4 mr-2 ${
                        isDark ? "text-gray-400" : "text-gray-500"
                      }`}
                    />
                  ) : (
                    <ChevronRight
                      className={`w-4 h-4 mr-2 ${
                        isDark ? "text-gray-400" : "text-gray-500"
                      }`}
                    />
                  )}
                  <span className="font-medium text-sm">{section.label}</span>
                </div>
              </button>

              {/* Collapsible Content */}
              <div
                className={`transition-all duration-300 overflow-hidden ${
                  expandedSections[section.id as SectionId]
                    ? "max-h-96 opacity-100"
                    : "max-h-0 opacity-0"
                }`}
              >
                <div className="mt-2 space-y-1 ml-6">
                  {section.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeItem === item.id;

                    return (
                      <button
                        key={item.id}
                        onClick={() => handleItemClick(item.id)}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all duration-200 group ${
                          isActive
                            ? isDark
                              ? "bg-orange-900/30 text-orange-300 border border-orange-700"
                              : "bg-orange-50 text-orange-700 border border-orange-200"
                            : isDark
                            ? "text-gray-400 hover:bg-gray-700"
                            : "text-gray-600 hover:bg-gray-50"
                        }`}
                      >
                        <div className="flex items-center">
                          <div
                            className={`w-2 h-2 rounded-full mr-3 ${item.color}`}
                          ></div>
                          <Icon
                            className={`w-4 h-4 mr-2 ${
                              isActive
                                ? "text-orange-400"
                                : isDark
                                ? "text-gray-400"
                                : "text-gray-500"
                            }`}
                          />
                          <span className="text-sm font-medium">
                            {item.label}
                          </span>
                        </div>
                        {item.count && (
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${
                              isActive
                                ? isDark
                                  ? "bg-orange-800 text-orange-200"
                                  : "bg-orange-100 text-orange-700"
                                : isDark
                                ? "bg-gray-700 text-gray-300"
                                : "bg-gray-100 text-gray-600"
                            }`}
                          >
                            {item.count}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      {/* <div
        className={`p-4 border-t ${
          isDark ? "border-gray-700" : "border-gray-200"
        }`}
      >
        <button
          onClick={() => handleItemClick("settings")}
          className={`w-full flex items-center px-4 py-3 rounded-lg transition-all duration-200 ${
            activeItem === "settings"
              ? isDark
                ? "bg-orange-900/30 text-orange-300 border border-orange-700"
                : "bg-orange-50 text-orange-700 border border-orange-200"
              : isDark
              ? "text-gray-300 hover:bg-gray-700"
              : "text-gray-700 hover:bg-gray-50"
          }`}
        >
          <Settings
            className={`w-5 h-5 mr-3 ${
              activeItem === "settings"
                ? "text-orange-400"
                : isDark
                ? "text-gray-400"
                : "text-gray-500"
            }`}
          />
          <span className="font-medium">Settings</span>
        </button>

        <div
          className={`mt-4 p-3 rounded-lg border ${
            isDark
              ? "bg-gradient-to-r from-gray-800 to-gray-900 border-gray-700"
              : "bg-gradient-to-r from-orange-50 to-purple-50 border-orange-100"
          }`}
        >
          <div className="flex items-center">
            <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-purple-600 rounded-full flex items-center justify-center">
              <Eye className="w-4 h-4 text-white" />
            </div>
            <div className="ml-3">
              <p
                className={`text-sm font-medium ${
                  isDark ? "text-gray-200" : "text-gray-900"
                }`}
              >
                Upgrade Plan
              </p>
              <p
                className={`text-xs ${
                  isDark ? "text-gray-400" : "text-gray-600"
                }`}
              >
                Get unlimited access
              </p>
            </div>
          </div>
        </div>
      </div> */}
    </div>
  );

  return (
    <div className={`flex h-screen ${isDark ? "bg-gray-900" : "bg-gray-100"}`}>
      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-80 shadow-xl transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0 ${
          isDark ? "bg-gray-800" : "bg-white"
        } ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"}`}
      >
        <SidebarContent />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Mobile Header */}
        <div
          className={`md:hidden shadow-sm border-b p-4 ${
            isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
          }`}
        >
          <div className="flex items-center justify-between">
            <button
              onClick={toggleSidebar}
              className={`p-2 rounded-lg transition-colors ${
                isDark ? "hover:bg-gray-700" : "hover:bg-gray-100"
              }`}
            >
              <Menu
                className={`w-6 h-6 ${
                  isDark ? "text-gray-300" : "text-gray-700"
                }`}
              />
            </button>
            <h1
              className={`text-lg font-semibold ${
                isDark ? "text-gray-200" : "text-gray-900"
              }`}
            >
              Dashboard
            </h1>
            <div className="w-10"></div> {/* Spacer for centering */}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto">
          {/* Render Creator Discovery Dashboard */}
          {activeItem === "creator-discovery" ? (
            <CreatorsDashboard />
          ) : (
            <div className="p-6">
              <div className="max-w-4xl mx-auto">
                <div
                  className={`rounded-lg shadow-sm border p-8 ${
                    isDark
                      ? "bg-gray-800 border-gray-700"
                      : "bg-white border-gray-200"
                  }`}
                >
                  <h2
                    className={`text-2xl font-bold mb-4 ${
                      isDark ? "text-gray-200" : "text-gray-900"
                    }`}
                  >
                    {activeItem === "add-influencers" && "Add New Influencers"}
                    {activeItem === "all-influencers" && "All Influencers"}
                    {activeItem === "favorites" && "Favorite Influencers"}
                    {activeItem === "report-unlocked" && "Unlocked Reports"}
                    {activeItem === "unread" && "Unread Messages"}
                    {activeItem === "candidates" && "Candidate List"}
                    {activeItem === "professionals" && "Professional List"}
                    {activeItem === "top-performers" && "Top Performers"}
                    {activeItem === "archived" && "Archived Items"}
                    {activeItem === "settings" && "Settings"}
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3, 4, 5, 6].map((item) => (
                      <div
                        key={item}
                        className={`rounded-lg p-6 transition-colors ${
                          isDark
                            ? "bg-gray-700 hover:bg-gray-600"
                            : "bg-gray-50 hover:bg-gray-100"
                        }`}
                      >
                        <div
                          className={`w-full h-32 rounded-lg mb-4 flex items-center justify-center ${
                            isDark
                              ? "bg-gradient-to-br from-gray-600 to-gray-700"
                              : "bg-gradient-to-br from-orange-100 to-purple-100"
                          }`}
                        >
                          <Users
                            className={`w-12 h-12 ${
                              isDark ? "text-gray-300" : "text-orange-600"
                            }`}
                          />
                        </div>
                        <h3
                          className={`font-semibold mb-2 ${
                            isDark ? "text-gray-200" : "text-gray-900"
                          }`}
                        >
                          Content Item {item}
                        </h3>
                        <p
                          className={`text-sm ${
                            isDark ? "text-gray-400" : "text-gray-600"
                          }`}
                        >
                          Sample content for the selected{" "}
                          {activeItem.replace("-", " ")} section.
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResponsiveSidebar;
