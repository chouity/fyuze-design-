import React from "react";
import { Star, TrendingUp, MapPin } from "lucide-react";
import type { Creator } from "./CreatorTableView";
import { useTheme } from "../../contexts/ThemeContext";

export interface CreatorCardViewProps {
  creators: Creator[];
  formatNumber: (num: number) => string;
  dataSource?: "regular" | "ai_search";
}

interface ExtendedCreator extends Creator {
  bio?: string;
  is_active?: boolean;
  location?: string;
  rate_per_post?: number;
  rate_per_reel?: number;
  rate_per_story?: number;
}

export const CreatorCardView: React.FC<CreatorCardViewProps> = ({
  creators,
  formatNumber,
}) => {
  const { isDark } = useTheme();

  const handleCreatorClick = (creatorId: string) => {
    // Debug: Log the creator ID being opened
    console.log("CreatorCardView: Opening creator profile for ID:", creatorId);
    // Simply open creator profile in new tab
    window.open(`/creators/${creatorId}`, "_blank");
  };

  // Create a proxy URL for Instagram images to bypass CORS
  const getProxyImageUrl = (originalUrl: string, proxyIndex: number = 0) => {
    if (!originalUrl) return "/api/placeholder/300/300";

    // Try multiple CORS proxy services as fallbacks
    const proxyServices = [
      // Primary: Weserv.nl (fast and reliable)
      (url: string) =>
        `https://images.weserv.nl/?url=${encodeURIComponent(
          url
        )}&w=300&h=300&fit=cover`,
      // Fallback 1: AllOrigins (good alternative)
      (url: string) =>
        `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
      // Fallback 2: Cors-anywhere (requires headers, might be rate limited)
      (url: string) => `https://cors-anywhere.herokuapp.com/${url}`,
      // Fallback 3: Direct URL (will likely fail but worth trying)
      (url: string) => url,
    ];

    // Return the specified proxy service
    const selectedService =
      proxyServices[Math.min(proxyIndex, proxyServices.length - 1)];
    const result = selectedService(originalUrl);
    return result;
  };

  // Enhanced image URL handler with error recovery
  const getImageUrl = (originalUrl: string) => {
    if (!originalUrl) {
      return "/default-avatar.png";
    }

    // Try primary proxy first
    const proxyUrl = getProxyImageUrl(originalUrl, 0);
    return proxyUrl;
  };

  // Generate custom avatar with initials
  const generateCustomAvatar = (creator: Creator) => {
    const name = creator.name || creator.full_name || creator.username || "U";
    const initials = name
      .split(" ")
      .map((n) => n.charAt(0).toUpperCase())
      .slice(0, 2)
      .join("");

    // Generate a consistent color based on the creator's name
    const colors = [
      "bg-blue-500",
      "bg-green-500",
      "bg-purple-500",
      "bg-pink-500",
      "bg-indigo-500",
      "bg-red-500",
      "bg-yellow-500",
      "bg-teal-500",
      "bg-orange-500",
      "bg-cyan-500",
    ];
    const colorIndex =
      name.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0) %
      colors.length;
    const bgColor = colors[colorIndex];

    return (
      <div
        className={`w-10 h-10 md:w-12 md:h-12 rounded-full ${bgColor} flex items-center justify-center text-white font-semibold text-sm md:text-base`}
      >
        {initials}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
      {creators.map((creator) => {
        const extendedCreator = creator as ExtendedCreator;
        return (
          <div
            key={creator.id}
            onClick={() => {
              // Debug: Log the creator object being clicked
              console.log("CreatorCardView: Clicked creator:", creator);
              console.log("CreatorCardView: Creator ID:", creator.id);
              console.log(
                "CreatorCardView: Creator username:",
                creator.username
              );
              // Use username for the URL since it's more user-friendly
              const creatorIdentifier = creator.username || creator.id;
              console.log(
                "CreatorCardView: Using identifier:",
                creatorIdentifier
              );
              handleCreatorClick(creatorIdentifier);
            }}
            className={`rounded-lg p-4 md:p-6 hover:shadow-lg hover:scale-105 transition-all duration-200 cursor-pointer border ${
              isDark
                ? "bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700 hover:shadow-gray-700/50"
                : "bg-gradient-to-br from-white to-pink-50 border-pink-100"
            }`}
          >
            <div className="flex items-start justify-between mb-3 md:mb-4">
              <div className="flex items-center">
                {creator.avatar_url || creator.profile_pic_url ? (
                  <img
                    src={getImageUrl(
                      (creator.avatar_url || creator.profile_pic_url)!
                    )}
                    alt={creator.name}
                    className="w-10 h-10 md:w-12 md:h-12 rounded-full mr-2 md:mr-3 object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = "none";
                      const parent = target.parentElement;
                      if (parent) {
                        const customAvatar = generateCustomAvatar(creator);
                        // Replace img with custom avatar
                        const avatarContainer = document.createElement("div");
                        avatarContainer.innerHTML = customAvatar.props.children;
                        avatarContainer.className =
                          customAvatar.props.className;
                        parent.replaceChild(avatarContainer, target);
                      }
                    }}
                  />
                ) : (
                  <div className="mr-2 md:mr-3">
                    {generateCustomAvatar(creator)}
                  </div>
                )}
                <div>
                  <h3
                    className={`font-semibold flex items-center text-sm md:text-base ${
                      isDark ? "text-gray-200" : "text-gray-900"
                    }`}
                  >
                    {creator.name}
                    {creator.verified && (
                      <Star className="w-3 h-3 md:w-4 md:h-4 text-pink-500 ml-1 fill-current" />
                    )}
                  </h3>
                  <p
                    className={`text-xs md:text-sm ${
                      isDark ? "text-gray-400" : "text-gray-600"
                    }`}
                  >
                    {creator.username}
                  </p>
                </div>
              </div>
              {extendedCreator.is_active === false && (
                <span
                  className={`px-2 py-1 text-xs rounded-full ${
                    isDark
                      ? "bg-red-900/30 text-red-300"
                      : "bg-red-100 text-red-800"
                  }`}
                >
                  Inactive
                </span>
              )}
            </div>

            {extendedCreator.bio && (
              <p
                className={`text-xs md:text-sm mb-3 md:mb-4 line-clamp-2 ${
                  isDark ? "text-gray-300" : "text-gray-700"
                }`}
              >
                {extendedCreator.bio}
              </p>
            )}

            <div className="space-y-1.5 md:space-y-2">
              <div className="flex items-center justify-between text-xs md:text-sm">
                <span
                  className={`${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  Platform
                </span>
                <span
                  className={`capitalize font-medium px-2 py-1 rounded text-xs ${
                    isDark
                      ? "bg-gray-700 text-gray-200"
                      : "bg-gray-200 text-gray-800"
                  }`}
                >
                  {creator.platform}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs md:text-sm">
                <span
                  className={`${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  Category
                </span>
                <span
                  className={`font-medium text-xs ${
                    isDark ? "text-gray-200" : "text-gray-900"
                  }`}
                >
                  {creator.category}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs md:text-sm">
                <span
                  className={`${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  Followers
                </span>
                <span
                  className={`font-medium ${
                    isDark ? "text-gray-200" : "text-gray-900"
                  }`}
                >
                  {formatNumber(creator.followers || 0)}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs md:text-sm">
                <span
                  className={`${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  Engagement
                </span>
                <span
                  className={`font-medium flex items-center ${
                    isDark ? "text-gray-200" : "text-gray-900"
                  }`}
                >
                  <TrendingUp className="w-3 h-3 mr-1 text-green-500" />
                  {creator.engagement_rate}%
                </span>
              </div>

              {extendedCreator.location && (
                <div className="flex items-center justify-between text-xs md:text-sm">
                  <span
                    className={`flex items-center ${
                      isDark ? "text-gray-400" : "text-gray-600"
                    }`}
                  >
                    <MapPin className="w-3 h-3 mr-1" />
                    Location
                  </span>
                  <span
                    className={`font-medium text-xs ${
                      isDark ? "text-gray-200" : "text-gray-900"
                    }`}
                  >
                    {extendedCreator.location}
                  </span>
                </div>
              )}

              {/* Pricing Info */}
              {(extendedCreator.rate_per_post ||
                extendedCreator.rate_per_reel ||
                extendedCreator.rate_per_story) && (
                <div
                  className={`pt-2 mt-2 md:mt-3 ${
                    isDark
                      ? "border-t border-gray-700"
                      : "border-t border-gray-200"
                  }`}
                >
                  <p
                    className={`text-xs mb-1 md:mb-2 ${
                      isDark ? "text-gray-400" : "text-gray-600"
                    }`}
                  >
                    Rates (USD):
                  </p>
                  <div className="space-y-1">
                    {extendedCreator.rate_per_post && (
                      <div className="flex justify-between text-xs">
                        <span
                          className={`${
                            isDark ? "text-gray-300" : "text-gray-700"
                          }`}
                        >
                          Post:
                        </span>
                        <span
                          className={`font-medium ${
                            isDark ? "text-gray-200" : "text-gray-900"
                          }`}
                        >
                          ${extendedCreator.rate_per_post}
                        </span>
                      </div>
                    )}
                    {extendedCreator.rate_per_reel && (
                      <div className="flex justify-between text-xs">
                        <span
                          className={`${
                            isDark ? "text-gray-300" : "text-gray-700"
                          }`}
                        >
                          Reel:
                        </span>
                        <span
                          className={`font-medium ${
                            isDark ? "text-gray-200" : "text-gray-900"
                          }`}
                        >
                          ${extendedCreator.rate_per_reel}
                        </span>
                      </div>
                    )}
                    {extendedCreator.rate_per_story && (
                      <div className="flex justify-between text-xs">
                        <span
                          className={`${
                            isDark ? "text-gray-300" : "text-gray-700"
                          }`}
                        >
                          Story:
                        </span>
                        <span
                          className={`font-medium ${
                            isDark ? "text-gray-200" : "text-gray-900"
                          }`}
                        >
                          ${extendedCreator.rate_per_story}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Contact Info */}
              {creator.contact_email && (
                <div
                  className={`pt-2 mt-2 ${
                    isDark
                      ? "border-t border-gray-700"
                      : "border-t border-gray-200"
                  }`}
                >
                  <p
                    className={`text-xs truncate ${
                      isDark ? "text-pink-400" : "text-pink-600"
                    }`}
                  >
                    📧 {creator.contact_email}
                  </p>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default CreatorCardView;
