import React from "react";
import { Users, AlertCircle } from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import { CreatorTableView } from "./CreatorTableView";
import { CreatorCardView } from "./CreatorCardView";
import type { Creator } from "./CreatorTableView";

export interface CreatorResultsProps {
  loading: boolean;
  error: string | null;
  creators: Creator[];
  viewMode: "table" | "cards";
  formatNumber: (num: number) => string;
  dataSource?: "regular" | "ai_search";
}

export const CreatorResults: React.FC<CreatorResultsProps> = ({
  loading,
  error,
  creators,
  viewMode,
  formatNumber,
  dataSource,
}) => {
  const { isDark } = useTheme();
  if (loading) {
    return null; // Loading handled by ResultsHeader
  }

  if (error) {
    return (
      <div className="p-4 md:p-6">
        <div
          className={`flex items-center justify-center text-sm md:text-base ${
            isDark ? "text-red-400" : "text-red-600"
          }`}
        >
          <AlertCircle className="w-4 h-4 md:w-5 md:h-5 mr-2" />
          <span>{error}</span>
        </div>
      </div>
    );
  }

  if (creators.length === 0) {
    return (
      <div className="p-4 md:p-6">
        <div className="text-center py-8 md:py-12">
          <Users
            className={`w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 ${
              isDark ? "text-gray-400" : "text-gray-300"
            }`}
          />
          <h3
            className={`font-medium mb-2 text-base md:text-lg ${
              isDark ? "text-gray-200" : "text-gray-900"
            }`}
          >
            No creators found
          </h3>
          <p
            className={`text-sm md:text-base ${
              isDark ? "text-gray-400" : "text-gray-600"
            }`}
          >
            Try adjusting your filters to see more results
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`p-4 md:p-6 

      ${
        isDark
          ? "bg-gradient-to-br from-gray-800/95 via-gray-900/95 to-purple-900/95 backdrop-blur-xl border-gray-700/50 text-white"
          : "bg-gradient-to-br from-white/95 via-orange-50/95 to-red-50/95 backdrop-blur-xl border-orange-200/50 text-gray-900"
      }`}
    >
      {/* Mobile: Always show cards, Desktop: Respect viewMode */}
      <div className="block md:hidden">
        <CreatorCardView
          creators={creators}
          formatNumber={formatNumber}
          dataSource={dataSource}
        />
      </div>
      <div className="hidden md:block">
        {viewMode === "table" ? (
          <CreatorTableView
            creators={creators}
            formatNumber={formatNumber}
            dataSource={dataSource}
          />
        ) : (
          <CreatorCardView
            creators={creators}
            formatNumber={formatNumber}
            dataSource={dataSource}
          />
        )}
      </div>
    </div>
  );
};

export default CreatorResults;
