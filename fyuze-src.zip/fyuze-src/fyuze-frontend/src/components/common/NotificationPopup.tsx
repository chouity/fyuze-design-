import React from "react";
import { X } from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";

export interface NotificationButton {
  label: string;
  onClick: () => void;
  variant?: "primary" | "secondary" | "danger" | "success" | "warning";
  color?: string; // Custom color override
  disabled?: boolean;
}

interface NotificationPopupProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
  buttons: NotificationButton[];
  type?: "info" | "success" | "warning" | "error";
  showCloseButton?: boolean;
  closeOnBackdropClick?: boolean;
}

const getButtonStyles = (
  variant: string,
  customColor?: string,
  isDark?: boolean
) => {
  if (customColor) {
    return `bg-${customColor}-600 hover:bg-${customColor}-700 text-white border-${customColor}-600 hover:border-${customColor}-700`;
  }

  switch (variant) {
    case "primary":
      return isDark
        ? "bg-blue-600 hover:bg-blue-700 text-white border-blue-600 hover:border-blue-700"
        : "bg-blue-600 hover:bg-blue-700 text-white border-blue-600 hover:border-blue-700";
    case "secondary":
      return isDark
        ? "bg-gray-600 hover:bg-gray-700 text-white border-gray-600 hover:border-gray-700"
        : "bg-gray-200 hover:bg-gray-300 text-gray-900 border-gray-200 hover:border-gray-300";
    case "danger":
      return "bg-red-600 hover:bg-red-700 text-white border-red-600 hover:border-red-700";
    case "success":
      return "bg-green-600 hover:bg-green-700 text-white border-green-600 hover:border-green-700";
    case "warning":
      return "bg-yellow-600 hover:bg-yellow-700 text-white border-yellow-600 hover:border-yellow-700";
    default:
      return isDark
        ? "bg-gray-600 hover:bg-gray-700 text-white border-gray-600 hover:border-gray-700"
        : "bg-gray-200 hover:bg-gray-300 text-gray-900 border-gray-200 hover:border-gray-300";
  }
};

const getTypeStyles = (type: string, isDark?: boolean) => {
  switch (type) {
    case "success":
      return {
        background: isDark
          ? "bg-green-900/20 border-green-700/50"
          : "bg-green-50 border-green-200",
        icon: "text-green-600",
        title: isDark ? "text-green-400" : "text-green-800",
      };
    case "warning":
      return {
        background: isDark
          ? "bg-yellow-900/20 border-yellow-700/50"
          : "bg-yellow-50 border-yellow-200",
        icon: "text-yellow-600",
        title: isDark ? "text-yellow-400" : "text-yellow-800",
      };
    case "error":
      return {
        background: isDark
          ? "bg-red-900/20 border-red-700/50"
          : "bg-red-50 border-red-200",
        icon: "text-red-600",
        title: isDark ? "text-red-400" : "text-red-800",
      };
    default: // info
      return {
        background: isDark
          ? "bg-blue-900/20 border-blue-700/50"
          : "bg-blue-50 border-blue-200",
        icon: "text-blue-600",
        title: isDark ? "text-blue-400" : "text-blue-800",
      };
  }
};

export const NotificationPopup: React.FC<NotificationPopupProps> = ({
  isOpen,
  onClose,
  title,
  message,
  buttons,
  type = "info",
  showCloseButton = true,
  closeOnBackdropClick = true,
}) => {
  const { isDark } = useTheme();

  if (!isOpen) return null;

  const typeStyles = getTypeStyles(type, isDark);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget && closeOnBackdropClick) {
      onClose();
    }
  };

  const handleButtonClick = (button: NotificationButton) => {
    if (!button.disabled) {
      button.onClick();
    }
  };

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm z-[100000000000000000]"
      onClick={handleBackdropClick}
    >
      <div
        className={`relative w-full max-w-md mx-auto rounded-2xl shadow-2xl border backdrop-blur-sm transform transition-all duration-300 scale-100 ${
          isDark
            ? "bg-gray-800/95 border-gray-700/50"
            : "bg-white/95 border-gray-200/50"
        } ${typeStyles.background}`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        {showCloseButton && (
          <button
            onClick={onClose}
            className={`absolute top-4 right-4 p-2 rounded-lg transition-colors cursor-pointer ${
              isDark
                ? "hover:bg-gray-700/50 text-gray-400 hover:text-gray-200"
                : "hover:bg-gray-100/50 text-gray-500 hover:text-gray-700"
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Content */}
        <div className="p-6 pb-4">
          {/* Title */}
          <h3 className={`text-xl font-semibold mb-3 pr-8 ${typeStyles.title}`}>
            {title}
          </h3>

          {/* Message */}
          <p
            className={`text-sm leading-relaxed mb-6 ${
              isDark ? "text-gray-300" : "text-gray-600"
            }`}
          >
            {message}
          </p>
        </div>

        {/* Buttons */}
        {buttons.length > 0 && (
          <div className="flex flex-col sm:flex-row gap-3 p-6 pt-0">
            {buttons.map((button, index) => (
              <button
                key={index}
                onClick={() => handleButtonClick(button)}
                disabled={button.disabled}
                className={`px-4 py-3 rounded-xl font-medium transition-all duration-200 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 border disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none ${getButtonStyles(
                  button.variant || "secondary",
                  button.color,
                  isDark
                )} ${
                  isDark
                    ? "focus:ring-offset-gray-800"
                    : "focus:ring-offset-white"
                }`}
              >
                {button.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Hook for easier usage
export const useNotificationPopup = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [config, setConfig] = React.useState<{
    title: string;
    message: string;
    buttons: NotificationButton[];
    type?: "info" | "success" | "warning" | "error";
    showCloseButton?: boolean;
    closeOnBackdropClick?: boolean;
  }>({
    title: "",
    message: "",
    buttons: [],
  });

  const showNotification = (newConfig: typeof config) => {
    setConfig(newConfig);
    setIsOpen(true);
  };

  const hideNotification = () => {
    setIsOpen(false);
  };

  return {
    isOpen,
    config,
    showNotification,
    hideNotification,
    NotificationPopup: (
      <NotificationPopup
        isOpen={isOpen}
        onClose={hideNotification}
        {...config}
      />
    ),
  };
};
