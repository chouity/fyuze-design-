import { useToastNotification } from "../../hooks/useToastNotification";

export function ToastTestButton() {
  const toast = useToastNotification();

  const testToasts = () => {
    toast.success("Success! This is a success message");
    setTimeout(() => toast.error("Error! This is an error message"), 1000);
    setTimeout(() => toast.warning("Warning! This is a warning message"), 2000);
    setTimeout(() => toast.info("Info! This is an info message"), 3000);
  };

  const testCreditError = () => {
    // toast.error(
    //   "No credits available. Please upgrade your subscription to continue."
    // );
  };

  return (
    <div className="fixed bottom-4 left-4 space-y-2 z-50">
      <button
        onClick={testToasts}
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
      >
        Test All Toasts
      </button>
      <br />
      <button
        onClick={testCreditError}
        className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
      >
        Test Credit Error
      </button>
    </div>
  );
}

export default ToastTestButton;
