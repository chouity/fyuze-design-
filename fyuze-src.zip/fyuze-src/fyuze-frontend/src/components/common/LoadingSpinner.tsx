import React from "react";
import { useTheme } from "../../contexts/ThemeContext";

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg" | "xl";
  text?: string;
  fullScreen?: boolean;
  className?: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({
  size = "md",
  text,
  fullScreen = false,
  className = "",
}) => {
  const { isDark } = useTheme();

  const getSizeClasses = () => {
    switch (size) {
      case "sm":
        return "h-4 w-4 border-2";
      case "md":
        return "h-8 w-8 border-2";
      case "lg":
        return "h-12 w-12 border-b-2";
      case "xl":
        return "h-16 w-16 border-b-2";
      default:
        return "h-8 w-8 border-2";
    }
  };

  const getColorClasses = () => {
    if (isDark) {
      return size === "sm" || size === "md"
        ? "border-gray-600 border-t-blue-400"
        : "border-blue-400";
    } else {
      return size === "sm" || size === "md"
        ? "border-gray-300 border-t-blue-600"
        : "border-blue-600";
    }
  };

  const spinner = (
    <div
      className={`animate-spin rounded-full ${getSizeClasses()} ${getColorClasses()} ${className}`}
    />
  );

  if (fullScreen) {
    return (
      <div
        className={`flex items-center justify-center min-h-screen ${
          isDark ? "bg-gray-900" : "bg-gray-50"
        }`}
      >
        <div className="flex flex-col items-center space-y-4">
          {spinner}
          {text && (
            <p
              className={`text-sm ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              {text}
            </p>
          )}
        </div>
      </div>
    );
  }

  if (text) {
    return (
      <div className="flex items-center space-x-2">
        {spinner}
        <span
          className={`text-sm ${isDark ? "text-gray-300" : "text-gray-600"}`}
        >
          {text}
        </span>
      </div>
    );
  }

  return spinner;
};

// Inline loading component for buttons
export const ButtonLoadingSpinner: React.FC<{ size?: "sm" | "md" }> = ({
  size = "sm",
}) => {
  const sizeClass = size === "sm" ? "w-4 h-4" : "w-5 h-5";
  return (
    <div
      className={`${sizeClass} border-2 border-white/30 border-t-white rounded-full animate-spin`}
    />
  );
};

export default LoadingSpinner;
