import { useEffect } from "react";
import { useToast } from "../../contexts/ToastContext";
import { initializeGlobalErrorHandler } from "../../lib/globalErrorHandler";

export function MiddlewareInitializer() {
  const { showToast } = useToast();

  useEffect(() => {
    // Initialize the global error handler with the toast function
    initializeGlobalErrorHandler(showToast);
    console.log("Global error handler initialized");
  }, [showToast]);

  return null; // This component doesn't render anything
}

export default MiddlewareInitializer;
