import React from "react";
import { Check, Sparkles } from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";

interface SubscriptionSuccessProps {
  planName: string;
  credits: number;
  onContinue: () => void;
}

const SubscriptionSuccess: React.FC<SubscriptionSuccessProps> = ({
  planName,
  credits,
  onContinue,
}) => {
  const { theme } = useTheme();
  const isDark = theme === "dark";

  return (
    <div
      className={`min-h-screen transition-all duration-500 ${
        isDark
          ? "bg-gradient-to-br from-gray-900 to-purple-900"
          : "bg-gradient-to-br from-orange-50 to-red-50"
      } flex items-center justify-center p-4`}
    >
      <div
        className={`rounded-3xl shadow-2xl p-8 max-w-md w-full text-center ${
          isDark
            ? "bg-gray-900/80 backdrop-blur-xl border border-gray-700/50"
            : "bg-white/80 backdrop-blur-xl border border-white/50"
        }`}
      >
        {/* Success Icon */}
        <div className="mb-6">
          <div className="relative mx-auto w-20 h-20 mb-4">
            <div
              className={`absolute inset-0 rounded-full ${
                isDark ? "bg-green-400/20" : "bg-green-500/20"
              } animate-ping`}
            ></div>
            <div
              className={`relative rounded-full w-20 h-20 flex items-center justify-center ${
                isDark ? "bg-green-400/10" : "bg-green-500/10"
              }`}
            >
              <Check
                className={`w-8 h-8 ${
                  isDark ? "text-green-400" : "text-green-500"
                }`}
              />
            </div>
          </div>
        </div>

        {/* Success Message */}
        <div className="mb-8">
          <h2
            className={`text-2xl font-bold mb-3 ${
              isDark ? "text-white" : "text-gray-800"
            }`}
          >
            Subscription Activated!
          </h2>
          <p className={`${isDark ? "text-gray-300" : "text-gray-600"} mb-4`}>
            Welcome to{" "}
            <span className="font-semibold text-orange-500">{planName}</span>
          </p>

          {/* Credits Info */}
          <div
            className={`inline-flex items-center px-4 py-2 rounded-xl ${
              isDark ? "bg-orange-500/10" : "bg-orange-50"
            } mb-6`}
          >
            <Sparkles
              className={`w-5 h-5 mr-2 ${
                isDark ? "text-orange-400" : "text-orange-500"
              }`}
            />
            <span
              className={`font-semibold ${
                isDark ? "text-orange-400" : "text-orange-600"
              }`}
            >
              {credits.toLocaleString()} credits added
            </span>
          </div>

          <p
            className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}
          >
            You're all set to start finding amazing influencers!
          </p>
        </div>

        {/* Continue Button */}
        <button
          onClick={onContinue}
          className="w-full py-4 px-6 rounded-xl font-bold text-white transition-all duration-300 transform hover:scale-[1.02] focus:ring-4 focus:ring-orange-500/50 bg-orange-600 hover:bg-orange-700 shadow-xl hover:shadow-2xl"
        >
          Continue to Dashboard
        </button>
      </div>
    </div>
  );
};

export default SubscriptionSuccess;
