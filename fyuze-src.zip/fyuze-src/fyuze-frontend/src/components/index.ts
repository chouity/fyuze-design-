// Core components (always loaded)
export { default as LocationSelector } from "./influencerCard/LocationSelector";
export { default as ProfileAvatar } from "./influencerCard/ProfileAvatar";
export { default as InfluencerCard } from "./influencerCard/InfluencerCard";
export { default as InfluencerGrid } from "./influencerCard/InfluencerGrid";
export { default as InfluencerHeader } from "./influencerCard/InfluencerHeader";
export { default as LoadingMessage } from "./influencerCard/LoadingMessage";
export { default as SuggestionButtons } from "./chatInterface/SuggestionButtons";
export { default as MessageAvatar } from "./influencerCard/MessageAvatar";
export { default as MessageActions } from "./influencerCard/MessageActions";
export { default as EditableMessage } from "./chatInterface/EditableMessage";
export { default as MessageContent } from "./influencerCard/MessageContent";
export { default as ChatInputArea } from "./chatInterface/ChatInputArea";

// Profile components (platform-agnostic)
export * from "./profile";

// Remove these from barrel exports to allow proper code splitting:
// - ChatBackground (used in multiple places)
// - ChatHeader (used in multiple places)
