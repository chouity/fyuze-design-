/**
 * PROFILE POSTS COMPONENT
 *
 * Platform-agnostic posts grid display for creator content.
 * Handles different media types (video, image, carousel) dynamically.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import React from "react";
import { useTheme } from "../../contexts/ThemeContext";
import type {
  PlatformCreatorProfile,
  PlatformPost,
} from "../../types/platform.types";
import {
  Heart,
  MessageCircle,
  Eye,
  Play,
  Image as ImageIcon,
} from "lucide-react";

interface ProfilePostsProps {
  profile: PlatformCreatorProfile;
  onPostClick?: (post: PlatformPost) => void;
}

const formatNumber = (num: number | undefined | null) => {
  if (!num || typeof num !== "number" || isNaN(num)) return "0";
  if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
  if (num >= 1000) return (num / 1000).toFixed(1) + "K";
  return num.toString();
};

const PostCard: React.FC<{
  post: PlatformPost;
  isDark: boolean;
  onClick?: () => void;
}> = ({ post, isDark, onClick }) => {
  return (
    <div
      className={`relative group rounded-lg overflow-hidden shadow-md transition-transform duration-200 hover:scale-105 ${
        isDark
          ? "bg-gray-800 border border-gray-700"
          : "bg-white border border-gray-200"
      } ${onClick ? "cursor-pointer" : ""}`}
      onClick={onClick}
    >
      {/* Media Display */}
      <div className="relative aspect-square">
        {post.thumbnail ? (
          <img
            src={post.thumbnail}
            alt="Post"
            className="w-full h-full object-cover"
            onError={(e) => {
              // Fallback for broken images
              e.currentTarget.style.display = "none";
            }}
          />
        ) : (
          <div
            className={`w-full h-full flex items-center justify-center ${
              isDark ? "bg-gray-700" : "bg-gray-100"
            }`}
          >
            {post.type === "video" ? (
              <Play className="w-12 h-12 text-gray-400" />
            ) : (
              <ImageIcon className="w-12 h-12 text-gray-400" />
            )}
          </div>
        )}

        {/* Media Type Indicator */}
        {post.type === "video" && (
          <div className="absolute top-2 right-2">
            <Play className="w-4 h-4 text-white drop-shadow-lg" />
          </div>
        )}

        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
          <div className="flex items-center gap-4 text-white">
            <div className="flex items-center gap-1">
              <Heart className="w-4 h-4" />
              <span className="text-sm">{formatNumber(post.likes)}</span>
            </div>
            <div className="flex items-center gap-1">
              <MessageCircle className="w-4 h-4" />
              <span className="text-sm">{formatNumber(post.comments)}</span>
            </div>
            {post.views && (
              <div className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                <span className="text-sm">{formatNumber(post.views)}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Post Content */}
      {post.caption && (
        <div className="p-3">
          <p
            className={`text-sm line-clamp-2 ${
              isDark ? "text-gray-300" : "text-gray-600"
            }`}
          >
            {post.caption}
          </p>
        </div>
      )}
    </div>
  );
};

export const ProfilePosts: React.FC<ProfilePostsProps> = ({
  profile,
  onPostClick,
}) => {
  const { isDark } = useTheme();

  const posts = profile.posts || [];

  if (posts.length === 0) {
    return (
      <div
        className={`p-8 rounded-xl text-center ${
          isDark
            ? "bg-gray-800 border border-gray-700"
            : "bg-white border border-gray-200"
        } shadow-lg`}
      >
        <ImageIcon className="w-12 h-12 mx-auto mb-4 text-gray-400" />
        <h3
          className={`text-lg font-semibold mb-2 ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          No Posts Available
        </h3>
        <p className={`${isDark ? "text-gray-400" : "text-gray-600"}`}>
          This creator hasn't posted any content yet.
        </p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2
          className={`text-xl font-bold ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          Recent Posts
        </h2>
        <span
          className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}
        >
          {posts.length} posts
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {posts.map((post, index) => (
          <PostCard
            key={post.id || `post-${index}`}
            post={post}
            isDark={isDark}
            onClick={onPostClick ? () => onPostClick(post) : undefined}
          />
        ))}
      </div>
    </div>
  );
};
