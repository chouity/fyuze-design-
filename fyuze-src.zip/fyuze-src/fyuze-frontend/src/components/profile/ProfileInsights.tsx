/**
 * PROFILE INSIGHTS COMPONENT
 *
 * Platform-agnostic insights and analytics display for creator performance.
 * Shows engagement analytics, best performing content, and growth metrics.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import React from "react";
import { useTheme } from "../../contexts/ThemeContext";
import type { PlatformCreatorProfile } from "../../types/platform.types";
import {
  TrendingUp,
  Award,
  BarChart3,
  Target,
  Calendar,
  Clock,
} from "lucide-react";

interface ProfileInsightsProps {
  profile: PlatformCreatorProfile;
}

const formatNumber = (num: number | undefined | null) => {
  if (!num || typeof num !== "number" || isNaN(num)) return "0";
  if (num >= 1000000) return (num / 1000000).toFixed(1) + "M";
  if (num >= 1000) return (num / 1000).toFixed(1) + "K";
  return num.toString();
};

const InsightCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  value: string;
  description: string;
  isDark: boolean;
}> = ({ icon, title, value, description, isDark }) => {
  return (
    <div
      className={`p-4 rounded-xl ${
        isDark
          ? "bg-gray-800 border border-gray-700"
          : "bg-white border border-gray-200"
      } shadow-lg`}
    >
      <div className="flex items-center gap-3 mb-3">
        {icon}
        <h3
          className={`font-semibold ${isDark ? "text-white" : "text-gray-900"}`}
        >
          {title}
        </h3>
      </div>
      <div
        className={`text-2xl font-bold mb-1 ${
          isDark ? "text-white" : "text-gray-900"
        }`}
      >
        {value}
      </div>
      <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>
        {description}
      </p>
    </div>
  );
};

export const ProfileInsights: React.FC<ProfileInsightsProps> = ({
  profile,
}) => {
  const { isDark } = useTheme();

  // Calculate insights from profile data
  const avgLikes = React.useMemo(() => {
    if (!profile.posts || profile.posts.length === 0) return 0;
    const totalLikes = profile.posts.reduce(
      (sum, post) => sum + (post.likes || 0),
      0
    );
    return Math.round(totalLikes / profile.posts.length);
  }, [profile.posts]);

  const avgComments = React.useMemo(() => {
    if (!profile.posts || profile.posts.length === 0) return 0;
    const totalComments = profile.posts.reduce(
      (sum, post) => sum + (post.comments || 0),
      0
    );
    return Math.round(totalComments / profile.posts.length);
  }, [profile.posts]);

  const bestPost = React.useMemo(() => {
    if (!profile.posts || profile.posts.length === 0) return null;
    return profile.posts.reduce((best, current) => {
      const currentEngagement =
        (current.likes || 0) + (current.comments || 0) + (current.shares || 0);
      const bestEngagement =
        (best.likes || 0) + (best.comments || 0) + (best.shares || 0);
      return currentEngagement > bestEngagement ? current : best;
    });
  }, [profile.posts]);

  const videoPostsCount = React.useMemo(() => {
    if (!profile.posts) return 0;
    return profile.posts.filter((post) => post.type === "video").length;
  }, [profile.posts]);

  const videoPercentage = React.useMemo(() => {
    if (!profile.posts || profile.posts.length === 0) return 0;
    return Math.round((videoPostsCount / profile.posts.length) * 100);
  }, [profile.posts, videoPostsCount]);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <BarChart3 className="w-6 h-6 text-blue-500" />
        <h2
          className={`text-xl font-bold ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          Creator Insights
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <InsightCard
          icon={<TrendingUp className="w-5 h-5 text-green-500" />}
          title="Engagement Rate"
          value={`${profile.engagementRate?.toFixed(1) || 0}%`}
          description="Average engagement across all posts"
          isDark={isDark}
        />

        <InsightCard
          icon={<Award className="w-5 h-5 text-yellow-500" />}
          title="Avg. Likes per Post"
          value={formatNumber(avgLikes)}
          description="Average likes received per post"
          isDark={isDark}
        />

        <InsightCard
          icon={<Target className="w-5 h-5 text-purple-500" />}
          title="Avg. Comments"
          value={formatNumber(avgComments)}
          description="Average comments per post"
          isDark={isDark}
        />

        <InsightCard
          icon={<Calendar className="w-5 h-5 text-blue-500" />}
          title="Content Mix"
          value={`${videoPercentage}%`}
          description={`${videoPostsCount} videos out of ${profile.postsCount} posts`}
          isDark={isDark}
        />

        <InsightCard
          icon={<Clock className="w-5 h-5 text-orange-500" />}
          title="Platform"
          value={profile.platform.toUpperCase()}
          description={`Data from ${profile.dataSource.replace("_", " ")}`}
          isDark={isDark}
        />

        {bestPost && (
          <InsightCard
            icon={<Award className="w-5 h-5 text-red-500" />}
            title="Best Post"
            value={formatNumber(
              (bestPost.likes || 0) + (bestPost.comments || 0)
            )}
            description="Highest engagement single post"
            isDark={isDark}
          />
        )}
      </div>

      {/* Best Post Preview */}
      {bestPost && (
        <div
          className={`p-6 rounded-xl ${
            isDark
              ? "bg-gray-800 border border-gray-700"
              : "bg-white border border-gray-200"
          } shadow-lg`}
        >
          <h3
            className={`text-lg font-semibold mb-4 ${
              isDark ? "text-white" : "text-gray-900"
            }`}
          >
            🏆 Best Performing Post
          </h3>
          <div className="flex flex-col md:flex-row gap-4">
            {bestPost.thumbnail && (
              <div className="flex-shrink-0">
                <img
                  src={bestPost.thumbnail}
                  alt="Best post"
                  className="w-32 h-32 object-cover rounded-lg"
                  onError={(e) => {
                    e.currentTarget.style.display = "none";
                  }}
                />
              </div>
            )}
            <div className="flex-grow">
              {bestPost.caption && (
                <p
                  className={`text-sm mb-3 line-clamp-3 ${
                    isDark ? "text-gray-300" : "text-gray-600"
                  }`}
                >
                  {bestPost.caption}
                </p>
              )}
              <div className="flex gap-4 text-sm">
                <span
                  className={`${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  ❤️ {formatNumber(bestPost.likes)} likes
                </span>
                <span
                  className={`${isDark ? "text-gray-400" : "text-gray-600"}`}
                >
                  💬 {formatNumber(bestPost.comments)} comments
                </span>
                {bestPost.views && (
                  <span
                    className={`${isDark ? "text-gray-400" : "text-gray-600"}`}
                  >
                    👁️ {formatNumber(bestPost.views)} views
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Additional Analytics */}
      <div
        className={`p-6 rounded-xl ${
          isDark
            ? "bg-gray-800 border border-gray-700"
            : "bg-white border border-gray-200"
        } shadow-lg`}
      >
        <h3
          className={`text-lg font-semibold mb-4 ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          📊 Quick Analytics
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <div
              className={`text-2xl font-bold ${
                isDark ? "text-blue-400" : "text-blue-600"
              }`}
            >
              {formatNumber(profile.followers)}
            </div>
            <div
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              Total Followers
            </div>
          </div>
          <div>
            <div
              className={`text-2xl font-bold ${
                isDark ? "text-green-400" : "text-green-600"
              }`}
            >
              {profile.postsCount}
            </div>
            <div
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              Total Posts
            </div>
          </div>
          <div>
            <div
              className={`text-2xl font-bold ${
                isDark ? "text-purple-400" : "text-purple-600"
              }`}
            >
              {formatNumber(profile.following)}
            </div>
            <div
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              Following
            </div>
          </div>
          <div>
            <div
              className={`text-2xl font-bold ${
                isDark ? "text-orange-400" : "text-orange-600"
              }`}
            >
              {profile.engagementRate?.toFixed(1) || 0}%
            </div>
            <div
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              Engagement
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
