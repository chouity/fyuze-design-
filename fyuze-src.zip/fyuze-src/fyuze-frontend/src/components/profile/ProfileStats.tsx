/**
 * PROFILE STATS COMPONENT
 *
 * Platform-agnostic stats display for creator metrics.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import React from "react";
import { useTheme } from "../../contexts/ThemeContext";
import type { PlatformCreatorProfile } from "../../types/platform.types";
import { Users, TrendingUp, Calendar, UserPlus } from "lucide-react";

interface ProfileStatsProps {
  profile: PlatformCreatorProfile;
}

const formatNumber = (num: number | undefined | null) => {
  if (!num || typeof num !== "number" || isNaN(num)) return "0";
  if (num >= 1000000) return (num / 1000000).toFixed(2) + "M";
  if (num >= 1000) return (num / 1000).toFixed(2) + "K";
  return num.toFixed(0);
};

export const ProfileStats: React.FC<ProfileStatsProps> = ({ profile }) => {
  const { isDark } = useTheme();

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div
        className={`p-4 rounded-xl ${
          isDark
            ? "bg-gray-800 border border-gray-700"
            : "bg-white border border-gray-200"
        } shadow-lg`}
      >
        <div className="flex items-center gap-2 mb-2">
          <Users className="w-5 h-5 text-blue-500" />
          <span
            className={`text-sm font-medium ${
              isDark ? "text-gray-400" : "text-gray-600"
            }`}
          >
            Followers
          </span>
        </div>
        <div
          className={`text-2xl font-bold ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          {formatNumber(profile.followers)}
        </div>
      </div>

      <div
        className={`p-4 rounded-xl ${
          isDark
            ? "bg-gray-800 border border-gray-700"
            : "bg-white border border-gray-200"
        } shadow-lg`}
      >
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp className="w-5 h-5 text-green-500" />
          <span
            className={`text-sm font-medium ${
              isDark ? "text-gray-400" : "text-gray-600"
            }`}
          >
            Engagement
          </span>
        </div>
        <div
          className={`text-2xl font-bold ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          {profile.engagementRate && typeof profile.engagementRate === "number"
            ? profile.engagementRate.toFixed(1)
            : "N/A"}
          %
        </div>
      </div>

      <div
        className={`p-4 rounded-xl ${
          isDark
            ? "bg-gray-800 border border-gray-700"
            : "bg-white border border-gray-200"
        } shadow-lg`}
      >
        <div className="flex items-center gap-2 mb-2">
          <Calendar className="w-5 h-5 text-purple-500" />
          <span
            className={`text-sm font-medium ${
              isDark ? "text-gray-400" : "text-gray-600"
            }`}
          >
            Posts
          </span>
        </div>
        <div
          className={`text-2xl font-bold ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          {formatNumber(profile.postsCount)}
        </div>
      </div>

      <div
        className={`p-4 rounded-xl ${
          isDark
            ? "bg-gray-800 border border-gray-700"
            : "bg-white border border-gray-200"
        } shadow-lg`}
      >
        <div className="flex items-center gap-2 mb-2">
          <UserPlus className="w-5 h-5 text-blue-500" />
          <span
            className={`text-sm font-medium ${
              isDark ? "text-gray-400" : "text-gray-600"
            }`}
          >
            Following
          </span>
        </div>
        <div
          className={`text-2xl font-bold ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          {formatNumber(profile.following)}
        </div>
      </div>
    </div>
  );
};
