/**
 * PROFILE HEADER COMPONENT
 *
 * Platform-agnostic profile header that displays creator information
 * using the standardized PlatformCreatorProfile interface.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import React from "react";
import { useTheme } from "../../contexts/ThemeContext";
import type { PlatformCreatorProfile } from "../../types/platform.types";
import { getPlatformConfig } from "../../config/platforms";
import { MapPin, Mail, ExternalLink, Verified } from "lucide-react";

interface ProfileHeaderProps {
  profile: PlatformCreatorProfile;
}

export const ProfileHeader: React.FC<ProfileHeaderProps> = ({ profile }) => {
  const { isDark } = useTheme();
  const platformConfig = getPlatformConfig(profile.platform);

  return (
    <div className="relative">
      {/* Background Gradient */}
      <div
        className={`absolute inset-0 rounded-3xl ${
          isDark
            ? "bg-gradient-to-br from-purple-900/20 via-pink-900/20 to-blue-900/20"
            : "bg-gradient-to-br from-purple-100/50 via-pink-100/50 to-blue-100/50"
        }`}
      />

      {/* Profile Card */}
      <div
        className={`relative p-8 rounded-3xl backdrop-blur-sm ${
          isDark
            ? "bg-gray-900/80 border border-gray-700/50"
            : "bg-white/80 border border-gray-200/50"
        } shadow-2xl`}
      >
        {/* Profile Picture - Top Center */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative group">
            <div
              className={`absolute inset-0 rounded-full blur-xl ${
                isDark
                  ? "bg-gradient-to-r from-purple-500/30 to-pink-500/30"
                  : "bg-gradient-to-r from-purple-300/30 to-pink-300/30"
              } group-hover:blur-2xl transition-all duration-500`}
            />
            <img
              src={profile.avatarUrl || "/api/placeholder/128/128"}
              alt={profile.displayName || profile.username}
              className="relative w-32 h-32 rounded-full object-cover shadow-2xl ring-4 ring-white/20 group-hover:scale-105 transition-transform duration-300"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = "/api/placeholder/128/128";
              }}
            />
            <div
              className={`absolute inset-0 rounded-full ring-2 ${
                isDark ? "ring-purple-500/20" : "ring-purple-400/20"
              }`}
            />
          </div>
        </div>

        {/* Profile Info - Centered */}
        <div className="text-center mb-6">
          <h1
            className={`text-3xl font-bold mb-2 ${
              isDark ? "text-white" : "text-gray-900"
            }`}
          >
            {profile.displayName}
          </h1>

          <div className="flex items-center justify-center gap-2 mb-3">
            {platformConfig?.icon && (
              <platformConfig.icon
                className={`w-5 h-5 ${platformConfig.color}`}
              />
            )}
            <span
              className={`text-lg font-medium ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              @{profile.username}
            </span>
          </div>

          {profile.category && (
            <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg">
              {profile.category}
            </div>
          )}
        </div>

        {/* Bio */}
        {profile.bio && (
          <div className="text-center mb-6">
            <p
              className={`text-base leading-relaxed max-w-2xl mx-auto ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              {profile.bio}
            </p>
          </div>
        )}

        {/* Status Badges */}
        <div className="flex flex-wrap justify-center gap-3 mb-6">
          {profile.isVerified && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg">
              <Verified className="w-4 h-4" />
              <span className="text-sm font-medium">Verified</span>
            </div>
          )}

          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-gray-500 to-gray-600 text-white shadow-lg">
            <span className="text-sm font-medium capitalize">
              {profile.platform} Creator
            </span>
          </div>
        </div>

        {/* External Links */}
        {profile.externalLinks.length > 0 && (
          <div className="text-center">
            <div className="inline-flex flex-wrap justify-center gap-3">
              {profile.externalLinks.map((link: string, index: number) => (
                <a
                  key={index}
                  href={link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span className="text-sm font-medium">Visit Link</span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Location and Contact */}
        {(profile.location || profile.contactEmail) && (
          <div className="flex flex-wrap justify-center gap-4 mt-6 pt-6 border-t border-gray-200/20">
            {profile.location && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/10 backdrop-blur-sm">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span
                  className={`text-sm ${
                    isDark ? "text-gray-300" : "text-gray-600"
                  }`}
                >
                  {profile.location}
                </span>
              </div>
            )}
            {profile.contactEmail && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/10 backdrop-blur-sm">
                <Mail className="w-4 h-4 text-gray-400" />
                <a
                  href={`mailto:${profile.contactEmail}`}
                  className="text-sm text-blue-400 hover:text-blue-300 transition-colors"
                >
                  Contact
                </a>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
