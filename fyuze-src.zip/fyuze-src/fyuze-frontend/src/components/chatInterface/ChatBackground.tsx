import React from "react";

interface ChatBackgroundProps {
  isDark: boolean;
}

const ChatBackground: React.FC<ChatBackgroundProps> = ({ isDark }) => {
  return (
    <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden">
      {/* Dotted background pattern */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: `radial-gradient(circle, ${
            isDark ? "rgba(147, 51, 234, 0.4)" : "rgba(249, 115, 22, 0.4)"
          } 1px, transparent 2px)`,
          backgroundSize: "20px 20px",
          backgroundPosition: "0 0, 10px 10px",
        }}
      />

      {/* Secondary dotted layer for depth */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle, ${
            isDark ? "rgba(236, 72, 153, 0.3)" : "rgba(139, 92, 246, 0.3)"
          } 0.5px, transparent 0.5px)`,
          backgroundSize: "40px 40px",
          backgroundPosition: "20px 20px",
        }}
      />

      {/* Animated gradient orbs */}
      {/* <div
        className={`absolute bottom-[-20vh] left-1/2 h-[90vh] w-[90vh] -translate-x-1/2 rounded-full blur-[120px] animate-pulse ${
          isDark ? "bg-purple-700/30" : "bg-orange-400/40"
        }`}
        style={{ animationDuration: "4s" }}
      /> */}

      {/* Floating social media icons */}
      <div className="absolute inset-0">
        <div
          className={`absolute top-40 right-16 w-10 h-10 rounded-full ${
            isDark ? "bg-blue-500/20" : "bg-blue-400/10"
          } animate-float`}
          style={{ animationDelay: "2s", animationDuration: "8s" }}
        />
        <div
          className={`absolute top-60 left-1/4 w-10 h-10 rounded-full ${
            isDark ? "bg-purple-500/20" : "bg-purple-400/10"
          } animate-float`}
          style={{ animationDelay: "4s", animationDuration: "7s" }}
        />
        <div
          className={`absolute bottom-40 right-20 w-12 h-12 rounded-lg ${
            isDark ? "bg-orange-500/20" : "bg-orange-400/10"
          } animate-float`}
          style={{ animationDelay: "1s", animationDuration: "9s" }}
        />
        <div
          className={`absolute bottom-60 left-16 w-16 h-16 rounded-full ${
            isDark ? "bg-green-500/20" : "bg-green-400/10"
          } animate-float`}
          style={{ animationDelay: "3s", animationDuration: "5s" }}
        />
      </div>

      {/* Subtle network connection lines */}
      <svg className="absolute inset-0 w-full h-full opacity-20">
        <defs>
          <linearGradient
            id="connectionGradient"
            x1="0%"
            y1="0%"
            x2="100%"
            y2="100%"
          >
            <stop
              offset="0%"
              stopColor={isDark ? "#8B5CF6" : "#F59E0B"}
              stopOpacity="0.3"
            />
            <stop
              offset="100%"
              stopColor={isDark ? "#EC4899" : "#EF4444"}
              stopOpacity="0.1"
            />
          </linearGradient>
        </defs>
        <path
          d="M0,100 Q150,50 300,80 T600,60 L800,40"
          stroke="url(#connectionGradient)"
          strokeWidth="1"
          fill="none"
          className="animate-pulse"
          style={{ animationDuration: "3s" }}
        />
        <path
          d="M0,200 Q200,150 400,180 T800,160"
          stroke="url(#connectionGradient)"
          strokeWidth="1"
          fill="none"
          className="animate-pulse"
          style={{ animationDuration: "4s", animationDelay: "1s" }}
        />
      </svg>

      {/* Main background orbs */}
      <div
        className={`absolute bottom-[-22vh] left-1/2 h-[100vh] w-[100vh] -translate-x-1/2 rounded-full blur-[90px] ${
          isDark
            ? "border border-gray-700/30 bg-transparent"
            : "border border-white/30 bg-transparent"
        }`}
      />
      <div
        className={`absolute bottom-[-24vh] left-1/2 h-[110vh] w-[110vh] -translate-x-1/2 rounded-full blur-[90px] ${
          isDark
            ? "border border-sky-900/20 bg-transparent"
            : "border border-sky-400/30 bg-transparent"
        }`}
      />

      {/* Side floating elements with social media vibes */}
      <div
        className={`absolute -left-20 top-32 h-[40vh] w-[40vh] rounded-full blur-[100px] animate-slow-spin ${
          isDark ? "bg-pink-900/10" : "bg-pink-400/20"
        }`}
        style={{ animationDuration: "20s" }}
      />

      {/* Subtle content creator themed shapes */}
      <div className="absolute inset-0 opacity-5">
        <div
          className={`absolute top-1/4 left-1/3 w-16 h-16 ${
            isDark ? "bg-yellow-400" : "bg-yellow-500"
          } rounded-lg transform rotate-12 animate-gentle-bounce`}
          style={{ animationDelay: "0s", clipPath: "circle(30%)" }}
        />
        <div
          className={`absolute bottom-1/3 right-1/4 w-12 h-12 ${
            isDark ? "bg-red-400" : "bg-red-500"
          } rounded-full animate-gentle-bounce`}
          style={{ animationDelay: "2s" }}
        />
        <div
          className={`absolute top-1/2 right-1/3 w-8 h-8 ${
            isDark ? "bg-green-400" : "bg-green-500"
          } transform rotate-45 animate-gentle-bounce`}
          style={{
            animationDelay: "4s",
            clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
          }}
        />
      </div>
    </div>
  );
};

export default ChatBackground;
