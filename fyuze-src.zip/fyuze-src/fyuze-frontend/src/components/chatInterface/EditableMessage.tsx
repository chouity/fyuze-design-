import React from "react";

interface EditableMessageProps {
  editText: string;
  setEditText: (text: string) => void;
  onSubmitEdit: () => void;
  onCancelEdit: () => void;
  isUser: boolean;
  isDark: boolean;
}

const EditableMessage: React.FC<EditableMessageProps> = ({
  editText,
  setEditText,
  onSubmitEdit,
  onCancelEdit,
  isUser,
  isDark,
}) => {
  return (
    <div
      className={`w-full p-4 rounded-2xl shadow-md mb-4 ${
        isUser
          ? isDark
            ? "bg-gradient-to-r from-pink-600 to-orange-600 text-white"
            : "bg-gradient-to-r from-pink-500 to-orange-500 text-white"
          : isDark
          ? "bg-gray-800/80 backdrop-blur-sm border border-gray-700 text-gray-200"
          : "bg-white/80 backdrop-blur-sm border border-white/50 text-gray-800"
      }`}
    >
      <textarea
        value={editText}
        onChange={(e) => setEditText(e.target.value)}
        className={`w-full bg-transparent border-none outline-none resize-none ${
          isUser
            ? "text-white placeholder-white/70"
            : isDark
            ? "text-gray-200 placeholder-gray-400"
            : "text-gray-800 placeholder-gray-500"
        }`}
        rows={Math.max(2, Math.min(8, editText.split("\n").length + 1))}
        autoFocus
        style={{
          minHeight: editText.length > 50 ? "80px" : "50px",
          maxHeight: "300px",
        }}
      />
      <div className="flex justify-end space-x-2 mt-3">
        <button
          onClick={onCancelEdit}
          className={`px-4 py-2 text-sm rounded-lg transition-colors ${
            isDark
              ? "bg-gray-600 text-white hover:bg-gray-700"
              : "bg-gray-400 text-white hover:bg-gray-500"
          }`}
        >
          Cancel
        </button>
        <button
          onClick={onSubmitEdit}
          className={`px-4 py-2 text-sm rounded-lg transition-colors ${
            isDark
              ? "bg-blue-600 text-white hover:bg-blue-700"
              : "bg-blue-500 text-white hover:bg-blue-600"
          }`}
        >
          Send
        </button>
      </div>
    </div>
  );
};

export default EditableMessage;
