import React from "react";
import { Send } from "lucide-react";

interface ChatInputAreaProps {
  input: string;
  setInput: (value: string) => void;
  textareaRef: React.RefObject<HTMLTextAreaElement | null>;
  animatedPlaceholder: string;
  handleSubmit: (e: React.FormEvent) => void;
  handleKeyPress: (e: React.KeyboardEvent) => void;
  isLoading: boolean;
  isDark: boolean;
  messagesExist: boolean;
}

const ChatInputArea: React.FC<ChatInputAreaProps> = ({
  input,
  setInput,
  textareaRef,
  animatedPlaceholder,
  handleSubmit,
  handleKeyPress,
  isLoading,
  isDark,
  messagesExist,
}) => {
  // Function to detect if text contains Arabic characters
  const isArabicText = (text: string) => {
    const arabicRegex =
      /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
    return arabicRegex.test(text);
  };

  // Determine text direction and alignment based on input content
  const getTextDirection = (): {
    direction: "ltr" | "rtl";
    textAlign: "left" | "right";
  } => {
    if (!input.trim()) return { direction: "ltr", textAlign: "left" };
    return isArabicText(input)
      ? { direction: "rtl", textAlign: "right" }
      : { direction: "ltr", textAlign: "left" };
  };

  const textStyle = getTextDirection();
  if (!messagesExist) {
    // Large design for initial state
    return (
      <div
        className={`flex flex-col p-0 transform transition-all duration-1000 ease-out hover:shadow-3xl rounded-3xl shadow-2xl ${
          isDark
            ? "bg-gray-900/90 backdrop-blur-xl border border-gray-700/50"
            : "bg-white/90 backdrop-blur-xl border border-white/50"
        }`}
      >
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={animatedPlaceholder}
          className={`w-full bg-transparent px-6 pt-6 pb-2 border-none outline-none resize-none rounded-t-3xl text-base min-h-[60px] max-h-[180px] focus:ring-0 transition-all duration-500 ease-out ${
            isDark
              ? "text-white placeholder-gray-400"
              : "text-gray-800 placeholder-gray-500"
          }`}
          rows={1}
          style={{
            minHeight: "60px",
            maxHeight: "180px",
            direction: textStyle.direction,
            textAlign: textStyle.textAlign,
          }}
        />
        <div className="flex items-center gap-3 px-4 pb-4 pt-2">
          <div className="flex-1" />
          <button
            onClick={handleSubmit}
            disabled={!input.trim() || isLoading}
            className={`w-12 h-12 flex items-center justify-center rounded-full transition-all duration-500 ease-out transform hover:scale-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg ${
              input.trim() && !isLoading
                ? "bg-gradient-to-r from-red-500 via-orange-500 to-purple-400 hover:from-red-600 hover:via-orange-600 hover:to-orange-600 text-white hover:shadow-xl"
                : isDark
                ? "bg-gray-700 text-gray-400"
                : "bg-gray-200 text-gray-400"
            }`}
          >
            <Send className="w-6 h-6" />
          </button>
        </div>
      </div>
    );
  }

  // Compact design after first message
  return (
    <div
      className={`flex items-center gap-3 p-3 md:rounded-2xl rounded-2xl md:shadow-lg shadow-lg ${
        isDark
          ? "md:bg-gray-900/95 bg-gray-900/95 backdrop-blur-xl md:border-gray-600/40 border-gray-600/40 border"
          : "md:bg-white/95 bg-white/95 backdrop-blur-xl md:border-gray-200/60 border-gray-200/60 border"
      }`}
    >
      <textarea
        ref={textareaRef}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder={animatedPlaceholder}
        className={`flex-1 bg-transparent border-none outline-none resize-none text-base focus:ring-0 transition-all duration-500 ease-out px-2 py-2 min-h-[40px] max-h-[120px] rounded-xl ${
          isDark
            ? "text-white placeholder-gray-400"
            : "text-gray-800 placeholder-gray-500"
        }`}
        rows={1}
        style={{
          minHeight: "40px",
          maxHeight: "120px",
          direction: textStyle.direction,
          textAlign: textStyle.textAlign,
        }}
      />
      <button
        onClick={handleSubmit}
        disabled={!input.trim() || isLoading}
        className={`w-10 h-10 flex items-center justify-center rounded-full transition-all duration-500 ease-out transform hover:scale-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg ${
          input.trim() && !isLoading
            ? "bg-gradient-to-r from-red-500 via-orange-500 to-purple-400 hover:from-red-600 hover:via-orange-600 hover:to-orange-600 text-white hover:shadow-xl"
            : isDark
            ? "bg-gray-700 text-gray-400"
            : "bg-gray-200 text-gray-400"
        }`}
      >
        <Send className="w-4 h-4" />
      </button>
    </div>
  );
};

export default ChatInputArea;
