import React from "react";
import type { SuggestionButtonProps } from "../../types/chat";

const SuggestionButton: React.FC<SuggestionButtonProps> = ({
  suggestion,
  onClick,
  isDark,
}) => {
  return (
    <button
      onClick={() => onClick(suggestion)}
      className={`text-left p-4 rounded-2xl transition-all duration-300 hover:scale-[1.02] hover:shadow-xl border cursor-pointer ${
        isDark
          ? "bg-gray-800/70 hover:bg-gray-700/90 border-gray-600/40 text-gray-200 hover:text-white backdrop-blur-md hover:border-gray-500/60"
          : "bg-white/40 hover:bg-white/70 border-gray-200/60 text-gray-700 hover:text-gray-900 backdrop-blur-md hover:border-gray-300/80"
      } shadow-lg hover:shadow-2xl transform hover:-translate-y-1 group`}
    >
      <span className="text-sm leading-relaxed font-medium group-hover:font-semibold transition-all duration-200">
        {suggestion}
      </span>
    </button>
  );
};

interface SuggestionButtonsProps {
  suggestions: string[];
  onSuggestionClick: (suggestion: string) => void;
  isDark: boolean;
}

const SuggestionButtons: React.FC<SuggestionButtonsProps> = ({
  suggestions,
  onSuggestionClick,
  isDark,
}) => {
  return (
    <div className="mt-8 mb-6">
      <div className="hidden md:grid grid-cols-2 lg:grid-cols-3 gap-4 max-w-6xl mx-auto">
        {suggestions.slice(0, 4).map((suggestion, index) => (
          <SuggestionButton
            key={index}
            suggestion={suggestion}
            onClick={onSuggestionClick}
            isDark={isDark}
          />
        ))}
      </div>
    </div>
  );
};

export default SuggestionButtons;
