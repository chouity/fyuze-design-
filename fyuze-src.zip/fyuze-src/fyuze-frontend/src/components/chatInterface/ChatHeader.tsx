import React from "react";
import { Menu, Moon, Sun, Coins } from "lucide-react";
import ChatBackground from "./ChatBackground";
import { useUserBalance } from "../../hooks/useUserPoints";
import { useAuth } from "../../contexts/AuthContext";

interface ChatHeaderProps {
  onToggleSidebar: () => void;
  onClearChat: () => void;
  onToggleTheme: () => void;
  theme: string;
  isDark: boolean;
  userName?: string;
  userEmail?: string;
}

const ChatHeader: React.FC<ChatHeaderProps> = ({
  onToggleSidebar,
  onToggleTheme,
  theme,
  isDark,
}) => {
  const { user } = useAuth();
  const balance = useUserBalance(user?.id || "");

  return (
    <div
      className={`relative z-10 px-4 flex-shrink-0 ${
        isDark ? "bg-black" : "bg-orange-100"
      }`}
    >
      <ChatBackground isDark={isDark} />
      <div className="flex items-center justify-between max-w-6xl mx-auto p-3">
        {/* Left side */}
        <div className="flex items-center space-x-4">
          {/* Mobile Menu Button */}
          <button
            onClick={onToggleSidebar}
            className={`lg:hidden p-2 rounded-xl transition-all duration-300 hover:scale-110 ${
              isDark
                ? "bg-gray-800/80 backdrop-blur-sm border border-gray-700"
                : "bg-white/80 backdrop-blur-sm border border-white/50"
            } shadow-md hover:shadow-lg`}
          >
            <Menu className="w-5 h-5 text-pink-500" />
          </button>

          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="relative">
              <div className="absolute animate-pulse"></div>
              <div className="relative hidden sm:block">
                <img
                  src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
                  className="w-10 h-10 p-0 text-white"
                  alt="Fyuze Logo"
                />
              </div>
            </div>
            <h1
              className={`text-xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500 bg-clip-text text-transparent block`}
            >
              Fyuze AI
            </h1>
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center space-x-3">
          {/* User Points */}
          <div
            className={`flex items-center space-x-2 px-3 py-2 rounded-xl transition-all duration-300 ${
              isDark
                ? "bg-gray-800/80 backdrop-blur-sm border border-gray-700 text-gray-200"
                : "bg-white/80 backdrop-blur-sm border border-white/50 text-orange-700"
            } shadow-md`}
          >
            <Coins className="w-4 h-4 text-yellow-500" />
            <span className="text-sm font-medium">
              {user?.id ? balance ?? 0 : "-"}
            </span>
          </div>

          {/* New Chat Button
          <button
            onClick={onClearChat}
            className={`flex items-center space-x-2 pl-2 sm:px-4 py-2 rounded-xl transition-all duration-300 hover:scale-105  ${
              isDark
                ? "bg-gray-800/80 backdrop-blur-sm border border-gray-700 text-gray-200 hover:bg-gray-700/80"
                : "bg-white/80 backdrop-blur-sm border border-white/50 text-orange-700 hover:bg-white/90"
            } shadow-md hover:shadow-lg`}
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:block">New Chat</span>
          </button> */}

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            className={`p-2 rounded-xl transition-all duration-300 hover:scale-110 cursor-pointer ${
              isDark
                ? "bg-gray-800/80 backdrop-blur-sm border border-gray-700"
                : "bg-white/80 backdrop-blur-sm border border-white/50"
            } shadow-md hover:shadow-lg`}
          >
            {theme === "light" ? (
              <Moon className="w-5 h-5 text-orange-600" />
            ) : (
              <Sun className="w-5 h-5 text-yellow-400" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatHeader;
