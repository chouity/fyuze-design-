import React from "react";
import {
  Menu,
  X,
  Users,
  LogOut,
  Contact,
  BotMessageSquare,
  Link,
  MonitorCog,
  Search,
} from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import { handleSignOut } from "../../lib/supabaseClient";

type SidebarProps = {
  isOpen: boolean;
  onClose: () => void;
  onToggle: () => void;
  currentPage:
    | "chat"
    | "creators"
    | "contactus"
    | "adminDashboard"
    | "urlAnalyzer"
    | "searchEngine";
  setCurrentPage: (
    page:
      | "chat"
      | "creators"
      | "contactus"
      | "adminDashboard"
      | "urlAnalyzer"
      | "searchEngine"
  ) => void;
};

const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  onToggle,
  currentPage,
  setCurrentPage,
}) => {
  // const [chartsOpen, setChartsOpen] = useState(false);
  const { isDark } = useTheme();
  // const handleNavigation = useNavigate();

  // const toggleCharts = () => {
  //   setChartsOpen(!chartsOpen);
  // };

  const menuItems = [
    {
      id: "chatbot",
      icon: BotMessageSquare,
      label: "Chatbot",
      onClick: () => {
        setCurrentPage("chat");
        onClose();
      },
    },
    {
      id: "searchEngine",
      icon: Search,
      label: "Search Engine",
      onClick: () => {
        setCurrentPage("searchEngine");
        onClose();
      },
    },
    {
      id: "creators",
      icon: Users,
      label: "Creators",
      onClick: () => {
        setCurrentPage("creators");
        onClose();
      },
    },
    {
      id: "adminDashboard",
      icon: MonitorCog,
      label: "Admin Dashboard",
      onClick: () => {
        setCurrentPage("adminDashboard");
        onClose();
      },
    },
    {
      id: "urlAnalyzer",
      icon: Link,
      label: "Url Analyzer",
      onClick: () => {
        setCurrentPage("urlAnalyzer");
        onClose();
      },
    },
  ];

  const bottomMenuItems = [
    {
      id: "contactus",
      icon: Contact,
      label: "Contact Us",
      onClick: () => {
        setCurrentPage("contactus");
        onClose();
      },
    },
    {
      id: "logout",
      icon: LogOut,
      label: "Sign Out",
      onClick: () => {
        handleSignOut();
        onClose();
      },
    },
  ];

  return (
    <>
      <nav>
        {/* Overlay for mobile */}
        {isOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden backdrop-blur-sm"
            onClick={onClose}
          />
        )}

        {/* Sidebar */}
        <div
          className={`
        fixed left-0 top-0 h-full z-50 transform transition-all duration-300 ease-in-out
        ${isOpen ? "w-72" : "w-16"}
        ${!isOpen ? "hidden lg:block" : "block"}
        ${
          isDark
            ? "bg-gradient-to-b from-gray-900 via-purple-900 to-pink-900"
            : "bg-gradient-to-b from-pink-100 via-orange-100 to-yellow-100"
        }
      `}
        >
          <div className="flex flex-col h-full relative z-10">
            {/* Header */}
            <div
              className={`flex items-center justify-between p-4 ${
                isDark
                  ? "border-b border-gray-700/50 bg-gray-900/50 backdrop-blur-sm"
                  : "border-b border-white/50 bg-white/50 backdrop-blur-sm"
              }`}
            >
              {isOpen ? (
                <>
                  <div className="flex items-center ">
                    <div className="relative">
                      <div className="absolute inset-0 rounded-xl  opacity-75"></div>
                      <div className="relative p-2 w-15 sm:w-15 h-15 sm:h-15 rounded-xl">
                        <img
                          src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
                          alt="fyuze logo"
                        />
                      </div>
                    </div>
                    <h2
                      className={`text-lg font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500 bg-clip-text text-transparent`}
                    >
                      Dashboard
                    </h2>
                  </div>
                  <button
                    onClick={onClose}
                    className={`p-2 rounded-xl transition-all duration-300 hover:scale-110 ${
                      isDark
                        ? "hover:bg-gray-700/50 text-gray-300"
                        : "hover:bg-white/50 text-gray-600"
                    }`}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </>
              ) : (
                <button
                  onClick={onToggle}
                  className={`p-2 rounded-xl transition-all duration-300 hover:scale-110 mx-auto cursor-ew-resize ${
                    isDark
                      ? "hover:bg-gray-700/50 text-orange-600"
                      : "hover:bg-white/50 text-orange-600"
                  }`}
                  title="Open Menu"
                >
                  <Menu className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Main Menu Items */}
            <div className="flex-1 overflow-y-auto py-4">
              <div className="space-y-1 px-2">
                {menuItems.map((item) => {
                  const isActive =
                    (item.id === "creators" && currentPage === "creators") ||
                    (item.id === "chatbot" && currentPage === "chat") ||
                    (item.id === "contactus" && currentPage === "contactus");
                  item.id === "adminDashboard" &&
                    currentPage === "adminDashboard";

                  return (
                    <div key={`${item.id}-${currentPage}`}>
                      {/* Main Menu Item */}
                      <div
                        className={`
                      flex items-center rounded-xl cursor-pointer group
                      ${
                        isOpen
                          ? "px-4 py-3 justify-between"
                          : "px-3 py-3 justify-center"
                      }
                      transition-all duration-100 ease-out
                      ${
                        isActive
                          ? isDark
                            ? "bg-orange-500/20 text-orange-300 border border-orange-500/30"
                            : "bg-orange-100 text-orange-700 border border-orange-300"
                          : isDark
                          ? "hover:bg-gray-800/50 text-gray-200 hover:text-white active:bg-gray-700/70"
                          : "hover:bg-white/50 text-gray-700 hover:text-gray-900 active:bg-white/70"
                      }
                      backdrop-blur-sm hover:shadow-lg hover:scale-105
                    `}
                        onClick={item.onClick}
                        title={!isOpen ? item.label : undefined}
                      >
                        <div className="flex items-center">
                          <item.icon
                            className={`w-5 h-5 transition-colors duration-300 ${
                              isActive
                                ? "text-orange-500"
                                : "text-orange-500 group-hover:text-orange-800"
                            }`}
                          />
                          {isOpen && (
                            <span className="ml-3 text-sm font-medium">
                              {item.label}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Menu Items */}
            <div
              className={`${
                isDark
                  ? "border-t border-gray-600/50 bg-gray-600/50"
                  : "border-t border-white/50 bg-white/30"
              } backdrop-blur-sm p-2 space-y-1`}
            >
              {bottomMenuItems.map((item) => (
                <div
                  key={item.id}
                  className={`
                  flex items-center rounded-xl transition-all duration-300 cursor-pointer group
                  ${
                    isOpen
                      ? "px-4 py-2 justify-start"
                      : "px-3 py-2 justify-center"
                  }
                  ${
                    isDark
                      ? "hover:bg-gray-800/50 text-gray-300 hover:text-white"
                      : "hover:bg-white/50 text-gray-600 hover:text-gray-800"
                  }
                  hover:scale-105 hover:shadow-md
                `}
                  onClick={item.onClick}
                  title={!isOpen ? item.label : undefined}
                >
                  <item.icon
                    className={`w-5 h-5 transition-colors duration-300 ${
                      item.id === "logout"
                        ? "text-red-400 group-hover:text-red-300"
                        : "text-gray-400 group-hover:text-pink-400"
                    }`}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Sidebar;
