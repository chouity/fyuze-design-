export interface EmailData {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  subject: string;
  message: string;
  created_at: string;
  updated_at: string;
  status: string;
  user_id: string;
}

export interface AdminFilters {
  searchTerm: string;
  statusFilter: string;
  fromDate: string;
  toDate: string;
}

export interface PaginationState {
  currentPage: number;
  resultsPerPage: number;
  totalResults: number;
}
