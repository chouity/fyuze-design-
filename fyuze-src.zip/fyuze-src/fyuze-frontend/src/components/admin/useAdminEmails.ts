import { useState, useEffect, useCallback, useRef } from "react";
import {
  getContactMessages,
  updateContactMessageStatus,
  deleteContactMessage,
  searchContactMessage,
} from "../../lib/supabaseClient";
import type { EmailData, AdminFilters, PaginationState } from "./types";

export const useAdminEmails = () => {
  const [emails, setEmails] = useState<EmailData[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<EmailData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [availableStatuses, setAvailableStatuses] = useState<string[]>([]);
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const [filters, setFilters] = useState<AdminFilters>({
    searchTerm: "",
    statusFilter: "all",
    fromDate: "",
    toDate: "",
  });

  const [pagination, setPagination] = useState<PaginationState>({
    currentPage: 1,
    resultsPerPage: 10,
    totalResults: 0,
  });

  // Fetch emails from API
  const fetchEmails = useCallback(async () => {
    setIsLoading(true);
    try {
      const params: any = {
        limit: pagination.currentPage * pagination.resultsPerPage,
        offset: (pagination.currentPage - 1) * pagination.resultsPerPage,
      };

      if (filters.statusFilter !== "all") {
        params.status = filters.statusFilter;
      }
      if (filters.fromDate) {
        params.from = filters.fromDate;
      }
      if (filters.toDate) {
        params.to = filters.toDate;
      }

      const result = await getContactMessages(params);

      if (result.status === "success" && result.data?.data) {
        const emailsData = result.data.data.results || [];
        setEmails(emailsData);

        const total = result.data.data.total || emailsData.length;
        setPagination((prev) => ({ ...prev, totalResults: total }));

        if (
          result.data.data.statuses &&
          Array.isArray(result.data.data.statuses)
        ) {
          setAvailableStatuses(result.data.data.statuses);
        }
      } else {
        setEmails([]);
        setPagination((prev) => ({ ...prev, totalResults: 0 }));
      }
    } catch (error) {
      setEmails([]);
      setPagination((prev) => ({ ...prev, totalResults: 0 }));
    } finally {
      setIsLoading(false);
    }
  }, [
    filters.statusFilter,
    filters.fromDate,
    filters.toDate,
    pagination.currentPage,
    pagination.resultsPerPage,
  ]);

  // Search emails
  const handleSearchMessages = useCallback(async (query: string) => {
    if (query.length < 3) return;

    setIsSearching(true);

    try {
      const result = await searchContactMessage({ query });

      if (result.status === "success" && result.data) {
        let emailsData = [];

        if (Array.isArray(result.data)) {
          emailsData = result.data;
        } else if (result.data.data && Array.isArray(result.data.data)) {
          emailsData = result.data.data;
        } else if (result.data.results && Array.isArray(result.data.results)) {
          emailsData = result.data.results;
        }

        setEmails(emailsData);
        setPagination((prev) => ({ ...prev, totalResults: emailsData.length }));
      } else {
        setEmails([]);
        setPagination((prev) => ({ ...prev, totalResults: 0 }));
      }
    } catch (error) {
      setEmails([]);
      setPagination((prev) => ({ ...prev, totalResults: 0 }));
    } finally {
      setIsSearching(false);
    }
  }, []);

  // Filter emails based on search term
  const filteredEmails = (emails || []).filter((email) => {
    if (!email) return false;

    // If we have search results from API (3+ characters), don't apply client-side filtering
    if (filters.searchTerm.length >= 3) {
      return true; // Show all results from API search
    }

    // For less than 3 characters, apply client-side filtering
    const fullName = `${email.first_name || ""} ${
      email.last_name || ""
    }`.trim();
    const searchLower = filters.searchTerm.toLowerCase();

    const matchesSearch =
      filters.searchTerm.length === 0 ||
      fullName.toLowerCase().includes(searchLower) ||
      (email.subject || "").toLowerCase().includes(searchLower) ||
      (email.message || "").toLowerCase().includes(searchLower) ||
      (email.email || "").toLowerCase().includes(searchLower);

    return matchesSearch;
  });

  // Update filters
  const updateFilters = useCallback((newFilters: Partial<AdminFilters>) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
    setPagination((prev) => ({ ...prev, currentPage: 1 }));
  }, []);

  // Clear filters
  const clearFilters = useCallback(() => {
    setFilters({
      searchTerm: "",
      statusFilter: "all",
      fromDate: "",
      toDate: "",
    });
    setPagination((prev) => ({ ...prev, currentPage: 1 }));
    fetchEmails();
  }, [fetchEmails]);

  // Pagination handlers
  const handlePageChange = useCallback((page: number) => {
    setPagination((prev) => ({ ...prev, currentPage: page }));
  }, []);

  const handleResultsPerPageChange = useCallback((perPage: number) => {
    setPagination((prev) => ({
      ...prev,
      resultsPerPage: perPage,
      currentPage: 1,
    }));
  }, []);

  // Email actions
  const handleEmailSelect = useCallback(async (email: EmailData) => {
    setSelectedEmail(email);
    // Mark as read when selected
    await handleStatusChange(email.id, "readed");
  }, []);

  const handleStatusChange = useCallback(
    async (emailId: string, newStatus: string) => {
      try {
        const result = await updateContactMessageStatus({
          id: emailId,
          status: newStatus,
        });

        if (result.status === "success") {
          setEmails((prev) =>
            prev.map((email) =>
              email.id === emailId ? { ...email, status: newStatus } : email
            )
          );
          // Update selected email if it's the one being changed
          setSelectedEmail((prev) =>
            prev?.id === emailId ? { ...prev, status: newStatus } : prev
          );
        } else {
        }
      } catch (error) {
      }
    },
    []
  );

  const handleEmailDelete = useCallback(
    async (emailId: string) => {
      try {
        const result = await deleteContactMessage({ id: emailId });

        if (result.status === "success") {
          setEmails((prev) => prev.filter((email) => email.id !== emailId));
          if (selectedEmail?.id === emailId) {
            setSelectedEmail(null);
          }
          // Update total results
          setPagination((prev) => ({
            ...prev,
            totalResults: Math.max(0, prev.totalResults - 1),
          }));
        } else {
        }
      } catch (error) {
      }
    },
    [selectedEmail?.id]
  );

  // Drag and drop handlers
  const handleDragStart = useCallback((e: React.DragEvent, emailId: string) => {
    setDraggedItem(emailId);
    e.dataTransfer.effectAllowed = "move";
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent, targetEmailId: string) => {
      e.preventDefault();

      if (!draggedItem || draggedItem === targetEmailId) return;

      const draggedIndex = emails.findIndex(
        (email) => email.id === draggedItem
      );
      const targetIndex = emails.findIndex(
        (email) => email.id === targetEmailId
      );

      const newEmails = [...emails];
      const [draggedEmail] = newEmails.splice(draggedIndex, 1);
      newEmails.splice(targetIndex, 0, draggedEmail);

      setEmails(newEmails);
      setDraggedItem(null);
    },
    [draggedItem, emails]
  );

  // Debounced search effect
  useEffect(() => {
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    if (filters.searchTerm.length === 0) {
      fetchEmails();
    } else if (filters.searchTerm.length >= 3) {
      searchTimeoutRef.current = setTimeout(() => {
        handleSearchMessages(filters.searchTerm);
      }, 500);
    }

    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, [filters.searchTerm, fetchEmails, handleSearchMessages]);

  // Fetch emails on mount and when dependencies change
  useEffect(() => {
    fetchEmails();
  }, [fetchEmails]);

  return {
    // State
    emails: filteredEmails,
    selectedEmail,
    isLoading,
    isSearching,
    filters,
    pagination: {
      ...pagination,
      totalResults: pagination.totalResults,
    },
    availableStatuses,

    // Actions
    updateFilters,
    clearFilters,
    fetchEmails,
    handlePageChange,
    handleResultsPerPageChange,
    handleEmailSelect,
    handleStatusChange,
    handleEmailDelete,
    handleDragStart,
    handleDragOver,
    handleDrop,
  };
};
