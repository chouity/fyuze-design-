import React, { useState, useRef, useEffect } from "react";
import {
  Search,
  Filter,
  ChevronDown,
  RefreshCw,
  Calendar as CalendarIcon,
} from "lucide-react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useTheme } from "../../contexts/ThemeContext";
import type { AdminFilters } from "./types";

interface SearchAndFiltersProps {
  filters: AdminFilters;
  onFiltersChange: (filters: Partial<AdminFilters>) => void;
  onRefresh: () => void;
  onClearFilters: () => void;
  availableStatuses: string[];
  isLoading: boolean;
}

export const SearchAndFilters: React.FC<SearchAndFiltersProps> = ({
  filters,
  onFiltersChange,
  onRefresh,
  onClearFilters,
  availableStatuses,
  isLoading,
}) => {
  const { isDark } = useTheme();

  const [statusOpen, setStatusOpen] = useState(false);
  const statusRef = useRef<HTMLDivElement | null>(null);

  const fromDateObj = filters.fromDate ? new Date(filters.fromDate) : null;
  const toDateObj = filters.toDate ? new Date(filters.toDate) : null;

  const handleFromDateChange = (date: Date | null) => {
    const dateString = date ? date.toISOString().split("T")[0] : "";
    onFiltersChange({ fromDate: dateString });

    // If to date is before the new from date, clear the to date
    if (date && toDateObj && date > toDateObj) {
      onFiltersChange({ fromDate: dateString, toDate: "" });
    }
  };

  // Close status dropdown when clicking outside
  useEffect(() => {
    const onDocClick = (e: MouseEvent) => {
      if (statusRef.current && !statusRef.current.contains(e.target as Node)) {
        setStatusOpen(false);
      }
    };
    document.addEventListener("click", onDocClick);
    return () => document.removeEventListener("click", onDocClick);
  }, []);

  const toggleStatus = () => setStatusOpen((s) => !s);

  const selectStatus = (value: string) => {
    onFiltersChange({ statusFilter: value });
    setStatusOpen(false);
  };

  const handleToDateChange = (date: Date | null) => {
    const dateString = date ? date.toISOString().split("T")[0] : "";
    onFiltersChange({ toDate: dateString });
  };

  return (
    <div
      className={`p-8 rounded-2xl shadow-xl mb-8 backdrop-blur-sm border relative z-[100] ${
        isDark
          ? "bg-gray-800/90 border-gray-700/50 shadow-gray-900/20"
          : "bg-white/90 border-gray-200/50 shadow-gray-200/20"
      }`}
    >
      <div className="flex flex-col space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div
            className={`p-3 rounded-xl ${
              isDark ? "bg-pink-500/20" : "bg-pink-100"
            }`}
          >
            <Filter
              className={`w-6 h-6 ${
                isDark ? "text-pink-400" : "text-pink-600"
              }`}
            />
          </div>
          <div>
            <h3
              className={`text-lg font-semibold ${
                isDark ? "text-white" : "text-gray-900"
              }`}
            >
              Advanced Filters
            </h3>
            <p
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              Refine your email search with precision
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
          {/* Search */}
          <div className="lg:col-span-2 xl:col-span-1">
            <label
              className={`block text-sm font-medium mb-2  ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              Search Emails
            </label>
            <div className="relative">
              <Search
                className={`absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 ${
                  isDark ? "text-gray-400" : "text-gray-500"
                }`}
              />
              <input
                type="text"
                placeholder="Search by name, email, subject..."
                value={filters.searchTerm}
                onChange={(e) =>
                  onFiltersChange({ searchTerm: e.target.value })
                }
                className={`w-full pl-12 pr-4 py-4 rounded-xl border-2 transition-all duration-200 focus:ring-2 focus:outline-none ${
                  isDark
                    ? "bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 hover:border-purple-500 focus:border-purple-500 focus:ring-purple-500/40"
                    : "bg-white border-gray-200 text-gray-900 placeholder-gray-500 hover:border-orange-400 focus:border-orange-500 focus:ring-orange-500/40"
                }`}
              />
            </div>
          </div>

          {/* Status Filter - custom dropdown */}
          <div ref={statusRef} className="relative z-[10000]">
            <label
              className={`block text-sm font-medium mb-2 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              Status
            </label>
            <div className="relative z-[10000]">
              <button
                type="button"
                onClick={toggleStatus}
                aria-haspopup="listbox"
                aria-expanded={statusOpen}
                className={`w-full text-left px-4 py-4 pr-10 rounded-xl border-2 transition-all duration-200 focus:ring-2 focus:outline-none flex items-center justify-between ${
                  isDark
                    ? "bg-gray-700/50 border-gray-600 text-white hover:border-purple-500 focus:border-purple-500 focus:ring-purple-500/40"
                    : "bg-white border-gray-200 text-gray-900 hover:border-orange-400 focus:border-orange-500 focus:ring-orange-500/40"
                }`}
              >
                <span>
                  {filters.statusFilter && filters.statusFilter !== "all"
                    ? filters.statusFilter.charAt(0).toUpperCase() +
                      filters.statusFilter.slice(1)
                    : "All Status"}
                </span>
                <ChevronDown
                  className={`w-5 h-5 ml-2 ${
                    isDark ? "text-gray-400" : "text-gray-500"
                  }`}
                />
              </button>

              {/* Dropdown menu */}
              {statusOpen && (
                <ul
                  role="listbox"
                  aria-label="Status options"
                  className={`absolute mt-2 w-full rounded-xl shadow-xl max-h-56 overflow-auto py-1 z-[9999] ${
                    isDark
                      ? "bg-gray-800 border border-gray-700 text-white"
                      : "bg-white border border-gray-200 text-gray-900"
                  }`}
                >
                  <li
                    role="option"
                    tabIndex={0}
                    onClick={() => selectStatus("all")}
                    onKeyDown={(e) => e.key === "Enter" && selectStatus("all")}
                    className="px-4 py-2 hover:bg-gray-100  cursor-pointer"
                  >
                    All Status
                  </li>

                  {availableStatuses.length > 0
                    ? availableStatuses.map((status) => (
                        <li
                          key={status}
                          role="option"
                          tabIndex={0}
                          onClick={() => selectStatus(status)}
                          onKeyDown={(e) =>
                            e.key === "Enter" && selectStatus(status)
                          }
                          className="px-4 py-2 hover:bg-gray-100  cursor-pointer"
                        >
                          {status.charAt(0).toUpperCase() + status.slice(1)}
                        </li>
                      ))
                    : ["pending", "resolved", "spam"].map((status) => (
                        <li
                          key={status}
                          role="option"
                          tabIndex={0}
                          onClick={() => selectStatus(status)}
                          onKeyDown={(e) =>
                            e.key === "Enter" && selectStatus(status)
                          }
                          className="px-4 py-2 hover:bg-gray-100  cursor-pointer"
                        >
                          {status.charAt(0).toUpperCase() + status.slice(1)}
                        </li>
                      ))}
                </ul>
              )}
            </div>
          </div>

          {/* From Date */}
          <div className="relative">
            <label
              className={`block text-sm font-medium mb-2 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              From Date
            </label>
            <div className="relative">
              <DatePicker
                selected={fromDateObj}
                onChange={handleFromDateChange}
                dateFormat="MMM dd, yyyy"
                placeholderText="Select start date"
                className={`w-full pl-4 pr-12 py-4 rounded-xl border-2 transition-all duration-200 focus:ring-2 focus:outline-none ${
                  isDark
                    ? "bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 hover:border-purple-500 focus:border-purple-500 focus:ring-purple-500/40"
                    : "bg-white border-gray-200 text-gray-900 placeholder-gray-500 hover:border-orange-400 focus:border-orange-500 focus:ring-orange-500/40"
                }`}
                calendarClassName={`square-calendar ${
                  isDark ? "dark-datepicker" : "light-datepicker"
                }`}
                popperPlacement="top-start"
                showPopperArrow={false}
                inline={false}
                fixedHeight
                showWeekNumbers={false}
                monthsShown={1}
                maxDate={new Date()} // Prevent selecting future dates beyond today
                selectsStart
                startDate={fromDateObj}
                endDate={toDateObj}
                portalId="root-portal"
              />
              <CalendarIcon
                className={`absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 pointer-events-none ${
                  isDark ? "text-gray-400" : "text-gray-500"
                }`}
              />
            </div>
          </div>

          {/* To Date */}
          <div className="relative">
            <label
              className={`block text-sm font-medium mb-2 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              To Date
            </label>
            <div className="relative">
              <DatePicker
                selected={toDateObj}
                onChange={handleToDateChange}
                dateFormat="MMM dd, yyyy"
                placeholderText={
                  filters.fromDate
                    ? "Select end date"
                    : "Select start date first"
                }
                disabled={!filters.fromDate}
                minDate={fromDateObj || undefined}
                maxDate={new Date()} // Prevent selecting future dates beyond today
                className={`w-full pl-4 pr-12 py-4 rounded-xl border-2 transition-all duration-200 focus:ring-2 focus:outline-none ${
                  !filters.fromDate
                    ? "opacity-50 cursor-not-allowed bg-gray-100 border-gray-200 "
                    : isDark
                    ? "bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 hover:border-purple-500 focus:border-purple-500 focus:ring-purple-500/40"
                    : "bg-white border-gray-200 text-gray-900 placeholder-gray-500 hover:border-orange-400 focus:border-orange-500 focus:ring-orange-500/40"
                }`}
                calendarClassName={`square-calendar ${
                  isDark ? "dark-datepicker" : "light-datepicker"
                }`}
                popperPlacement="top-start"
                showPopperArrow={false}
                inline={false}
                fixedHeight
                showWeekNumbers={false}
                monthsShown={1}
                selectsEnd
                startDate={fromDateObj}
                endDate={toDateObj}
                portalId="root-portal"
              />
              <CalendarIcon
                className={`absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 pointer-events-none ${
                  isDark ? "text-gray-400" : "text-gray-500"
                }`}
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t border-gray-300/50">
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="flex-1 sm:flex-none px-8 py-4 bg-pink-600 hover:bg-pink-700 text-white rounded-xl font-medium transition-all duration-200 transform hover:scale-105 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3"
          >
            <RefreshCw
              className={`w-5 h-5 ${isLoading ? "animate-spin" : ""}`}
            />
            {isLoading ? "Refreshing..." : "Refresh Results"}
          </button>

          <button
            onClick={onClearFilters}
            className={`px-6 py-4 rounded-xl font-medium transition-all duration-200 ${
              isDark
                ? "bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white border border-gray-600"
                : "bg-gray-100 hover:bg-gray-200 text-gray-700 hover:text-gray-900 border border-gray-300"
            }`}
          >
            Clear Filters
          </button>
        </div>
      </div>
    </div>
  );
};
