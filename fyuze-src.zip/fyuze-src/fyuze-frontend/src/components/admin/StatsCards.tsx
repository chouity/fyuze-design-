import React from "react";
import { Mail, Clock, Archive } from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import type { EmailData } from "./types";

interface StatsCardsProps {
  totalResults: number;
  emails: EmailData[];
}

export const StatsCards: React.FC<StatsCardsProps> = ({
  totalResults,
  emails,
}) => {
  const { isDark } = useTheme();

  const unreadCount = emails.filter((e) => e.status === "unreaded").length;
  const pendingCount = emails.filter((e) => e.status === "pending").length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {/* Total Messages Card */}
      <div
        className={`relative p-8 rounded-2xl shadow-xl backdrop-blur-sm border overflow-hidden ${
          isDark
            ? "bg-blue-900/20 border-blue-700/50 shadow-blue-900/20"
            : "bg-blue-50/80 border-blue-200/50 shadow-blue-200/20"
        }`}
      >
        <div className="absolute inset-0 opacity-0"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div
              className={`p-3 rounded-xl ${
                isDark ? "bg-blue-500/20" : "bg-blue-100"
              }`}
            >
              <Mail
                className={`w-8 h-8 ${
                  isDark ? "text-blue-400" : "text-blue-600"
                }`}
              />
            </div>
            <div
              className={`text-2xl font-bold ${
                isDark ? "text-blue-400" : "text-blue-600"
              }`}
            >
              {totalResults}
            </div>
          </div>
          <div>
            <p
              className={`text-lg font-semibold mb-1 ${
                isDark ? "text-white" : "text-gray-900"
              }`}
            >
              Total Messages
            </p>
            <p
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              All contact messages received
            </p>
          </div>
        </div>
      </div>

      {/* Unread Messages Card */}
      <div
        className={`relative p-8 rounded-2xl shadow-xl backdrop-blur-sm border overflow-hidden ${
          isDark
            ? "bg-yellow-900/20 border-yellow-700/50 shadow-yellow-900/20"
            : "bg-yellow-50/80 border-yellow-200/50 shadow-yellow-200/20"
        }`}
      >
        <div className="absolute inset-0 opacity-0"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div
              className={`p-3 rounded-xl ${
                isDark ? "bg-yellow-500/20" : "bg-yellow-100"
              }`}
            >
              <Clock
                className={`w-8 h-8 ${
                  isDark ? "text-yellow-400" : "text-yellow-600"
                }`}
              />
            </div>
            <div
              className={`text-2xl font-bold ${
                isDark ? "text-yellow-400" : "text-yellow-600"
              }`}
            >
              {unreadCount}
            </div>
          </div>
          <div>
            <p
              className={`text-lg font-semibold mb-1 ${
                isDark ? "text-white" : "text-gray-900"
              }`}
            >
              Unread Messages
            </p>
            <p
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              Messages awaiting review
            </p>
          </div>
        </div>
      </div>

      {/* Pending Messages Card */}
      <div
        className={`relative p-8 rounded-2xl shadow-xl backdrop-blur-sm border overflow-hidden ${
          isDark
            ? "bg-pink-900/20 border-pink-700/50 shadow-pink-900/20"
            : "bg-pink-50/80 border-pink-200/50 shadow-pink-200/20"
        }`}
      >
        <div className="absolute inset-0 opacity-0"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div
              className={`p-3 rounded-xl ${
                isDark ? "bg-pink-500/20" : "bg-pink-100"
              }`}
            >
              <Archive
                className={`w-8 h-8 ${
                  isDark ? "text-pink-400" : "text-pink-600"
                }`}
              />
            </div>
            <div
              className={`text-2xl font-bold ${
                isDark ? "text-pink-400" : "text-pink-600"
              }`}
            >
              {pendingCount}
            </div>
          </div>
          <div>
            <p
              className={`text-lg font-semibold mb-1 ${
                isDark ? "text-white" : "text-gray-900"
              }`}
            >
              Pending Messages
            </p>
            <p
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              Messages requiring action
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
