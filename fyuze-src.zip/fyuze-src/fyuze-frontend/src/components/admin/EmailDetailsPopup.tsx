import React from "react";
import {
  Mail,
  User,
  Calendar,
  Clock,
  ArrowLeft,
  Archive,
  Trash,
} from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import type { EmailData } from "./types";

interface EmailDetailsPopupProps {
  selectedEmail: EmailData | null;
  isOpen: boolean;
  onClose: () => void;
  onDelete: (emailId: string) => void;
  onArchive: (emailId: string) => void;
}

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case "pending":
      return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
    case "approved":
      return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
    case "rejected":
      return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
    case "archived":
      return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    default:
      return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
  }
};

export const EmailDetailsPopup: React.FC<EmailDetailsPopupProps> = ({
  selectedEmail,
  isOpen,
  onClose,
  onDelete,
  onArchive,
}) => {
  const { isDark } = useTheme();

  const handleArchive = () => {
    if (selectedEmail) {
      onArchive(selectedEmail.id);
      onClose();
    }
  };

  const handleDelete = () => {
    if (selectedEmail) {
      onDelete(selectedEmail.id);
      onClose();
    }
  };

  if (!isOpen || !selectedEmail) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
        onClick={onClose}
      />

      {/* Popup */}
      <div
        className={`fixed inset-x-0 bottom-0 top-16 z-50 lg:hidden overflow-hidden rounded-t-3xl shadow-2xl transform transition-transform duration-300 ${
          isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between p-4 border-b ${
            isDark ? "border-gray-700" : "border-gray-200"
          }`}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className={`p-2 rounded-xl transition-colors ${
                isDark
                  ? "text-gray-400 hover:text-white hover:bg-gray-700"
                  : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
              }`}
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h2
                className={`text-lg font-semibold ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                Message Details
              </h2>
              <p
                className={`text-sm ${
                  isDark ? "text-gray-400" : "text-gray-600"
                }`}
              >
                {selectedEmail.first_name} {selectedEmail.last_name}
              </p>
            </div>
          </div>

          {/* Status Badge */}
          <span
            className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(
              selectedEmail.status
            )}`}
          >
            {selectedEmail.status}
          </span>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {/* Contact Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <User
                className={`w-5 h-5 ${
                  isDark ? "text-blue-400" : "text-blue-600"
                }`}
              />
              <div>
                <p
                  className={`font-medium ${
                    isDark ? "text-white" : "text-gray-900"
                  }`}
                >
                  {selectedEmail.first_name} {selectedEmail.last_name}
                </p>
                <p
                  className={`text-sm ${
                    isDark ? "text-gray-400" : "text-gray-600"
                  }`}
                >
                  {selectedEmail.subject || "No subject"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Mail
                className={`w-5 h-5 ${
                  isDark ? "text-blue-400" : "text-blue-600"
                }`}
              />
              <p className={`${isDark ? "text-gray-300" : "text-gray-700"}`}>
                {selectedEmail.email}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <Calendar
                className={`w-5 h-5 ${
                  isDark ? "text-blue-400" : "text-blue-600"
                }`}
              />
              <p
                className={`text-sm ${
                  isDark ? "text-gray-400" : "text-gray-600"
                }`}
              >
                {new Date(selectedEmail.created_at).toLocaleDateString(
                  "en-US",
                  {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  }
                )}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <Clock
                className={`w-5 h-5 ${
                  isDark ? "text-blue-400" : "text-blue-600"
                }`}
              />
              <p
                className={`text-sm ${
                  isDark ? "text-gray-400" : "text-gray-600"
                }`}
              >
                {new Date(selectedEmail.created_at).toLocaleTimeString(
                  "en-US",
                  {
                    hour: "2-digit",
                    minute: "2-digit",
                  }
                )}
              </p>
            </div>
          </div>

          {/* Message */}
          <div>
            <h3
              className={`text-sm font-semibold mb-3 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              Message
            </h3>
            <div
              className={`p-4 rounded-xl ${
                isDark ? "bg-gray-700/50" : "bg-gray-50"
              }`}
            >
              <p
                className={`whitespace-pre-wrap ${
                  isDark ? "text-gray-300" : "text-gray-700"
                }`}
              >
                {selectedEmail.message}
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        {selectedEmail.status.toLowerCase() === "pending" && (
          <div
            className={`p-4 border-t ${
              isDark ? "border-gray-700" : "border-gray-200"
            }`}
          >
            <div className="flex gap-3">
              <button
                onClick={handleArchive}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white px-4 py-3 rounded-xl transition-colors flex items-center justify-center gap-2 font-medium"
              >
                <Archive className="w-5 h-5" />
                Archive
              </button>

              <button
                onClick={handleDelete}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-3 rounded-xl transition-colors flex items-center justify-center gap-2 font-medium"
              >
                <Trash className="w-5 h-5" />
                Delete
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default EmailDetailsPopup;
