import React from "react";
import {
  Mail,
  User,
  Calendar,
  Clock,
  Trash,
  Archive,
} from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import type { EmailData } from "./types";

interface EmailDetailsProps {
  selectedEmail: EmailData | null;
  onArchive: (emailId: string) => void;
  onDelete: (emailId: string) => void;
}

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case "pending":
      return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
    case "approved":
      return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
    case "rejected":
      return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
    case "archived":
      return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    default:
      return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
  }
};

export const EmailDetails: React.FC<EmailDetailsProps> = ({
  selectedEmail,
  onArchive,
  onDelete,
}) => {
  const { isDark } = useTheme();

  const handleArchive = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedEmail) {
      onArchive(selectedEmail.id);
    }
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedEmail) {
      onDelete(selectedEmail.id);
    }
  };

  return (
    <div
      className={`rounded-2xl shadow-xl backdrop-blur-sm border overflow-hidden h-[calc(200vh-50rem)] flex flex-col ${
        isDark
          ? "bg-gray-800/90 border-gray-700/50 shadow-gray-900/20"
          : "bg-white/90 border-gray-200/50 shadow-gray-200/20"
      }`}
    >
      <div
        className={`p-6 border-b flex-shrink-0 ${
          isDark ? "border-gray-700/50" : "border-gray-200/50"
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`p-2 rounded-lg ${
              isDark
                ? "bg-gradient-to-br from-green-500/20 to-emerald-500/20"
                : "bg-gradient-to-br from-green-100 to-emerald-100"
            }`}
          >
            <User
              className={`w-5 h-5 ${
                isDark ? "text-green-400" : "text-green-600"
              }`}
            />
          </div>
          <div>
            <h2
              className={`text-xl font-semibold ${
                isDark ? "text-white" : "text-gray-900"
              }`}
            >
              Message Details
            </h2>
            <p
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              {selectedEmail
                ? "View and manage message"
                : "Select a message to view"}
            </p>
          </div>
        </div>
      </div>

      <div className="p-6 flex-1 overflow-y-auto">
        {selectedEmail ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div
                className={`px-3 py-1 text-sm rounded-full ${getStatusColor(
                  selectedEmail.status
                )}`}
              >
                {selectedEmail.status}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">
                {selectedEmail.subject}
              </h3>
              <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 mb-4">
                <User className="w-4 h-4" />
                <span>
                  {selectedEmail.first_name} {selectedEmail.last_name}
                </span>
                <span>•</span>
                <span>{selectedEmail.email}</span>
              </div>
            </div>

            <div
              className={`p-4 rounded-lg  ${
                isDark ? "bg-gray-700" : "bg-gray-50"
              }`}
            >
              <p
                className={`leading-relaxed ${
                  isDark ? "text-gray-200" : "text-gray-800"
                }`}
              >
                {selectedEmail.message}
              </p>
            </div>

            <div className="flex items-center gap-4 text-sm text-gray-500 pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>
                  {new Date(selectedEmail.created_at).toLocaleDateString()}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>
                  {new Date(selectedEmail.created_at).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center text-gray-500 py-12">
            <Mail className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Select an email to view details</p>
          </div>
        )}
      </div>

      {/* Fixed Action Buttons */}
      {selectedEmail && (
        <div
          className={`p-6 border-t flex-shrink-0 ${
            isDark ? "border-gray-700/50" : "border-gray-200/50"
          }`}
        >
          <div className="flex gap-2">
            <button
              onClick={handleArchive}
              className="flex-1 bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Archive className="w-4 h-4" />
              Archive
            </button>

            <button
              onClick={handleDelete}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Trash className="w-4 h-4" />
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
