import React from "react";
import { Mail } from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import { LoadingSpinner } from "../common";
import type { EmailData, PaginationState } from "./types";
const Pagination = React.lazy(() =>
  import("../creators/Pagination").then((module) => ({
    default: module.Pagination,
  }))
);
const EmailCard = React.lazy(() =>
  import("./EmailCard").then((module) => ({ default: module.EmailCard }))
);
interface EmailListProps {
  emails: EmailData[];
  selectedEmail: EmailData | null;
  isLoading: boolean;
  isSearching: boolean;
  totalResults: number;
  pagination: PaginationState;
  onEmailSelect: (email: EmailData) => void;
  onEmailArchive: (emailId: string) => void;
  onEmailDelete: (emailId: string) => void;
  onPageChange: (page: number) => void;
  onResultsPerPageChange: (perPage: number) => void;
  onDragStart: (e: React.DragEvent, emailId: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, targetEmailId: string) => void;
}

export const EmailList: React.FC<EmailListProps> = ({
  emails,
  selectedEmail,
  isLoading,
  isSearching,
  totalResults,
  pagination,
  onEmailSelect,
  onEmailArchive,
  onEmailDelete,
  onPageChange,
  onResultsPerPageChange,
  onDragStart,
  onDragOver,
  onDrop,
}) => {
  const { isDark } = useTheme();

  return (
    <div
      className={` lg:col-span-2 rounded-2xl shadow-xl backdrop-blur-sm border overflow-hidden min-w-0 flex flex-col h-[calc(200vh-50rem)] ${
        isDark
          ? "bg-gray-800/90 border-gray-700/50 shadow-gray-900/20"
          : "bg-white/90 border-gray-200/50 shadow-gray-200/20"
      }`}
    >
      <div
        className={`p-6 border-b ${
          isDark ? "border-gray-700/50" : "border-gray-200/50"
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`p-2 rounded-lg ${
                isDark
                  ? "bg-gradient-to-br from-blue-500/20 to-indigo-500/20"
                  : "bg-gradient-to-br from-blue-100 to-indigo-100"
              }`}
            >
              <Mail
                className={`w-5 h-5 ${
                  isDark ? "text-blue-400" : "text-blue-600"
                }`}
              />
            </div>
            <div>
              <h2
                className={`text-xl font-semibold ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                Messages
              </h2>
              <p
                className={`text-sm ${
                  isDark ? "text-gray-400" : "text-gray-600"
                }`}
              >
                {totalResults} total messages
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-hidden ">
        {isLoading || isSearching ? (
          <div className="p-12 text-center">
            <LoadingSpinner
              size="xl"
              text={
                isSearching ? "Searching messages..." : "Loading messages..."
              }
            />
            <p
              className={`text-sm mt-4 ${
                isDark ? "text-gray-500" : "text-gray-500"
              }`}
            >
              {isSearching
                ? "Please wait while we search your messages"
                : "Please wait while we fetch your data"}
            </p>
          </div>
        ) : emails.length === 0 ? (
          <div className="p-12 text-center">
            <div
              className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 ${
                isDark ? "bg-gray-700/50" : "bg-gray-100"
              }`}
            >
              <Mail
                className={`w-8 h-8 opacity-50 ${
                  isDark ? "text-gray-400" : "text-gray-500"
                }`}
              />
            </div>
            <p
              className={`text-lg font-medium ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              No messages found
            </p>
            <p
              className={`text-sm mt-2 ${
                isDark ? "text-gray-500" : "text-gray-500"
              }`}
            >
              Try adjusting your filters or search terms
            </p>
          </div>
        ) : (
          emails.map((email) => (
            <EmailCard
              key={email.id}
              email={email}
              isSelected={selectedEmail?.id === email.id}
              onClick={onEmailSelect}
              onArchive={onEmailArchive}
              onDelete={onEmailDelete}
              onDragStart={onDragStart}
              onDragOver={onDragOver}
              onDrop={onDrop}
            />
          ))
        )}
      </div>

      {/* Pagination */}
      <div className="flex-shrink-0 relative">
        <Pagination
          currentPage={pagination.currentPage}
          totalResults={pagination.totalResults}
          resultsPerPage={pagination.resultsPerPage}
          onPageChange={onPageChange}
          onResultsPerPageChange={onResultsPerPageChange}
        />
      </div>
    </div>
  );
};
