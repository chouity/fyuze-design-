import React from "react";
import { User, Archive, Trash2 } from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import type { EmailData } from "./types";

interface EmailCardProps {
  email: EmailData;
  isSelected: boolean;
  onClick: (email: EmailData) => void;
  onArchive: (emailId: string) => void;
  onDelete: (emailId: string) => void;
  onDragStart: (e: React.DragEvent, emailId: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, targetEmailId: string) => void;
}

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case "pending":
      return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
    case "approved":
      return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
    case "rejected":
      return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
    case "archived":
      return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    default:
      return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
  }
};

export const EmailCard: React.FC<EmailCardProps> = ({
  email,
  isSelected,
  onClick,
  onArchive,
  onDelete,
  onDragStart,
  onDragOver,
  onDrop,
}) => {
  const { isDark } = useTheme();

  const handleClick = () => {
    onClick(email);
  };

  const handleArchive = (e: React.MouseEvent) => {
    e.stopPropagation();
    onArchive(email.id);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(email.id);
  };

  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, email.id)}
      onDragOver={onDragOver}
      onDrop={(e) => onDrop(e, email.id)}
      onClick={handleClick}
      className={`p-6 border-b cursor-pointer transition-all duration-200 hover:scale-[1.02] ${
        isDark
          ? "border-gray-700/50 hover:bg-gray-700/30"
          : "border-gray-200/50 hover:bg-gray-50/50"
      } ${
        isSelected
          ? isDark
            ? "bg-pink-300/10"
            : "bg-pink-50 border-pink-200/50"
          : ""
      }`}
    >
      <div className="flex items-start justify-between min-w-0">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span
              className={`px-2 py-1 text-xs rounded-full ${getStatusColor(
                email.status
              )}`}
            >
              {email.status}
            </span>
          </div>

          <div className="flex items-center gap-2 mb-2">
            <User className="w-4 h-4 text-gray-400" />
            <span
              className={`font-medium truncate ${
                isDark ? "text-gray-300" : "text-gray-700"
              } `}
            >
              {email.first_name} {email.last_name}
            </span>
          </div>

          <h3
            className={`font-medium mb-1 truncate ${
              isDark ? "text-white" : "text-gray-900"
            }`}
          >
            {email.subject}
          </h3>

          <p className="text-sm text-gray-600 dark:text-gray-400 truncate mb-2">
            {email.message}
          </p>

          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span>{email.email}</span>
            <span>{new Date(email.created_at).toLocaleDateString()}</span>
            <span>
              {new Date(email.created_at).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 ml-4">
          <button
            onClick={handleArchive}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors"
            title="Archive"
          >
            <Archive className="w-4 h-4" />
          </button>

          <button
            onClick={handleDelete}
            className="p-2 text-red-600 hover:bg-red-100  rounded-lg transition-colors cursor-pointer"
            title="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
