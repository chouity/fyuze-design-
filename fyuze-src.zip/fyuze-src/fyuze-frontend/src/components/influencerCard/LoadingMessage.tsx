import React, { useState, useEffect } from "react";
import type { LoadingMessageProps } from "../../types/chat";

const LoadingMessage: React.FC<LoadingMessageProps> = ({ message, isDark }) => {
  const [displayMessage, setDisplayMessage] = useState("");
  const [isAnimating, setIsAnimating] = useState(false);

  // Typewriter effect
  useEffect(() => {
    if (!message) return;

    setIsAnimating(true);
    setDisplayMessage("");
    let currentIndex = 0;

    const typewriterInterval = setInterval(() => {
      currentIndex++;
      if (currentIndex <= message.length) {
        setDisplayMessage(message.slice(0, currentIndex));
      } else {
        setIsAnimating(false);
        clearInterval(typewriterInterval);
      }
    }, 30); // Typing speed

    return () => {
      clearInterval(typewriterInterval);
    };
  }, [message]);

  return (
    <div className="relative">
      <div
        className={`text-sm transition-all duration-300 ease-in-out transform ${
          isDark ? "text-gray-300" : "text-gray-600"
        }`}
      >
        {displayMessage}
        {isAnimating && (
          <span
            className={`inline-block w-0.5 h-4 ml-1 animate-pulse ${
              isDark ? "bg-purple-400" : "bg-purple-600"
            }`}
          />
        )}
      </div>
      {/* Animated gradient background */}
      <div
        className={`absolute inset-0 -z-10 rounded-lg opacity-20 animate-pulse ${
          isDark
            ? "bg-gradient-to-r from-purple-600/20 to-blue-600/20"
            : "bg-gradient-to-r from-purple-300/20 to-blue-300/20"
        }`}
      />
    </div>
  );
};

export default LoadingMessage;
