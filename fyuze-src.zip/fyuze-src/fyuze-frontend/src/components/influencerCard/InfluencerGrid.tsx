import React from "react";
import InfluencerCard from "./InfluencerCard";
import type { Influencer } from "../../types/chat";

interface InfluencerGridProps {
  influencers: Influencer[];
  isDark: boolean;
  onViewProfile: (influencer: Influencer) => void;
}

const InfluencerGrid: React.FC<InfluencerGridProps> = ({
  influencers,
  isDark,
  onViewProfile,
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 overflow-y-auto overflow-x-hidden custom-scrollbar py-5">
      {influencers.map((influencer, index) => (
        <InfluencerCard
          key={`${influencer.username}-${index}`}
          influencer={influencer}
          index={index}
          isDark={isDark}
          onViewProfile={onViewProfile}
        />
      ))}

      {/* Custom scrollbar styles */}
      <style
        dangerouslySetInnerHTML={{
          __html: `
          .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: ${
              isDark ? "rgba(55, 65, 81, 0.3)" : "rgba(229, 231, 235, 0.3)"
            };
            border-radius: 10px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: ${
              isDark ? "rgba(147, 51, 234, 0.5)" : "rgba(147, 51, 234, 0.4)"
            };
            border-radius: 10px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: ${
              isDark ? "rgba(147, 51, 234, 0.7)" : "rgba(147, 51, 234, 0.6)"
            };
          }
          .loading-indicator {
            pointer-events: none;
          }
        `,
        }}
      />
    </div>
  );
};

export default InfluencerGrid;
