import React from "react";

interface MessageAvatarProps {
  isUser: boolean;
  userName?: string;
  userEmail?: string;
}

const MessageAvatar: React.FC<MessageAvatarProps> = ({
  isUser,
  userName,
  userEmail,
}) => {
  if (isUser) {
    const displayChar = userName
      ? userName.charAt(0).toUpperCase()
      : userEmail
      ? userEmail.charAt(0).toUpperCase()
      : "U";

    return (
      <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-orange-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
        {displayChar}
      </div>
    );
  }

  return (
    <img
      src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
      className="w-10 h-10 text-white"
      alt="Fyuze AI Avatar"
    />
  );
};

export default MessageAvatar;
