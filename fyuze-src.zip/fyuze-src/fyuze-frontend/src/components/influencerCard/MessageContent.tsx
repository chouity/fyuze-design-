import React from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";

interface MessageContentProps {
  text: string;
  isUser: boolean;
  isDark: boolean;
}

const MessageContent: React.FC<MessageContentProps> = ({
  text,
  isUser,
  isDark,
}) => {
  // Function to detect if text contains Arabic characters
  const isArabicText = (text: string) => {
    const arabicRegex =
      /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
    return arabicRegex.test(text);
  };

  // Determine text direction and alignment based on message content
  const getTextDirection = (): {
    direction: "ltr" | "rtl";
    textAlign: "left" | "right";
  } => {
    if (!text.trim()) return { direction: "ltr", textAlign: "left" };
    return isArabicText(text)
      ? { direction: "rtl", textAlign: "right" }
      : { direction: "ltr", textAlign: "left" };
  };

  const textStyle = getTextDirection();
  return (
    <div
      className={`inline-block p-4 rounded-2xl shadow-md mb-4 ${
        isUser
          ? isDark
            ? "bg-gradient-to-r from-pink-600 to-orange-600 text-white"
            : "bg-gradient-to-r from-pink-500 to-orange-500 text-white"
          : isDark
          ? "bg-gray-800/80 backdrop-blur-sm border border-gray-700 text-gray-200"
          : "bg-white/80 backdrop-blur-sm border border-white/50 text-gray-800"
      }`}
      style={{
        direction: textStyle.direction,
        textAlign: textStyle.textAlign,
      }}
    >
      <div
        className={`prose prose-sm max-w-none ${
          isDark ? "prose-invert prose-gray" : "prose-gray"
        }`}
      >
        <ReactMarkdown
          children={text}
          remarkPlugins={[remarkGfm]}
          rehypePlugins={[rehypeHighlight]}
          components={{
            // Custom styling for links
            a: ({ children, href }) => (
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className={`${
                  isDark
                    ? "text-blue-400 hover:text-blue-300"
                    : "text-blue-600 hover:text-blue-500"
                } underline decoration-2 underline-offset-2 hover:decoration-4 transition-all duration-200`}
              >
                {children}
              </a>
            ),
            // Custom styling for code blocks
            code: ({ children, ...props }) => {
              const isInline = !props.className?.includes("language-");
              return isInline ? (
                <code
                  className={`${
                    isDark
                      ? "bg-gray-700 text-gray-200"
                      : "bg-gray-100 text-gray-800"
                  } px-1.5 py-0.5 rounded text-sm font-mono`}
                >
                  {children}
                </code>
              ) : (
                <code className={props.className} {...props}>
                  {children}
                </code>
              );
            },
            // Custom styling for blockquotes
            blockquote: ({ children }) => (
              <blockquote
                className={`border-l-4 ${
                  isDark
                    ? "border-purple-500 bg-purple-900/20"
                    : "border-purple-400 bg-purple-50"
                } pl-4 py-2 my-4 italic`}
              >
                {children}
              </blockquote>
            ),
          }}
        />
      </div>
    </div>
  );
};

export default MessageContent;
