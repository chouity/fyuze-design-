import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { getGradientColors, getPlatformInfo } from "../../utils/platformUtils";
import type { Influencer } from "../../types/chat";

interface ProfileAvatarProps {
  influencer: Influencer;
  index: number;
  isDark: boolean;
  size?: "sm" | "md" | "lg";
}

const ProfileAvatar: React.FC<ProfileAvatarProps> = ({
  influencer,
  index,
  isDark,
  size = "md",
}) => {
  const sizeClasses = {
    sm: "w-12 h-12",
    md: "w-16 h-16",
    lg: "w-20 h-20",
  };

  const platformInfo = getPlatformInfo(influencer?.url || "", isDark);

  return (
    <div className="relative mb-3">
      <div
        className={`${
          sizeClasses[size]
        } rounded-2xl overflow-hidden shadow-lg bg-gradient-to-br ${getGradientColors(
          index
        )} flex items-center justify-center text-white`}
      >
        {influencer.avatar_url || influencer.profilePicUrl ? (
          <>
            <img
              src={`https://corsproxy.io/?${encodeURIComponent(
                influencer.avatar_url || influencer.profilePicUrl
              )}`}
              alt={influencer.fullName}
              className="w-full h-full object-cover"
              onLoad={(e) => {
                const target = e.target as HTMLImageElement;
                const parent = target.parentElement;
                if (parent) {
                  const loadingIndicator = parent.querySelector(
                    ".loading-indicator"
                  ) as HTMLElement;
                  if (loadingIndicator) {
                    loadingIndicator.style.display = "none";
                  }
                }
              }}
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                const parent = target.parentElement;
                if (parent) {
                  target.style.display = "none";
                  const fallback = parent.querySelector(
                    ".fallback-avatar"
                  ) as HTMLElement;
                  if (fallback) {
                    fallback.style.display = "flex";
                  }
                  const loadingIndicator = parent.querySelector(
                    ".loading-indicator"
                  ) as HTMLElement;
                  if (loadingIndicator) {
                    loadingIndicator.style.display = "none";
                  }
                }
              }}
              crossOrigin="anonymous"
            />
            {/* Loading indicator */}
            <div className="loading-indicator absolute inset-0 bg-gradient-to-br from-purple-500/20 to-pink-500/20 animate-pulse rounded-2xl flex items-center justify-center">
              <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            </div>
          </>
        ) : null}
        <div
          className={`fallback-avatar w-full h-full flex items-center justify-center text-2xl font-bold ${
            influencer.avatar_url || influencer.profilePicUrl
              ? "hidden"
              : "flex"
          }`}
        >
          {influencer.fullName?.charAt(0).toUpperCase() || "Influencer"}
        </div>
      </div>

      {/* Platform badge */}
      <div
        className={`absolute -bottom-1 -right-1 p-1.5 rounded-full ${
          isDark
            ? "bg-gray-800 border-2 border-gray-700"
            : "bg-white border-2 border-gray-200"
        }`}
      >
        <FontAwesomeIcon
          icon={platformInfo.icon}
          className={`w-4 h-4 ${platformInfo.color}`}
        />
      </div>
    </div>
  );
};

export default ProfileAvatar;
