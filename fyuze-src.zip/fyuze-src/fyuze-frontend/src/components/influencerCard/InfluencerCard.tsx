import React from "react";
import { User } from "lucide-react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import ProfileAvatar from "./ProfileAvatar";
import { formatNumber } from "../../utils/numberUtils";
import { getPlatformInfo } from "../../utils/platformUtils";
import type { Influencer } from "../../types/chat";

interface InfluencerCardProps {
  influencer: Influencer;
  index: number;
  isDark: boolean;
  onViewProfile: (influencer: Influencer) => void;
}

const InfluencerCard: React.FC<InfluencerCardProps> = ({
  influencer,
  index,
  isDark,
  onViewProfile,
}) => {
  const platformInfo = getPlatformInfo(influencer?.url || "", isDark);

  return (
    <div
      className={`group relative overflow-hidden rounded-3xl border transition-all duration-500 hover:scale-[1.02] hover:shadow-2xl overflow-x-hidden  ${
        isDark
          ? "bg-gradient-to-br from-gray-800/90 via-gray-900/90 to-black/90 border-gray-700/50 hover:border-purple-500/50"
          : "bg-gradient-to-br from-white/95 via-gray-50/95 to-white/95 border-gray-200/60 hover:border-purple-300/60"
      } backdrop-blur-xl shadow-xl`}
    >
      {/* Animated background overlay */}
      <div
        className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-all duration-500 ${
          isDark
            ? "bg-gradient-to-br from-purple-900/20 via-pink-900/20 to-orange-900/20"
            : "bg-gradient-to-br from-purple-100/40 via-pink-100/40 to-orange-100/40"
        }`}
      />

      <div className="relative z-10 p-4 flex flex-col h-full">
        {/* Header Section - Centered layout */}
        <div className="flex flex-col items-center text-center mb-4">
          <ProfileAvatar
            influencer={influencer}
            index={index}
            isDark={isDark}
            size="md"
          />

          <div className="w-full">
            <div className="flex items-center justify-center gap-1 mb-2">
              <h4
                className={`text-lg font-bold truncate ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                {influencer.fullName}
              </h4>
              {/* <Star className="w-4 h-4 text-yellow-400 fill-current" /> */}
            </div>

            <p
              className={`text-sm mb-3 font-medium truncate ${
                isDark ? "text-purple-300" : "text-purple-600"
              }`}
            >
              @{influencer.username}
            </p>

            {/* Followers Count */}
            <div className="flex justify-center">
              <div
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold shadow-md ${
                  isDark
                    ? "bg-gradient-to-r from-purple-900/80 to-pink-900/80 text-purple-200 border border-purple-700/50"
                    : "bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 border border-purple-200/50"
                } backdrop-blur-sm`}
              >
                <FontAwesomeIcon
                  icon={platformInfo.icon}
                  className="w-3 h-3 text-pink-500"
                />
                <span>{formatNumber(influencer.followersCount)} followers</span>
              </div>
            </div>
          </div>
        </div>

        {/* Biography Section - Flex grow to take available space */}
        <div className="flex-grow flex flex-col justify-center mb-4">
          {influencer.biography && (
            <div
              className={`p-3 rounded-xl ${
                isDark
                  ? "bg-gray-800/60 border border-gray-700/50"
                  : "bg-gray-50/80 border border-gray-200/50"
              } backdrop-blur-sm`}
            >
              <p
                className={`text-xs leading-relaxed italic text-center line-clamp-3 ${
                  isDark ? "text-gray-300" : "text-gray-700"
                }`}
              >
                {influencer.biography ||
                  "No biography available Tech enthusiast reviewing the latest gadgetsTech enthusiast reviewing the latest gadgets."}
              </p>
            </div>
          )}
        </div>

        {/* Action Buttons - Always at bottom */}
        <div className="flex flex-col gap-2 mt-auto">
          <a
            href={influencer.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all duration-300 hover:scale-105 text-sm ${
              isDark
                ? "bg-gray-700/80 hover:bg-gray-600/80 text-gray-300 hover:text-white border border-gray-600/50 hover:border-gray-500/50"
                : "bg-gray-100/80 hover:bg-gray-200/80 text-gray-700 hover:text-gray-900 border border-gray-200/50 hover:border-gray-300/50"
            } backdrop-blur-sm shadow-lg hover:shadow-xl cursor-pointer`}
          >
            <FontAwesomeIcon
              icon={platformInfo.icon}
              className={`w-4 h-4 ${platformInfo.color}`}
            />
            <span>View on {platformInfo.name}</span>
          </a>

          <button
            onClick={() => onViewProfile(influencer)}
            className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold transition-all duration-300 hover:scale-105 text-sm ${
              isDark
                ? "bg-gray-700/80 hover:bg-gray-600/80 text-gray-300 hover:text-white border border-gray-600/50 hover:border-gray-500/50"
                : "bg-gray-100/80 hover:bg-gray-200/80 text-gray-700 hover:text-gray-900 border border-gray-200/50 hover:border-gray-300/50"
            } backdrop-blur-sm shadow-lg hover:shadow-xl cursor-pointer`}
          >
            <User className="w-4 h-4" />
            <span>View Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default InfluencerCard;
