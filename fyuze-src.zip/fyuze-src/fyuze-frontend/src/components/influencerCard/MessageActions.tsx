import React from "react";
import { Copy, Edit, Check } from "lucide-react";

interface MessageActionsProps {
  messageId: string;
  messageText: string;
  isUser: boolean;
  isDark: boolean;
  copiedMessageId: string | null;
  onCopy: (text: string, messageId: string) => void;
  onEdit: (messageId: string, text: string) => void;
}

const MessageActions: React.FC<MessageActionsProps> = ({
  messageId,
  messageText,
  isUser,
  isDark,
  copiedMessageId,
  onCopy,
  onEdit,
}) => {
  return (
    <div className="flex items-center space-x-2">
      {!isUser && (
        <button
          onClick={() => onCopy(messageText, messageId)}
          className={`p-1 rounded-md transition-all duration-200 hover:scale-110 ${
            copiedMessageId === messageId
              ? isDark
                ? " text-white"
                : " text-gray-900"
              : isDark
              ? "hover:bg-gray-700 text-gray-400 hover:text-gray-300"
              : "hover:bg-gray-200 text-gray-500 hover:text-gray-700"
          }`}
          title={copiedMessageId === messageId ? "Copied!" : "Copy message"}
        >
          {copiedMessageId === messageId ? (
            <span className="text-xs font-medium">
              <Check className="w-3 h-3" />
            </span>
          ) : (
            <Copy className="w-3 h-3" />
          )}
        </button>
      )}
      {isUser && (
        <button
          onClick={() => onEdit(messageId, messageText)}
          className={`p-1 rounded-md transition-all duration-200 hover:scale-110 ${
            isDark
              ? "hover:bg-gray-700 text-gray-400 hover:text-gray-300"
              : "hover:bg-gray-200 text-gray-500 hover:text-gray-700"
          }`}
          title="Edit message"
        >
          <Edit className="w-3 h-3" />
        </button>
      )}
    </div>
  );
};

export default MessageActions;
