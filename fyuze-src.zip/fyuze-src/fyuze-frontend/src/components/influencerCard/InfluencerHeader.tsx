import React from "react";
import { TrendingUp } from "lucide-react";

interface InfluencerHeaderProps {
  count: number;
  isDark: boolean;
  title?: string;
  subtitle?: string;
}

const InfluencerHeader: React.FC<InfluencerHeaderProps> = ({
  count,
  isDark,
  title = "Found",
  subtitle = "Perfect matches for your campaign",
}) => {
  return (
    <div className="flex items-center gap-3 mb-6 overflow-x-hidden ">
      <div
        className={`p-3 rounded-xl ${
          isDark
            ? "bg-gradient-to-br from-purple-900/60 to-pink-900/60 border border-purple-500/30"
            : "bg-gradient-to-br from-purple-100 to-pink-100 border border-purple-200"
        } backdrop-blur-sm`}
      >
        <TrendingUp
          className={`w-6 h-6 ${
            isDark ? "text-purple-300" : "text-purple-600"
          }`}
        />
      </div>
      <div>
        <h3
          className={`text-xl font-bold ${
            isDark ? "text-white" : "text-gray-800"
          }`}
        >
          🎯 {title} {count} Influencer{count > 1 ? "s" : ""}
        </h3>
        <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>
          {subtitle}
        </p>
      </div>
    </div>
  );
};

export default InfluencerHeader;
