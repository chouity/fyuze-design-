/**
 * DASHBOARD RESULTS COMPONENT
 *
 * Platform-agnostic results display for creator search.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import React, { useMemo } from "react";
import { useTheme } from "../../contexts/ThemeContext";
import { ResultsHeader } from "../creators/ResultsHeader";
import { CreatorResults } from "../creators/CreatorResults";
import { Pagination } from "../creators/Pagination";
import type { PlatformCreatorProfile } from "../../types/platform.types";
import type { Creator } from "../creators/CreatorTableView";

interface DashboardResultsProps {
  // Data
  creators: PlatformCreatorProfile[];
  loading: boolean;
  error: string | null;
  totalResults: number;

  // View mode
  viewMode: "table" | "cards";
  onViewModeChange: (mode: "table" | "cards") => void;

  // Pagination
  currentPage: number;
  resultsPerPage: number;
  onPageChange: (page: number) => void;
  onResultsPerPageChange: (count: number) => void;

  // Data source
  dataSource: "regular" | "ai_search";

  // Utils
  formatNumber: (num: number | undefined | null) => string;
}

// Adapter function to convert PlatformCreatorProfile to Creator
const adaptCreatorForTable = (profile: PlatformCreatorProfile): Creator => {
  return {
    id: profile.id,
    name: profile.displayName || profile.username,
    username: profile.username,
    avatar_url: profile.avatarUrl,
    profile_pic_url: profile.avatarUrl,
    full_name: profile.displayName,
    followers: profile.followers,
    following: profile.following,
    engagement_rate: profile.engagementRate,
    is_verified: profile.isVerified,
    verified: profile.isVerified,
    category: profile.category,
    contact_email: profile.contactEmail,
    platform: profile.platform,
    bio: profile.bio,
    location: profile.location,
  };
};

export const DashboardResults: React.FC<DashboardResultsProps> = ({
  creators,
  loading,
  error,
  totalResults,
  viewMode,
  onViewModeChange,
  currentPage,
  resultsPerPage,
  onPageChange,
  onResultsPerPageChange,
  dataSource,
  formatNumber,
}) => {
  const { isDark } = useTheme();

  // Adapt creators for the existing table component
  const adaptedCreators = useMemo(() => {
    return creators.map(adaptCreatorForTable);
  }, [creators]);

  // Adapter for formatNumber to match expected signature
  const adaptedFormatNumber = (num: number) => formatNumber(num);

  return (
    <div
      className={`rounded-xl border shadow-lg overflow-hidden ${
        isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
      }`}
    >
      <ResultsHeader
        loading={loading}
        totalResults={totalResults}
        viewMode={viewMode}
        onViewModeChange={onViewModeChange}
      />

      <div className="overflow-x-auto">
        <CreatorResults
          loading={loading}
          error={error}
          creators={adaptedCreators}
          viewMode={viewMode}
          formatNumber={adaptedFormatNumber}
          dataSource={dataSource}
        />
      </div>

      {/* Pagination */}
      <Pagination
        currentPage={currentPage}
        totalResults={totalResults}
        resultsPerPage={resultsPerPage}
        onPageChange={onPageChange}
        onResultsPerPageChange={onResultsPerPageChange}
      />
    </div>
  );
};
