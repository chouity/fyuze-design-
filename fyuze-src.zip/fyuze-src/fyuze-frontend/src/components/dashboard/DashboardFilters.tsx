/**
 * DASHBOARD FILTERS COMPONENT
 *
 * Platform-agnostic filters for creator search and discovery.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import React from "react";
import { useTheme } from "../../contexts/ThemeContext";
import { CreatorFilters } from "../creators/CreatorFilters";

interface FilterState {
  search: string;
  platform: string;
  category: string;
  location: string;
  verified: boolean | null;
  followers_min: string;
  followers_max: string;
  engagement_rate_min: string;
  engagement_rate_max: string;
  audience_gender: string;
  audience_age_min: string;
  audience_age_max: string;
}

interface DashboardFiltersProps {
  filters: FilterState;
  showAdvancedFilters: boolean;
  onFilterChange: (key: string, value: any) => void;
  onToggleAdvanced: () => void;
  onClearFilters: () => void;
}

export const DashboardFilters: React.FC<DashboardFiltersProps> = ({
  filters,
  showAdvancedFilters,
  onFilterChange,
  onToggleAdvanced,
  onClearFilters,
}) => {
  const { isDark } = useTheme();

  return (
    <div
      className={`mb-6 p-6 rounded-xl border shadow-lg ${
        isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
      }`}
    >
      <CreatorFilters
        filters={filters}
        onFilterChange={onFilterChange}
        showAdvancedFilters={showAdvancedFilters}
        onToggleAdvanced={onToggleAdvanced}
        onClearFilters={onClearFilters}
      />
    </div>
  );
};
