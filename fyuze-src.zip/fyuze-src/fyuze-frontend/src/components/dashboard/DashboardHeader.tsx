/**
 * DASHBOARD HEADER COMPONENT
 *
 * Platform-agnostic dashboard header with search, AI search, and filters.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import React from "react";
import { useTheme } from "../../contexts/ThemeContext";
import { Sparkles, X } from "lucide-react";

interface DashboardHeaderProps {
  showingAIResults: boolean;
  aiTopic?: string;
  aiPlatform?: string;
  useMockData?: boolean;
  onOpenAISearch: () => void;
  onClearAIResults: () => void;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  showingAIResults,
  aiTopic,
  aiPlatform,
  useMockData,
  onOpenAISearch,
  onClearAIResults,
}) => {
  const { isDark } = useTheme();

  return (
    <div className="mb-6 md:mb-8 text-center">
      <h1
        className={`text-2xl md:text-3xl font-bold mb-2 ${
          isDark ? "text-white" : "text-gray-900"
        }`}
      >
        Creator Discovery
      </h1>
      <p
        className={`text-sm md:text-base ${
          isDark ? "text-gray-300" : "text-gray-600"
        }`}
      >
        Find and connect with creators that match your brand
      </p>

      {/* AI Search Button */}
      <div className="mt-4 flex justify-center gap-4 flex-wrap">
        <button
          onClick={onOpenAISearch}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg ${
            isDark
              ? "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
              : "bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
          }`}
        >
          <Sparkles className="w-5 h-5" />
          AI Creator Search
        </button>

        {showingAIResults && (
          <div className="flex items-center gap-2 flex-wrap">
            {useMockData !== undefined && (
              <div
                className={`px-2 py-1 rounded-full text-xs font-medium ${
                  useMockData
                    ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                    : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                }`}
              >
                {useMockData ? "Demo Data" : "Live API"}
              </div>
            )}
            <button
              onClick={onClearAIResults}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg font-medium transition-all duration-300 border ${
                isDark
                  ? "border-gray-600 text-gray-300 hover:bg-gray-700"
                  : "border-gray-300 text-gray-700 hover:bg-gray-50"
              }`}
            >
              <X className="w-4 h-4" />
              Clear AI Results
            </button>
          </div>
        )}
      </div>

      {/* AI Results Indicator */}
      {showingAIResults && aiTopic && aiPlatform && (
        <div
          className={`mt-4 px-4 py-3 rounded-lg border flex items-center justify-center ${
            isDark
              ? "bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-gray-700 text-purple-300"
              : "bg-gradient-to-r from-purple-50 to-blue-50 border-gray-200 text-purple-700"
          }`}
        >
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-medium">
              Showing AI search results for "{aiTopic}" on {aiPlatform}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
