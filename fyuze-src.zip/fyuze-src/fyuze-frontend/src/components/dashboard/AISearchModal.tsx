/**
 * AI SEARCH MODAL COMPONENT
 *
 * Platform-agnostic AI search modal for creator discovery.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import React from "react";
import { useTheme } from "../../contexts/ThemeContext";
import { Sparkles, X } from "lucide-react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faInstagram, faTiktok } from "@fortawesome/free-brands-svg-icons";

interface AISearchState {
  isOpen: boolean;
  topic: string;
  keywords: string;
  location?: string;
  platform: string;
  search_results: number;
}

interface AISearchModalProps {
  aiSearch: AISearchState;
  onUpdateAISearch: (updates: Partial<AISearchState>) => void;
  onSearch: () => void;
  isLoading?: boolean;
}

export const AISearchModal: React.FC<AISearchModalProps> = ({
  aiSearch,
  onUpdateAISearch,
  onSearch,
  isLoading = false,
}) => {
  const { isDark } = useTheme();

  const handleClose = () => {
    onUpdateAISearch({ isOpen: false });
  };

  const handleSearch = () => {
    if (!aiSearch.topic.trim() || !aiSearch.platform) return;
    onSearch();
  };

  if (!aiSearch.isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div
        className={`rounded-3xl shadow-2xl border max-w-md w-full max-h-[90vh] overflow-y-auto animate-in  zoom-in-95 duration-300  ${
          isDark
            ? "bg-gray-800/95 border-gray-700 backdrop-blur-xl"
            : "bg-white/95 border-gray-200 backdrop-blur-xl"
        }`}
      >
        {/* Modal Header */}
        <div
          className={`p-6 border-b ${
            isDark ? "border-gray-700" : "border-gray-200"
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-full ${
                  isDark ? "bg-purple-900/30" : "bg-purple-100"
                }`}
              >
                <Sparkles
                  className={`w-5 h-5 ${
                    isDark ? "text-purple-400" : "text-purple-600"
                  }`}
                />
              </div>
              <h2
                className={`text-xl font-bold ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                AI Creator Search
              </h2>
            </div>
            <button
              onClick={handleClose}
              className={`p-2 rounded-full transition-colors cursor-pointer ${
                isDark
                  ? "hover:bg-gray-700 text-gray-400"
                  : "hover:bg-gray-100 text-gray-500"
              }`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p
            className={`mt-2 text-sm ${
              isDark ? "text-gray-400" : "text-gray-600"
            }`}
          >
            Find creators using natural language and AI-powered search
          </p>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-4">
          {/* Topic Field */}
          <div>
            <label
              className={`block text-sm font-medium mb-3 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              Topic / Description *
            </label>
            <div className="relative ">
              <textarea
                value={aiSearch.topic}
                onChange={(e) => onUpdateAISearch({ topic: e.target.value })}
                placeholder="e.g., Fashion influencers who create outfit videos, cooking content creators, tech reviewers..."
                rows={3}
                className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 resize-none ${
                  isDark
                    ? "bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-purple-500 focus:bg-gray-700"
                    : "bg-gray-50/50 border-gray-200 text-gray-900 placeholder-gray-500 focus:border-purple-500 focus:bg-white"
                } focus:outline-none focus:ring-4 focus:ring-purple-500/20`}
              />
              <div
                className={`absolute bottom-2 right-3 text-xs ${
                  isDark ? "text-gray-500" : "text-gray-400"
                }`}
              >
                {aiSearch.topic.length}/500
              </div>
            </div>
          </div>

          {/* Keywords Field */}
          <div>
            <label
              className={`block text-sm font-medium mb-3 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              Keywords (comma-separated)
            </label>
            <input
              type="text"
              value={aiSearch.keywords}
              onChange={(e) => onUpdateAISearch({ keywords: e.target.value })}
              placeholder="e.g., style, outfit, fashion, trending, viral"
              className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 ${
                isDark
                  ? "bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus:bg-gray-700"
                  : "bg-gray-50/50 border-gray-200 text-gray-900 placeholder-gray-500 focus:border-blue-500 focus:bg-white"
              } focus:outline-none focus:ring-4 focus:ring-blue-500/20`}
            />
          </div>

          {/* Location Field */}
          <div>
            <label
              className={`block text-sm font-medium mb-3 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              Location
            </label>
            <input
              type="text"
              value={aiSearch.location || ""}
              onChange={(e) => onUpdateAISearch({ location: e.target.value })}
              placeholder="e.g., United States, New York, Global"
              className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 ${
                isDark
                  ? "bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-green-500 focus:bg-gray-700"
                  : "bg-gray-50/50 border-gray-200 text-gray-900 placeholder-gray-500 focus:border-green-500 focus:bg-white"
              } focus:outline-none focus:ring-4 focus:ring-green-500/20`}
            />
          </div>

          {/* Platform Field */}
          <div>
            <label
              className={`block text-sm font-medium mb-3 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              Platform *
            </label>
            <div className="grid grid-cols-2 gap-3">
              {/* Instagram Option */}
              <button
                type="button"
                onClick={() => onUpdateAISearch({ platform: "instagram" })}
                className={`relative p-4 rounded-xl border-2 transition-all duration-200 ${
                  aiSearch.platform === "instagram"
                    ? isDark
                      ? "border-pink-500 bg-pink-500/10"
                      : "border-pink-500 bg-pink-50"
                    : isDark
                    ? "border-gray-600 hover:border-gray-500 bg-gray-700/50"
                    : "border-gray-200 hover:border-gray-300 bg-gray-50/50"
                } hover:scale-105 transform`}
              >
                <div className="flex flex-col items-center space-y-2">
                  <div
                    className={`p-3 rounded-full ${
                      aiSearch.platform === "instagram"
                        ? "bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500"
                        : isDark
                        ? "bg-gray-600"
                        : "bg-gray-300"
                    }`}
                  >
                    <FontAwesomeIcon
                      icon={faInstagram}
                      className="w-6 h-6 text-white"
                    />
                  </div>
                  <span
                    className={`font-semibold text-sm ${
                      aiSearch.platform === "instagram"
                        ? isDark
                          ? "text-pink-400"
                          : "text-pink-600"
                        : isDark
                        ? "text-gray-300"
                        : "text-gray-700"
                    }`}
                  >
                    Instagram
                  </span>
                </div>
                {aiSearch.platform === "instagram" && (
                  <div
                    className={`absolute -top-1 -right-1 w-4 h-4 rounded-full border-2 ${
                      isDark
                        ? "bg-pink-500 border-gray-800"
                        : "bg-pink-500 border-white"
                    }`}
                  />
                )}
              </button>

              {/* TikTok Option */}
              <button
                type="button"
                onClick={() => onUpdateAISearch({ platform: "tiktok" })}
                className={`relative p-4 rounded-xl border-2 transition-all duration-200 ${
                  aiSearch.platform === "tiktok"
                    ? isDark
                      ? "border-red-500 bg-red-500/10"
                      : "border-red-500 bg-red-50"
                    : isDark
                    ? "border-gray-600 hover:border-gray-500 bg-gray-700/50"
                    : "border-gray-200 hover:border-gray-300 bg-gray-50/50"
                } hover:scale-105 transform`}
              >
                <div className="flex flex-col items-center space-y-2">
                  <div
                    className={`p-3 rounded-full ${
                      aiSearch.platform === "tiktok"
                        ? "bg-black"
                        : isDark
                        ? "bg-gray-600"
                        : "bg-gray-300"
                    }`}
                  >
                    <FontAwesomeIcon
                      icon={faTiktok}
                      className={`w-6 h-6 ${
                        aiSearch.platform === "tiktok"
                          ? "text-white"
                          : "text-white"
                      }`}
                    />
                  </div>
                  <span
                    className={`font-semibold text-sm ${
                      aiSearch.platform === "tiktok"
                        ? isDark
                          ? "text-red-400"
                          : "text-red-600"
                        : isDark
                        ? "text-gray-300"
                        : "text-gray-700"
                    }`}
                  >
                    TikTok
                  </span>
                </div>
                {aiSearch.platform === "tiktok" && (
                  <div
                    className={`absolute -top-1 -right-1 w-4 h-4 rounded-full border-2 ${
                      isDark
                        ? "bg-red-500 border-gray-800"
                        : "bg-red-500 border-white"
                    }`}
                  />
                )}
              </button>
            </div>
          </div>

          {/* Search Results Field */}
          <div>
            <label
              className={`block text-sm font-medium mb-3 ${
                isDark ? "text-gray-300" : "text-gray-700"
              }`}
            >
              Number of Results
            </label>
            <select
              value={aiSearch.search_results}
              onChange={(e) =>
                onUpdateAISearch({
                  search_results: parseInt(e.target.value),
                })
              }
              className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 ${
                isDark
                  ? "bg-gray-700/50 border-gray-600 text-white focus:border-orange-500 focus:bg-gray-700"
                  : "bg-gray-50/50 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white"
              } focus:outline-none focus:ring-4 focus:ring-orange-500/20`}
            >
              <option value={1}>1 result</option>
              <option value={2}>2 results</option>
              <option value={3}>3 results</option>
              <option value={4}>4 results</option>
              <option value={5}>5 results</option>
              <option value={6}>6 results</option>
              <option value={7}>7 results</option>
              <option value={8}>8 results</option>
              <option value={9}>9 results</option>
              <option value={10}>10 results</option>
            </select>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-6">
            <button
              onClick={handleClose}
              disabled={isLoading}
              className={`flex-1 px-6 py-3 rounded-xl border-2 font-semibold transition-all duration-200 ${
                isDark
                  ? "border-gray-600 text-gray-300 hover:bg-gray-700 hover:border-gray-500 disabled:opacity-50"
                  : "border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400 disabled:opacity-50"
              } transform hover:scale-105 disabled:hover:scale-100`}
            >
              Cancel
            </button>
            <button
              onClick={handleSearch}
              disabled={
                isLoading || !aiSearch.topic.trim() || !aiSearch.platform
              }
              className={`flex-1 px-6 py-3 rounded-xl font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 disabled:hover:scale-100 ${
                isDark
                  ? "bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 hover:from-purple-700 hover:via-blue-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-purple-500/25"
                  : "bg-gradient-to-r from-purple-500 via-blue-500 to-indigo-500 hover:from-purple-600 hover:via-blue-600 hover:to-indigo-600 text-white shadow-lg hover:shadow-purple-500/25"
              }`}
            >
              {isLoading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Searching...
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  Search
                </div>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
