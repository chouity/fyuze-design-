import { createClient } from "@supabase/supabase-js";
import type { Database } from "../../database.types";

// Supabase configuration
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "your-supabase-url";
const supabaseAnonKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY || "your-supabase-anon-key";

// Environment detection for proper API routing
// Manual override for quick testing (uncomment one line below):
// const isProduction = true;  // Force Supabase functions
// const isProduction = false; // Force local agent

const isProduction =
  import.meta.env.VITE_FORCE_PRODUCTION === "true"
    ? true
    : import.meta.env.VITE_FORCE_DEVELOPMENT === "true"
    ? false
    : import.meta.env.MODE === "production";

// Development configuration (only used in development)
const DEV_API_URL = import.meta.env.VITE_DEV_API_URL || "http://localhost:8000";
const PROD_API_URL = "https://iwoihtzagjtmrsihfwfv.supabase.co/functions/v1";
// Create Supabase client with proper typing
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Generic type for function call responses
export interface FunctionResponse<T = any> {
  data: T | null;
  error: any | null;
}

// Generic helper for calling database functions
export async function callDatabaseFunction<T = any>(
  functionName: keyof Database["public"]["Functions"],
  payload: Record<string, any> = {}
): Promise<FunctionResponse<T>> {
  try {
    const { data, error } = await supabase.rpc(functionName as any, {
      payload,
    });

    if (error) {
      return { data: null, error };
    }

    return { data: data as T, error: null };
  } catch (err) {
    return { data: null, error: err };
  }
}

export async function getCreators(params: Record<string, any>) {
  callDatabaseFunction("get_creators", params);
}

export async function getLocations(params: Record<string, any>) {
  return callDatabaseFunction("get_locations", params);
}

export async function getPlatforms() {
  return callDatabaseFunction("get_creator_platforms");
}
export async function getCategories() {
  return callDatabaseFunction("get_creator_categories");
}

export async function handleSignOut() {
  const { error } = await supabase.auth.signOut();
  if (error) {
  } else {
  }
}
export async function createUserSession() {
  return callDatabaseFunction("create_user_session");
}

//contact form functions
export async function addContactMessage(payload: Record<string, any>) {
  try {
    const result = await callDatabaseFunction("add_contact_message", payload);

    if (result.error) {
      return {
        data: null,
        status: "error",
        message: result.error.message || "Failed to submit message",
      };
    }

    return {
      data: result.data,
      status: "success",
      message: "Message submitted successfully",
    };
  } catch (error) {
    return {
      data: null,
      status: "error",
      message: "An unexpected error occurred",
    };
  }
}

export async function getContactMessages(params?: {
  status?: string;
  from?: string;
  to?: string;
  limit?: number;
  offset?: number;
}) {
  try {
    const result = await callDatabaseFunction(
      "get_contact_messages",
      params || {}
    );

    if (result.error) {
      return {
        data: null,
        status: "error",
        message: result.error.message || "Failed to fetch messages",
      };
    }

    return {
      data: result.data,
      status: "success",
      message: "Messages fetched successfully",
    };
  } catch (error) {
    return {
      data: null,
      status: "error",
      message: "An unexpected error occurred",
    };
  }
}
export async function updateContactMessageStatus(params: {
  id: string;
  status: string;
}) {
  try {
    const result = await callDatabaseFunction(
      "update_contact_message_status",
      params
    );

    if (result.error) {
      return {
        data: null,
        status: "error",
        message: result.error.message || "Failed to update message status",
      };
    }

    return {
      data: result.data,
      status: "success",
      message: "Message status updated successfully",
    };
  } catch (error) {
    return {
      data: null,
      status: "error",
      message: "An unexpected error occurred",
    };
  }
}
export async function searchContactMessage(params: { query: string }) {
  try {
    const result = await callDatabaseFunction(
      "search_contact_messages",
      params
    );

    if (result.error) {
      return {
        data: null,
        status: "error",
        message: result.error.message || "Failed to search message ",
      };
    }

    return {
      data: result.data,
      status: "success",
      message: "messages fetched successfully",
    };
  } catch (error) {
    return {
      data: null,
      status: "error",
      message: "An unexpected error occurred",
    };
  }
}

export async function deleteContactMessage(params: { id: string }) {
  try {
    const result = await callDatabaseFunction("delete_contact_message", params);

    if (result.error) {
      return {
        data: null,
        status: "error",
        message: result.error.message || "Failed to delete message",
      };
    }

    return {
      data: result.data,
      status: "success",
      message: "Message deleted successfully",
    };
  } catch (error) {
    // ...existing code...
    return {
      data: null,
      status: "error",
      message: "An unexpected error occurred",
    };
  }
}
//end

export async function fyuzeAICreators(
  session_id: string,
  message: string,
  userId: string
) {
  const {
    data: { session },
    error,
  } = await supabase.auth.getSession();

  if (error || !session) {
    throw new Error("No active session found");
  }

  const baseUrl = isProduction ? PROD_API_URL : DEV_API_URL;

  try {
    const res = await fetch(`${baseUrl}/find-influencers`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({
        message,
        user_id: userId,
        session_id: session_id,
      }),
    });

    const data = await res.json();

    // Check for API error responses
    if (data.error) {
      // This will trigger our middleware error handling
      const error = new Error(data.message || "API request failed");
      (error as any).status = data.code || 500;
      (error as any).apiError = data;
      throw error;
    }

    // Check for HTTP errors
    if (!res.ok) {
      const error = new Error(`HTTP ${res.status}: ${res.statusText}`);
      (error as any).status = res.status;
      throw error;
    }

    return data;
  } catch (error) {
    // Re-throw to be handled by the calling code
    throw error;
  }
}

export async function searchTiktokCreators(
  topic: string,
  location: string,
  platform: string,
  search_results: number,
  keyword?: string[]
) {
  const requestBody = {
    location,
    platform: platform,
    topic: topic,
    search_results: search_results,
    keywords: keyword || [],
  };
  const {
    data: { session },
    error,
  } = await supabase.auth.getSession();
  if (error || !session) {
    throw new Error("No active session found");
  }

  try {
    const baseUrl = isProduction ? PROD_API_URL : DEV_API_URL;
    const res = await fetch(`${baseUrl}/search_tiktok_influencers`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify(requestBody),
    });

    const data = await res.json();

    // Check for API error responses first
    if (data.error) {
      const error = new Error(
        data.message || data.error || "TikTok search failed"
      );
      (error as any).status = data.code || 500;
      (error as any).apiError = data;
      throw error;
    }

    // Check for HTTP errors
    if (!res.ok) {
      const error = new Error(`HTTP ${res.status}: ${res.statusText}`);
      (error as any).status = res.status;
      throw error;
    }

    return data;
  } catch (error) {
    // Re-throw to be handled by the calling code
    throw error;
  }
}

export async function searchCreators(
  topic: string,
  location: string,
  platform: string,
  search_results: number,
  keyword?: string[]
) {
  const requestBody = {
    location,
    platform: platform,
    topic: topic,
    search_results: search_results,
    keywords: keyword || [],
  };

  const {
    data: { session },
    error,
  } = await supabase.auth.getSession();
  if (error || !session) {
    throw new Error("No active session found");
  }
  try {
    const baseUrl = isProduction ? PROD_API_URL : DEV_API_URL;
    const res = await fetch(`${baseUrl}/search_insta_influencers`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify(requestBody),
    });

    const data = await res.json();

    // Check for API error responses first
    if (data.error) {
      const error = new Error(
        data.message || data.error || "Instagram search failed"
      );
      (error as any).status = data.code || 500;
      (error as any).apiError = data;
      throw error;
    }

    // Check for HTTP errors
    if (!res.ok) {
      const error = new Error(`HTTP ${res.status}: ${res.statusText}`);
      (error as any).status = res.status;
      throw error;
    }

    return data;
  } catch (error) {
    // Re-throw to be handled by the calling code
    throw error;
  }
}

export async function UrlAnalyzer(url: string) {
  const {
    data: { session },
    error,
  } = await supabase.auth.getSession();

  if (error || !session) {
    throw new Error("No active session found");
  }

  try {
    // Use a dedicated URL analyzer endpoint or adapt the existing one
    const baseUrl = isProduction ? PROD_API_URL : DEV_API_URL;
    const res = await fetch(`${baseUrl}/analyze_website`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({
        url,
      }),
    });

    const data = await res.json();

    // Check for API error responses first
    if (data.error) {
      const error = new Error(
        data.message || data.error || "Website analysis failed"
      );
      (error as any).status = data.code || 500;
      (error as any).apiError = data;
      throw error;
    }

    // Check for HTTP errors
    if (!res.ok) {
      const error = new Error(`HTTP ${res.status}: ${res.statusText}`);
      (error as any).status = res.status;
      throw error;
    }

    return {
      data: data.data || data,
      error: null,
    };
  } catch (err) {
    // Re-throw to be handled by the calling code
    return {
      data: null,
      error: err instanceof Error ? err : new Error("Failed to analyze URL"),
    };
  }
}

export async function SeatchEngine(query: string, gl: string) {
  const {
    data: { session },
    error,
  } = await supabase.auth.getSession();

  if (error || !session) {
    throw new Error("No active session found");
  }

  try {
    const baseUrl = isProduction ? PROD_API_URL : DEV_API_URL;
    const res = await fetch(`${baseUrl}/basic_search`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({
        query,
        gl,
      }),
    });

    const data = await res.json();

    // Check for API error responses first
    if (data.error) {
      const error = new Error(data.message || data.error || "Search failed");
      (error as any).status = data.code || 500;
      (error as any).apiError = data;
      throw error;
    }

    // Check for HTTP errors
    if (!res.ok) {
      const error = new Error(`HTTP ${res.status}: ${res.statusText}`);
      (error as any).status = res.status;
      throw error;
    }

    return {
      data: data.data || data,
      error: null,
    };
  } catch (err) {
    // Re-throw to be handled by the calling code
    return {
      data: null,
      error: err instanceof Error ? err : new Error("Failed to search"),
    };
  }
}
export default supabase;
