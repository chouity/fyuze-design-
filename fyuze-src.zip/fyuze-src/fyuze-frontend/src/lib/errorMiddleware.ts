// Error middleware for handling API responses and errors globally
import type { FunctionResponse } from "./supabaseClient";

export interface ErrorMiddlewareConfig {
  showToast?: (
    message: string,
    type: "error" | "success" | "warning" | "info"
  ) => void;
  logErrors?: boolean;
  retryAttempts?: number;
  retryDelay?: number;
}

export class ApiError extends Error {
  public status?: number;
  public code?: string;
  public details?: any;

  constructor(message: string, status?: number, code?: string, details?: any) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

let globalConfig: ErrorMiddlewareConfig = {
  logErrors: true,
  retryAttempts: 0,
  retryDelay: 1000,
};

export function configureErrorMiddleware(config: ErrorMiddlewareConfig) {
  globalConfig = { ...globalConfig, ...config };
}

// Middleware for fetch API calls
export async function fetchWithErrorHandling(
  url: string,
  options: RequestInit = {},
  customConfig: Partial<ErrorMiddlewareConfig> = {}
): Promise<Response> {
  const config = { ...globalConfig, ...customConfig };
  let lastError: Error;

  for (let attempt = 0; attempt <= (config.retryAttempts || 0); attempt++) {
    try {
      const response = await fetch(url, options);

      if (!response.ok) {
        const errorMessage = await getErrorMessage(response);
        const error = new ApiError(
          errorMessage,
          response.status,
          response.status.toString(),
          { url, attempt }
        );

        if (config.logErrors) {
          console.error("Fetch error:", error);
        }

        // Show toast for client errors (4xx) and server errors (5xx)
        if (config.showToast && response.status >= 400) {
          config.showToast(errorMessage, "error");
        }

        throw error;
      }

      return response;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error("Unknown error");

      if (config.logErrors) {
        console.error(`Fetch attempt ${attempt + 1} failed:`, lastError);
      }

      // If this is the last attempt or not a retryable error, throw
      if (
        attempt === (config.retryAttempts || 0) ||
        !isRetryableError(lastError)
      ) {
        if (config.showToast && !(lastError instanceof ApiError)) {
          config.showToast(
            lastError.message || "Network error occurred",
            "error"
          );
        }
        throw lastError;
      }

      // Wait before retrying
      if (config.retryDelay && attempt < (config.retryAttempts || 0)) {
        await new Promise((resolve) => setTimeout(resolve, config.retryDelay));
      }
    }
  }

  throw lastError!;
}

// Middleware for Supabase function responses
export function handleSupabaseResponse<T>(
  response: FunctionResponse<T>,
  customConfig: Partial<ErrorMiddlewareConfig> = {}
): FunctionResponse<T> {
  const config = { ...globalConfig, ...customConfig };

  if (response.error) {
    const errorMessage = extractErrorMessage(response.error);
    const error = new ApiError(
      errorMessage,
      undefined,
      undefined,
      response.error
    );

    if (config.logErrors) {
      console.error("Supabase function error:", error);
    }

    if (config.showToast) {
      config.showToast(errorMessage, "error");
    }

    // Return the original response structure but with enhanced error
    return {
      data: null,
      error: error,
    };
  }

  return response;
}

// Wrapper for successful operations
export function handleSuccess<T>(
  data: T,
  message?: string,
  customConfig: Partial<ErrorMiddlewareConfig> = {}
): FunctionResponse<T> {
  const config = { ...globalConfig, ...customConfig };

  if (config.showToast && message) {
    config.showToast(message, "success");
  }

  return {
    data,
    error: null,
  };
}

// Utility functions
async function getErrorMessage(response: Response): Promise<string> {
  try {
    const contentType = response.headers.get("content-type");

    if (contentType?.includes("application/json")) {
      const errorData = await response.json();
      return (
        errorData.message ||
        errorData.error ||
        `HTTP ${response.status}: ${response.statusText}`
      );
    } else {
      const text = await response.text();
      return text || `HTTP ${response.status}: ${response.statusText}`;
    }
  } catch {
    return `HTTP ${response.status}: ${response.statusText}`;
  }
}

function extractErrorMessage(error: any): string {
  if (typeof error === "string") {
    return error;
  }

  if (error && typeof error === "object") {
    return (
      error.message ||
      error.error ||
      error.details ||
      "An unknown error occurred"
    );
  }

  return "An unknown error occurred";
}

function isRetryableError(error: Error): boolean {
  // Retry on network errors, timeouts, and 5xx server errors
  if (error instanceof ApiError) {
    return error.status ? error.status >= 500 : false;
  }

  // Retry on network failures
  return error.name === "TypeError" && error.message.includes("fetch");
}

// Enhanced error boundary for React components
export function withErrorHandling<T extends (...args: any[]) => any>(
  fn: T,
  customConfig: Partial<ErrorMiddlewareConfig> = {}
): T {
  return ((...args: any[]) => {
    const config = { ...globalConfig, ...customConfig };

    try {
      const result = fn(...args);

      // Handle promises
      if (result && typeof result.then === "function") {
        return result.catch((error: Error) => {
          if (config.logErrors) {
            console.error("Function error:", error);
          }

          if (config.showToast) {
            config.showToast(error.message || "An error occurred", "error");
          }

          throw error;
        });
      }

      return result;
    } catch (error) {
      const err = error instanceof Error ? error : new Error("Unknown error");

      if (config.logErrors) {
        console.error("Function error:", err);
      }

      if (config.showToast) {
        config.showToast(err.message || "An error occurred", "error");
      }

      throw err;
    }
  }) as T;
}
