// Query key factory for consistent cache management
export const queryKeys = {
  // Creators queries
  creators: {
    all: ["creators"] as const,
    lists: () => [...queryKeys.creators.all, "list"] as const,
    list: (filters: Record<string, any>) =>
      [...queryKeys.creators.lists(), filters] as const,
    details: () => [...queryKeys.creators.all, "detail"] as const,
    detail: (id: string) => [...queryKeys.creators.details(), id] as const,
  },

  // Users queries
  users: {
    all: ["users"] as const,
    lists: () => [...queryKeys.users.all, "list"] as const,
    list: (filters: Record<string, any>) =>
      [...queryKeys.users.lists(), filters] as const,
    details: () => [...queryKeys.users.all, "detail"] as const,
    detail: (id: string) => [...queryKeys.users.details(), id] as const,
  },

  // Analytics queries
  analytics: {
    all: ["analytics"] as const,
    dashboard: () => [...queryKeys.analytics.all, "dashboard"] as const,
    reports: () => [...queryKeys.analytics.all, "reports"] as const,
    report: (id: string) => [...queryKeys.analytics.reports(), id] as const,
  },

  // Generic function queries
  functions: {
    all: ["functions"] as const,
    function: (name: string, params: Record<string, any>) =>
      [...queryKeys.functions.all, name, params] as const,
  },
} as const;
