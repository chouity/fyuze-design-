// Global API Error Interceptor
// This automatically catches ALL API errors and shows appropriate toasts

let globalToastFunction:
  | ((message: string, type: "error" | "success" | "warning" | "info") => void)
  | null = null;
let isInitialized = false;

// Deduplication mechanism to prevent showing the same error multiple times
const recentErrors = new Set<string>();
const ERROR_DEDUP_TIMEOUT = 2000; // 2 seconds

function shouldShowError(errorKey: string): boolean {
  if (recentErrors.has(errorKey)) {
    return false;
  }

  recentErrors.add(errorKey);
  setTimeout(() => {
    recentErrors.delete(errorKey);
  }, ERROR_DEDUP_TIMEOUT);

  return true;
}

function createErrorKey(errorData: any): string {
  if (typeof errorData === "string") {
    return errorData;
  }

  if (errorData && typeof errorData === "object") {
    const message = errorData.message || errorData.error || "unknown";
    const code = errorData.code || "";
    return `${code}-${message}`;
  }

  return "unknown-error";
}

// Initialize the global error handler
export function initializeGlobalErrorHandler(
  showToast: (
    message: string,
    type: "error" | "success" | "warning" | "info"
  ) => void
) {
  // Prevent multiple initializations
  if (isInitialized) {
    globalToastFunction = showToast; // Update toast function but don't re-setup handlers
    return;
  }

  globalToastFunction = showToast;
  setupGlobalErrorHandlers();
  isInitialized = true;
}

// Setup global error handlers
function setupGlobalErrorHandlers() {
  // Intercept fetch globally
  const originalFetch = window.fetch;

  window.fetch = async (...args) => {
    try {
      const response = await originalFetch(...args);

      // Clone response to read it without consuming the original
      const responseClone = response.clone();

      // Check if this looks like an API response that might have errors
      const contentType = response.headers.get("content-type");
      if (
        contentType &&
        contentType.includes("application/json") &&
        !response.ok
      ) {
        try {
          const data = await responseClone.json();

          // Check for API error responses
          if (data && (data.error || data.code || data.message)) {
            const errorKey = createErrorKey(data);

            if (shouldShowError(errorKey) && globalToastFunction) {
              const errorMessage = extractErrorMessage(data);

              console.log(
                "[GlobalErrorHandler] Fetch interceptor - showing toast for:",
                errorKey
              );

              // Show specific toast for credit errors
              if (data.code === 403 && data.message?.includes("credits")) {
                // globalToastFunction(
                //   "No credits available. Please upgrade your subscription to continue.",
                //   "error"
                // );
              } else {
                globalToastFunction(errorMessage, "error");
              }
            }
          }
        } catch (jsonError) {
          // If we can't parse JSON, just show the HTTP error
          if (globalToastFunction && response.status >= 400) {
            globalToastFunction(
              `HTTP ${response.status}: ${response.statusText}`,
              "error"
            );
          }
        }
      }

      return response;
    } catch (error) {
      // Handle network errors
      if (globalToastFunction && error instanceof Error) {
        if (error.name === "TypeError" && error.message.includes("fetch")) {
          globalToastFunction(
            "Network error. Please check your connection.",
            "error"
          );
        } else {
          globalToastFunction(error.message, "error");
        }
      }
      throw error;
    }
  };

  // Intercept unhandled promise rejections (for API calls that don't handle errors)
  window.addEventListener("unhandledrejection", (event) => {
    const error = event.reason;

    if (error instanceof Error && globalToastFunction) {
      // Check if this looks like an API error
      const apiError = (error as any).apiError;
      if (apiError) {
        const errorKey = createErrorKey(apiError);

        if (shouldShowError(errorKey)) {
          const errorMessage = extractErrorMessage(apiError);

          console.log(
            "[GlobalErrorHandler] Unhandled rejection - showing toast for:",
            errorKey
          );

          if (apiError.code === 403 && apiError.message?.includes("credits")) {
            // globalToastFunction(
            //   "No credits available. Please upgrade your subscription to continue.",
            //   "error"
            // );
          } else {
            globalToastFunction(errorMessage, "error");
          }
        }

        // Prevent the error from being logged to console
        event.preventDefault();
      }
    }
  });

  // Intercept console.error to catch logged API errors
  const originalConsoleError = console.error;
  console.error = (...args) => {
    // Call original console.error
    originalConsoleError(...args);

    // Check if any argument looks like an API error
    for (const arg of args) {
      if (
        arg &&
        typeof arg === "object" &&
        (arg.error || arg.code || arg.message)
      ) {
        const errorKey = createErrorKey(arg);

        if (shouldShowError(errorKey) && globalToastFunction) {
          const errorMessage = extractErrorMessage(arg);

          console.log(
            "[GlobalErrorHandler] Console interceptor - showing toast for:",
            errorKey
          );

          if (arg.code === 403 && arg.message?.includes("credits")) {
            // globalToastFunction(
            //   "No credits available. Please upgrade your subscription to continue.",
            //   "error"
            // );
          } else if (errorMessage && !errorMessage.includes("Failed to")) {
            // Only show toast for API errors, not generic failures
            globalToastFunction(errorMessage, "error");
          }
        }
        break;
      }
    }
  };
}

// Helper function to extract error message
function extractErrorMessage(errorData: any): string {
  if (typeof errorData === "string") {
    return errorData;
  }

  if (errorData && typeof errorData === "object") {
    return (
      errorData.message ||
      errorData.error ||
      errorData.details ||
      `Error ${errorData.code || ""}`.trim() ||
      "An unknown error occurred"
    );
  }

  return "An unknown error occurred";
}

// Helper function to show success toasts manually
export function showSuccessToast(message: string) {
  if (globalToastFunction) {
    globalToastFunction(message, "success");
  }
}

// Helper function to show error toasts manually
export function showErrorToast(message: string) {
  if (globalToastFunction) {
    globalToastFunction(message, "error");
  }
}

// Helper function to show warning toasts manually
export function showWarningToast(message: string) {
  if (globalToastFunction) {
    globalToastFunction(message, "warning");
  }
}

// Helper function to show info toasts manually
export function showInfoToast(message: string) {
  if (globalToastFunction) {
    globalToastFunction(message, "info");
  }
}
