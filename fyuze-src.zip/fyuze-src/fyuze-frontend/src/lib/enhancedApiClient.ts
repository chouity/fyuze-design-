// Enhanced supabase client with error middleware integration
import { supabase, callDatabaseFunction } from './supabaseClient';
import type { Database } from '../../database.types';
import { 
  fetchWithErrorHandling, 
  handleSupabaseResponse, 
  handleSuccess,
  configureErrorMiddleware 
} from './errorMiddleware';
import type { FunctionResponse } from './supabaseClient';

// Enhanced wrapper for Supabase RPC functions with error handling
export async function callDatabaseFunctionWithErrorHandling<T = any>(
  functionName: keyof Database["public"]["Functions"],
  payload: Record<string, any> = {},
  options: {
    successMessage?: string;
    showSuccessToast?: boolean;
    showErrorToast?: boolean;
  } = {}
): Promise<FunctionResponse<T>> {
  try {
    const response = await callDatabaseFunction<T>(functionName, payload);
    
    // Handle the response with middleware
    const processedResponse = handleSupabaseResponse(response, {
      showToast: options.showErrorToast !== false ? globalConfig.showToast : undefined
    });
    
    // Show success toast if needed
    if (processedResponse.data && options.successMessage && options.showSuccessToast) {
      return handleSuccess(processedResponse.data, options.successMessage);
    }
    
    return processedResponse;
  } catch (error) {
    // This should rarely happen as callDatabaseFunction handles most errors
    const errorResponse: FunctionResponse<T> = {
      data: null,
      error: error instanceof Error ? error : new Error('Unknown error occurred')
    };
    
    return handleSupabaseResponse(errorResponse, {
      showToast: options.showErrorToast !== false ? globalConfig.showToast : undefined
    });
  }
}

// Enhanced wrapper for fetch API calls
export async function fetchWithToastHandling(
  url: string,
  options: RequestInit = {},
  config: {
    successMessage?: string;
    showSuccessToast?: boolean;
    showErrorToast?: boolean;
    retryAttempts?: number;
  } = {}
): Promise<Response> {
  const response = await fetchWithErrorHandling(url, options, {
    showToast: config.showErrorToast !== false ? globalConfig.showToast : undefined,
    retryAttempts: config.retryAttempts,
  });
  
  // Show success toast if configured
  if (config.successMessage && config.showSuccessToast && globalConfig.showToast) {
    globalConfig.showToast(config.successMessage, 'success');
  }
  
  return response;
}

// Global configuration placeholder (will be set by the app)
let globalConfig: { showToast?: (message: string, type: 'error' | 'success' | 'warning' | 'info') => void } = {};

// Function to initialize the middleware with toast function
export function initializeErrorMiddleware(showToast: (message: string, type: 'error' | 'success' | 'warning' | 'info') => void) {
  globalConfig.showToast = showToast;
  
  configureErrorMiddleware({
    showToast,
    logErrors: true,
    retryAttempts: 1,
    retryDelay: 1000,
  });
}

// Enhanced API functions with error handling
export const enhancedApiClient = {
  // Contact form functions with error handling
  async addContactMessage(payload: Record<string, any>) {
    return callDatabaseFunctionWithErrorHandling(
      'add_contact_message',
      payload,
      {
        successMessage: 'Message submitted successfully!',
        showSuccessToast: true,
      }
    );
  },

  async getContactMessages(params?: Record<string, any>) {
    return callDatabaseFunctionWithErrorHandling(
      'get_contact_messages',
      params || {},
      {
        showErrorToast: true,
      }
    );
  },

  async updateContactMessage(payload: Record<string, any>) {
    return callDatabaseFunctionWithErrorHandling(
      'update_contact_message_status',
      payload,
      {
        successMessage: 'Message updated successfully!',
        showSuccessToast: true,
      }
    );
  },

  async deleteContactMessage(payload: Record<string, any>) {
    return callDatabaseFunctionWithErrorHandling(
      'delete_contact_message',
      payload,
      {
        successMessage: 'Message deleted successfully!',
        showSuccessToast: true,
      }
    );
  },

  // Creator functions with error handling
  async getCreators(params: Record<string, any> = {}) {
    return callDatabaseFunctionWithErrorHandling(
      'get_creators',
      params,
      {
        showErrorToast: true,
      }
    );
  },

  async getLocations(params: Record<string, any> = {}) {
    return callDatabaseFunctionWithErrorHandling(
      'get_locations',
      params,
      {
        showErrorToast: true,
      }
    );
  },

  async getPlatforms() {
    return callDatabaseFunctionWithErrorHandling(
      'get_creator_platforms',
      {},
      {
        showErrorToast: true,
      }
    );
  },

  async getCategories() {
    return callDatabaseFunctionWithErrorHandling(
      'get_creator_categories',
      {},
      {
        showErrorToast: true,
      }
    );
  },

  // External API calls with error handling
  async searchCreators(
    topic: string,
    location: string,
    platform: string,
    search_results: number,
    keyword?: string[]
  ) {
    const {
      data: { session },
      error,
    } = await supabase.auth.getSession();
    
    if (error || !session) {
      if (globalConfig.showToast) {
        globalConfig.showToast('Please log in to search creators', 'error');
      }
      throw new Error('No active session found');
    }

    const requestBody = {
      location,
      platform,
      topic,
      search_results,
      keywords: keyword || [],
    };

    const isProduction = import.meta.env.MODE === 'production';
    const baseUrl = isProduction 
      ? 'https://iwoihtzagjtmrsihfwfv.supabase.co/functions/v1'
      : import.meta.env.VITE_DEV_API_URL || 'http://localhost:8000';

    const endpoint = platform === 'tiktok' 
      ? `${baseUrl}/search_tiktok_influencers`
      : `${baseUrl}/search_insta_influencers`;

    const response = await fetchWithToastHandling(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify(requestBody),
    }, {
      showErrorToast: true,
      retryAttempts: 1,
    });

    return response.json();
  },

  async analyzeUrl(url: string) {
    const {
      data: { session },
      error,
    } = await supabase.auth.getSession();

    if (error || !session) {
      if (globalConfig.showToast) {
        globalConfig.showToast('Please log in to analyze URLs', 'error');
      }
      throw new Error('No active session found');
    }

    const isProduction = import.meta.env.MODE === 'production';
    const baseUrl = isProduction 
      ? 'https://iwoihtzagjtmrsihfwfv.supabase.co/functions/v1'
      : import.meta.env.VITE_DEV_API_URL || 'http://localhost:8000';

    const response = await fetchWithToastHandling(`${baseUrl}/analyze_website`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({ url }),
    }, {
      successMessage: 'URL analyzed successfully!',
      showSuccessToast: true,
      showErrorToast: true,
      retryAttempts: 1,
    });

    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error);
    }

    return {
      data: data.data || data,
      error: null,
    };
  },

  async searchEngine(query: string, gl: string) {
    const {
      data: { session },
      error,
    } = await supabase.auth.getSession();

    if (error || !session) {
      if (globalConfig.showToast) {
        globalConfig.showToast('Please log in to search', 'error');
      }
      throw new Error('No active session found');
    }

    const isProduction = import.meta.env.MODE === 'production';
    const baseUrl = isProduction 
      ? 'https://iwoihtzagjtmrsihfwfv.supabase.co/functions/v1'
      : import.meta.env.VITE_DEV_API_URL || 'http://localhost:8000';

    const response = await fetchWithToastHandling(`${baseUrl}/basic_search`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({ query, gl }),
    }, {
      showErrorToast: true,
      retryAttempts: 1,
    });

    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error);
    }

    return {
      data: data.data || data,
      error: null,
    };
  },
};

export default enhancedApiClient;