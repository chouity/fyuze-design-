// Geolocation utility to detect user's country from IP address

export interface LocationData {
  country: string;
  countryCode: string;
  region?: string;
  city?: string;
  ip?: string;
}

// Free IP geolocation services (with fallbacks)
const GEOLOCATION_APIS = [
  {
    url: "https://ipapi.co/json/",
    parser: (data: any): LocationData => ({
      country: data.country_name || "Unknown",
      countryCode: data.country_code?.toLowerCase() || "us",
      region: data.region,
      city: data.city,
      ip: data.ip,
    }),
  },
  {
    url: "https://ipinfo.io/json",
    parser: (data: any): LocationData => ({
      country: data.country_name || "Unknown",
      countryCode: data.country?.toLowerCase() || "us",
      region: data.region,
      city: data.city,
      ip: data.ip,
    }),
  },
  {
    url: "https://api.ipgeolocation.io/ipgeo?apiKey=free",
    parser: (data: any): LocationData => ({
      country: data.country_name || "Unknown",
      countryCode: data.country_code2?.toLowerCase() || "us",
      region: data.state_prov,
      city: data.city,
      ip: data.ip,
    }),
  },
];

// Fallback to browser's built-in geolocation (requires user permission)
async function getBrowserLocation(): Promise<LocationData | null> {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve(null);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          // Use reverse geocoding to get country from coordinates
          const { latitude, longitude } = position.coords;
          const response = await fetch(
            `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`
          );
          const data = await response.json();

          resolve({
            country: data.countryName || "Unknown",
            countryCode: data.countryCode?.toLowerCase() || "us",
            region: data.principalSubdivision,
            city: data.city,
          });
        } catch (error) {
          console.error("Reverse geocoding failed:", error);
          resolve(null);
        }
      },
      () => resolve(null),
      { timeout: 10000 }
    );
  });
}

// Main function to detect user's location
export async function detectUserLocation(): Promise<LocationData> {
  console.log("🌍 Detecting user location...");

  // Try IP-based geolocation services
  for (const api of GEOLOCATION_APIS) {
    try {
      console.log(`🔍 Trying API: ${api.url}`);
      const response = await fetch(api.url, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      const location = api.parser(data);

      console.log("✅ Location detected:", location);
      return location;
    } catch (error) {
      console.warn(`❌ Failed to get location from ${api.url}:`, error);
      continue;
    }
  }

  // Fallback to browser geolocation
  console.log("🔍 Trying browser geolocation...");
  const browserLocation = await getBrowserLocation();
  if (browserLocation) {
    console.log("✅ Browser location detected:", browserLocation);
    return browserLocation;
  }

  // Ultimate fallback
  console.log("🔄 Using default location (US)");
  return {
    country: "United States",
    countryCode: "us",
    region: "Unknown",
    city: "Unknown",
  };
}

// Cache location for session to avoid repeated API calls
let cachedLocation: LocationData | null = null;

export async function getUserLocation(): Promise<LocationData> {
  if (cachedLocation) {
    console.log("📋 Using cached location:", cachedLocation);
    return cachedLocation;
  }

  cachedLocation = await detectUserLocation();
  return cachedLocation;
}

// Clear cached location (useful for testing or when user changes VPN)
export function clearLocationCache(): void {
  cachedLocation = null;
  console.log("🗑️ Location cache cleared");
}

// Country code to Google Search country mapping
export function getGoogleSearchCountryCode(countryCode: string): string {
  // Google Search uses specific country codes
  const mapping: Record<string, string> = {
    us: "us",
    ca: "ca",
    gb: "uk",
    au: "au",
    de: "de",
    fr: "fr",
    es: "es",
    it: "it",
    jp: "jp",
    kr: "kr",
    cn: "cn",
    in: "in",
    br: "br",
    mx: "mx",
    ar: "ar",
    cl: "cl",
    co: "co",
    pe: "pe",
    nl: "nl",
    be: "be",
    ch: "ch",
    at: "at",
    dk: "dk",
    fi: "fi",
    no: "no",
    se: "se",
    pl: "pl",
    cz: "cz",
    hu: "hu",
    ru: "ru",
    ua: "ua",
    tr: "tr",
    sa: "sa",
    ae: "ae",
    il: "il",
    eg: "eg",
    za: "za",
    ng: "ng",
    ke: "ke",
    th: "th",
    sg: "sg",
    my: "my",
    id: "id",
    ph: "ph",
    vn: "vn",
    nz: "nz",
    lb: "lb", // Lebanon
    // Add more mappings as needed
  };

  return mapping[countryCode.toLowerCase()] || "us"; // Default to US if not found
}
