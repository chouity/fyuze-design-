// Utility functions for converting human-readable numbers to actual values

/**
 * Formats a number to human-readable format (K, M, B)
 * @param num - The number to format
 * @returns Formatted string (e.g., "1.2K", "3.4M")
 */
export const formatNumber = (num: number | undefined | null): string => {
  // Handle undefined, null, or non-numeric values
  if (num == null || typeof num !== "number" || isNaN(num)) {
    return "0";
  }

  if (num >= 1000000000) {
    return (num / 1000000000).toFixed(1) + "B";
  }
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M";
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + "K";
  }
  return num.toString();
};

/**
 * Converts human-readable number input to actual number
 * Examples:
 * "2" -> 2000 (2K)
 * "2k" -> 2000
 * "2K" -> 2000
 * "1.5M" -> 1500000
 * "500" -> 500 (if less than 1000, treated as actual number)
 * "2000" -> 2000 (if >= 1000, treated as actual number)
 */
export function parseFollowersInput(input: string): number {
  if (!input || input.trim() === "") return 0;

  const cleanInput = input.trim().toLowerCase();

  // Check if input contains multiplier
  if (cleanInput.includes("k")) {
    const number = parseFloat(cleanInput.replace("k", ""));
    return isNaN(number) ? 0 : Math.round(number * 1000);
  }

  if (cleanInput.includes("m")) {
    const number = parseFloat(cleanInput.replace("m", ""));
    return isNaN(number) ? 0 : Math.round(number * 1000000);
  }

  const number = parseFloat(cleanInput);
  if (isNaN(number)) return 0;

  // If it's a number less than 1000 and doesn't contain multipliers,
  // assume it means thousands (K)
  if (number > 0 && number < 1000 && !cleanInput.includes(".")) {
    return Math.round(number * 1000);
  }

  // Otherwise, treat as actual number
  return Math.round(number);
}

/**
 * Formats a number back to human-readable format for display
 */
export function formatFollowersDisplay(value: number): string {
  if (value === 0) return "";

  if (value >= 1000000) {
    const millions = value / 1000000;
    return millions % 1 === 0 ? `${millions}M` : `${millions.toFixed(1)}M`;
  }

  if (value >= 1000) {
    const thousands = value / 1000;
    return thousands % 1 === 0 ? `${thousands}K` : `${thousands.toFixed(1)}K`;
  }

  return value.toString();
}

/**
 * Converts display value back to input value for editing
 */
export function convertToInputValue(displayValue: string): string {
  if (!displayValue) return "";

  // If it's already in K/M format, convert to simple number
  const cleanValue = displayValue.toLowerCase();

  if (cleanValue.includes("k")) {
    const number = parseFloat(cleanValue.replace("k", ""));
    return isNaN(number) ? "" : number.toString();
  }

  if (cleanValue.includes("m")) {
    const number = parseFloat(cleanValue.replace("m", ""));
    return isNaN(number) ? "" : number.toString();
  }

  return displayValue;
}
