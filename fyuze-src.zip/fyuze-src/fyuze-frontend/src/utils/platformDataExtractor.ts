/**
 * DYNAMIC PLATFORM DATA EXTRACTOR
 *
 * This module provides dynamic data extraction capabilities for all supported platforms.
 * It uses the platform configurations to automatically extract the correct fields
 * for any platform without hardcoded logic.
 *
 * @author Fyuze Team
 * @version 2.0.0
 * @last-updated 2025-09-23
 */

import type { PlatformType, PlatformConfiguration } from "../config/platforms";
import {
  PLATFORM_CONFIGS,
  getPlatformByName,
  getPlatformConfig,
} from "../config/platforms";

// ===== TYPE DEFINITIONS =====

export interface ExtractedCreatorData {
  // Core identifiers
  id: string;
  username: string;
  displayName: string;
  platform: PlatformType;

  // Social metrics
  followers: number;
  following: number;
  postsCount: number;

  // Profile information
  bio: string;
  avatarUrl: string;
  verified: boolean;

  // Contact & location
  contactEmail: string;
  location: string;
  category: string;

  // Engagement
  engagementRate: number;

  // Posts data
  posts: any[];

  // Platform-specific data
  platformSpecific: Record<string, any>;

  // Metadata
  dataSource: string;
  rawData: any;
}

export interface PlatformDetectionResult {
  platform: PlatformType;
  confidence: number; // 0-1 score
  matchedFields: string[];
  detectionMethod:
    | "explicit"
    | "unique_fields"
    | "required_fields"
    | "fallback";
}

// ===== PLATFORM DETECTION =====

/**
 * Detect platform from creator data using advanced heuristics
 */
export class PlatformDetector {
  /**
   * Main detection method with confidence scoring
   */
  static detectPlatform(creatorData: any): PlatformDetectionResult {
    // Method 1: Explicit platform field
    const explicitResult = this.detectByExplicitField(creatorData);
    if (explicitResult) {
      return explicitResult;
    }

    // Method 2: Unique platform-specific fields
    const uniqueResult = this.detectByUniqueFields(creatorData);
    if (uniqueResult) {
      return uniqueResult;
    }

    // Method 3: Required fields pattern matching
    const patternResult = this.detectByRequiredFields(creatorData);
    if (patternResult) {
      return patternResult;
    }

    // Method 4: Fallback to Instagram (most common)
    return {
      platform: "instagram",
      confidence: 0.1,
      matchedFields: [],
      detectionMethod: "fallback",
    };
  }

  /**
   * Check for explicit platform identifiers
   */
  private static detectByExplicitField(
    data: any
  ): PlatformDetectionResult | null {
    // Check platform field
    if (data.platform) {
      const platform = getPlatformByName(data.platform);
      if (platform) {
        return {
          platform,
          confidence: 1.0,
          matchedFields: ["platform"],
          detectionMethod: "explicit",
        };
      }
    }

    // Check each platform's explicit identifiers
    for (const [platformKey, config] of Object.entries(PLATFORM_CONFIGS)) {
      for (const identifier of config.detectionRules.explicitIdentifiers) {
        if (
          data.platform === identifier ||
          data.source === identifier ||
          data.type === identifier
        ) {
          return {
            platform: platformKey as PlatformType,
            confidence: 0.95,
            matchedFields: ["platform", "source", "type"].filter(
              (field) => data[field] === identifier
            ),
            detectionMethod: "explicit",
          };
        }
      }
    }

    return null;
  }

  /**
   * Detect by unique platform-specific fields
   */
  private static detectByUniqueFields(
    data: any
  ): PlatformDetectionResult | null {
    const results: Array<{
      platform: PlatformType;
      score: number;
      fields: string[];
    }> = [];

    for (const [platformKey, config] of Object.entries(PLATFORM_CONFIGS)) {
      const matchedFields: string[] = [];
      let score = 0;

      for (const uniqueField of config.detectionRules.uniqueFields) {
        if (this.hasField(data, uniqueField)) {
          matchedFields.push(uniqueField);
          score += 1;
        }
      }

      if (matchedFields.length > 0) {
        results.push({
          platform: platformKey as PlatformType,
          score,
          fields: matchedFields,
        });
      }
    }

    // Return the platform with the highest score
    if (results.length > 0) {
      const best = results.reduce((a, b) => (a.score > b.score ? a : b));
      return {
        platform: best.platform,
        confidence: Math.min(0.9, best.score / 3), // Normalize to max 0.9
        matchedFields: best.fields,
        detectionMethod: "unique_fields",
      };
    }

    return null;
  }

  /**
   * Detect by required fields pattern
   */
  private static detectByRequiredFields(
    _data: any
  ): PlatformDetectionResult | null {
    // This method can be expanded to look for common field patterns
    // For now, it's a placeholder for future enhancements
    return null;
  }

  /**
   * Check if data has a specific field (supports nested paths)
   */
  private static hasField(data: any, fieldPath: string): boolean {
    if (!data) return false;

    // Support nested field paths like "edge_followed_by.count"
    const parts = fieldPath.split(".");
    let current = data;

    for (const part of parts) {
      if (current && typeof current === "object" && part in current) {
        current = current[part];
      } else {
        return false;
      }
    }

    return current !== undefined && current !== null;
  }
}

// ===== DYNAMIC DATA EXTRACTION =====

/**
 * Dynamic data extractor that works with any platform
 */
export class PlatformDataExtractor {
  /**
   * Extract creator data using platform-specific mapping
   */
  static extractCreatorData(
    rawData: any,
    platform: PlatformType,
    dataSource: string = "unknown"
  ): ExtractedCreatorData {
    const config = getPlatformConfig(platform);
    const platformData = this.extractPlatformData(rawData, dataSource);

    return {
      // Core identifiers
      id:
        this.extractField(rawData, platformData, config.fieldMapping.id) ||
        this.generateId(rawData, platform),
      username:
        this.extractField(
          rawData,
          platformData,
          config.fieldMapping.username
        ) || "",
      displayName:
        this.extractField(
          rawData,
          platformData,
          config.fieldMapping.displayName
        ) || "",
      platform,

      // Social metrics
      followers: this.extractNumericField(
        rawData,
        platformData,
        config.fieldMapping.followers
      ),
      following: this.extractNumericField(
        rawData,
        platformData,
        config.fieldMapping.following
      ),
      postsCount: this.extractNumericField(
        rawData,
        platformData,
        config.fieldMapping.posts
      ),

      // Profile information
      bio:
        this.extractField(rawData, platformData, config.fieldMapping.bio) || "",
      avatarUrl:
        this.extractField(rawData, platformData, config.fieldMapping.avatar) ||
        "",
      verified: this.extractBooleanField(
        rawData,
        platformData,
        config.fieldMapping.verified
      ),

      // Contact & location
      contactEmail: this.extractEmail(rawData, platformData),
      location:
        this.extractField(rawData, platformData, ["location", "region"]) || "",
      category:
        this.extractField(rawData, platformData, [
          "category",
          "category_name",
          "business_category_name",
        ]) || "",

      // Engagement
      engagementRate: this.calculateEngagementRate(
        rawData,
        platformData,
        platform
      ),

      // Posts data
      posts: this.extractPosts(rawData, platformData, platform),

      // Platform-specific data
      platformSpecific: this.extractPlatformSpecific(
        rawData,
        platformData,
        config
      ),

      // Metadata
      dataSource,
      rawData: rawData,
    };
  }

  /**
   * Extract platform data based on source type
   */
  private static extractPlatformData(rawData: any, dataSource: string): any {
    // For AI search and endpoint sources, use the data directly
    if (dataSource === "ai_search" || dataSource === "endpoint") {
      return rawData;
    }

    // For database sources, try to parse platform_data
    if (rawData.platform_data) {
      try {
        return typeof rawData.platform_data === "string"
          ? JSON.parse(rawData.platform_data)
          : rawData.platform_data;
      } catch (error) {
        return rawData;
      }
    }

    return rawData;
  }

  /**
   * Extract field value using multiple possible field names
   */
  private static extractField(
    rawData: any,
    platformData: any,
    fieldNames: string[]
  ): string {
    // Try platform data first
    for (const fieldName of fieldNames) {
      const value = this.getNestedValue(platformData, fieldName);
      if (value) return String(value);
    }

    // Fallback to raw data
    for (const fieldName of fieldNames) {
      const value = this.getNestedValue(rawData, fieldName);
      if (value) return String(value);
    }

    return "";
  }

  /**
   * Extract numeric field with proper conversion
   */
  private static extractNumericField(
    rawData: any,
    platformData: any,
    fieldNames: string[]
  ): number {
    const value = this.extractField(rawData, platformData, fieldNames);
    const numValue = parseInt(value) || 0;
    return isNaN(numValue) ? 0 : numValue;
  }

  /**
   * Extract boolean field
   */
  private static extractBooleanField(
    rawData: any,
    platformData: any,
    fieldNames: string[]
  ): boolean {
    for (const fieldName of fieldNames) {
      const value =
        this.getNestedValue(platformData, fieldName) ??
        this.getNestedValue(rawData, fieldName);
      if (value !== undefined && value !== null) {
        // Handle various boolean representations
        if (typeof value === "boolean") return value;
        if (typeof value === "string") return value.toLowerCase() === "true";
        if (typeof value === "number") return value > 0;
        return Boolean(value);
      }
    }
    return false;
  }

  /**
   * Extract email from various sources
   */
  private static extractEmail(rawData: any, platformData: any): string {
    const emailFields = ["contact_email", "email", "business_email"];

    // Try direct email fields
    for (const field of emailFields) {
      const email =
        this.getNestedValue(platformData, field) ??
        this.getNestedValue(rawData, field);
      if (email) return String(email);
    }

    // Try to extract from bio
    const bio = this.extractField(rawData, platformData, [
      "bio",
      "biography",
      "signature",
      "description",
    ]);
    if (bio) {
      const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/;
      const match = bio.match(emailRegex);
      if (match) return match[0];
    }

    return "";
  }

  /**
   * Calculate engagement rate based on platform
   */
  private static calculateEngagementRate(
    rawData: any,
    platformData: any,
    _platform: PlatformType
  ): number {
    // Check for pre-calculated engagement rate
    const existingRate =
      this.getNestedValue(platformData, "engagementRate") ??
      this.getNestedValue(rawData, "engagement_rate");

    if (existingRate !== undefined && existingRate !== null) {
      const rate =
        typeof existingRate === "string"
          ? parseFloat(existingRate)
          : existingRate;
      return isNaN(rate) ? 0 : Math.round(rate * 100) / 100;
    }

    // TODO: Implement platform-specific engagement calculation
    return 0;
  }

  /**
   * Extract posts data from various possible locations
   */
  private static extractPosts(
    rawData: any,
    platformData: any,
    _platform: PlatformType
  ): any[] {
    // Try multiple possible locations for posts data
    let posts: any[] = [];

    // Method 1: Check for posts.edges (Instagram API format)
    if (platformData?.posts?.edges && Array.isArray(platformData.posts.edges)) {
      posts = platformData.posts.edges.map((edge: any) => edge.node || edge);
    }
    // Method 2: Check for direct posts array
    else if (platformData?.posts && Array.isArray(platformData.posts)) {
      posts = platformData.posts;
    }
    // Method 3: Check for videos.videos array (TikTok database format)
    else if (
      platformData?.videos?.videos &&
      Array.isArray(platformData.videos.videos)
    ) {
      posts = platformData.videos.videos;
    }
    // Method 4: Check for videos array (TikTok format)
    else if (platformData?.videos && Array.isArray(platformData.videos)) {
      posts = platformData.videos;
    }
    // Method 5: Check raw data for posts
    else if (rawData?.posts?.edges && Array.isArray(rawData.posts.edges)) {
      posts = rawData.posts.edges.map((edge: any) => edge.node || edge);
    } else if (rawData?.posts && Array.isArray(rawData.posts)) {
      posts = rawData.posts;
    }
    // Method 6: Check for videos.videos in raw data (TikTok database)
    else if (rawData?.videos?.videos && Array.isArray(rawData.videos.videos)) {
      posts = rawData.videos.videos;
    }
    // Method 7: Check for videos in raw data (TikTok)
    else if (rawData?.videos && Array.isArray(rawData.videos)) {
      posts = rawData.videos;
    } else {
    }

    return posts;
  }

  /**
   * Extract platform-specific data
   */
  private static extractPlatformSpecific(
    rawData: any,
    platformData: any,
    config: PlatformConfiguration
  ): Record<string, any> {
    const result: Record<string, any> = {};

    for (const [key, fieldNames] of Object.entries(
      config.fieldMapping.platformSpecific
    )) {
      const value = this.extractField(rawData, platformData, fieldNames);
      if (value) {
        result[key] = value;
      }
    }

    return result;
  }

  /**
   * Get nested value from object using dot notation
   */
  private static getNestedValue(obj: any, path: string): any {
    if (!obj || !path) return undefined;

    const parts = path.split(".");
    let current = obj;

    for (const part of parts) {
      if (current && typeof current === "object" && part in current) {
        current = current[part];
      } else {
        return undefined;
      }
    }

    return current;
  }

  /**
   * Generate unique ID for creator
   */
  private static generateId(rawData: any, platform: PlatformType): string {
    const username = rawData.username || rawData.unique_id || rawData.handle;
    if (username) {
      return `${platform}_${username}`;
    }
    return `${platform}_${Date.now()}_${Math.random()
      .toString(36)
      .substr(2, 9)}`;
  }
}

// ===== UTILITY FUNCTIONS =====

/**
 * Process creator data with automatic platform detection
 */
export const processCreatorWithDetection = (
  rawData: any,
  dataSource: string = "unknown"
): ExtractedCreatorData => {
  const detection = PlatformDetector.detectPlatform(rawData);

  return PlatformDataExtractor.extractCreatorData(
    rawData,
    detection.platform,
    dataSource
  );
};

/**
 * Process multiple creators with platform detection
 */
export const processCreatorsWithDetection = (
  rawDataArray: any[],
  dataSource: string = "unknown"
): ExtractedCreatorData[] => {
  return rawDataArray.map((rawData) =>
    processCreatorWithDetection(rawData, dataSource)
  );
};
