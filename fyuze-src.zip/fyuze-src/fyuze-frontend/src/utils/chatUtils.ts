import { loading_messages } from "../types/loadingMessages";

export const formatTime = (date: Date): string => {
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
};

export const adjustTextareaHeight = (
  textarea: HTMLTextAreaElement | null
): void => {
  if (textarea) {
    textarea.style.height = "auto";
    textarea.style.height = Math.min(textarea.scrollHeight, 120) + "px";
  }
};

export const getRandomMessage = (messages: string[]): string => {
  return messages[Math.floor(Math.random() * messages.length)];
};

export const getLoadingSection = (
  elapsed: number
): keyof typeof loading_messages => {
  if (elapsed < 6) return "zero"; // 0-6 seconds: no messages (empty array)
  if (elapsed >= 6 && elapsed < 15) return "first";
  if (elapsed >= 15 && elapsed < 30) return "second";
  if (elapsed >= 30 && elapsed < 50) return "third";
  if (elapsed >= 50 && elapsed < 80) return "fourth";
  if (elapsed >= 80) return "fifth";
  return "zero";
};

export const copyToClipboard = async (text: string): Promise<boolean> => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    console.error("Failed to copy message:", err);
    return false;
  }
};

export const scrollToBottom = (element: HTMLDivElement | null): void => {
  element?.scrollIntoView({ behavior: "smooth" });
};
