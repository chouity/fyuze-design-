// Platform detection utilities for social media influencers
import {
  faInstagram,
  faYoutube,
  faTiktok,
  faXTwitter,
  faFacebook,
  faLinkedin,
} from "@fortawesome/free-brands-svg-icons";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import type { IconDefinition } from "@fortawesome/fontawesome-svg-core";

export interface PlatformInfo {
  icon: IconDefinition;
  color: string;
  bgColor: string;
  borderColor: string;
  name: string;
}

/**
 * Extracts platform name from URL
 * @param url - The social media profile URL
 * @returns Platform name as string
 */
export const extractPlatformFromUrl = (url: string): string => {
  if (!url || typeof url !== "string") return "unknown";
  const lowerUrl = url.toLowerCase();
  if (lowerUrl.includes("instagram.com")) return "instagram";
  if (lowerUrl.includes("youtube.com") || lowerUrl.includes("youtu.be"))
    return "youtube";
  if (lowerUrl.includes("tiktok.com")) return "tiktok";
  if (lowerUrl.includes("twitter.com") || lowerUrl.includes("x.com"))
    return "twitter";
  if (lowerUrl.includes("facebook.com")) return "facebook";
  return "unknown";
};

/**
 * Detects the social media platform from a URL and returns platform-specific information
 * @param url - The social media profile URL
 * @param isDark - Whether the app is in dark mode (for styling)
 * @returns PlatformInfo object with icon, colors, and platform name
 */
export const getPlatformInfo = (
  url: string,
  isDark: boolean = false
): PlatformInfo => {
  if (!url || typeof url !== "string") {
    return {
      icon: faStar,
      color: "text-purple-500",
      bgColor: isDark ? "bg-purple-900/50" : "bg-purple-100",
      borderColor: "border-purple-500/30",
      name: "Social Media",
    };
  }

  const lowerUrl = url.toLowerCase();

  if (lowerUrl.includes("instagram.com")) {
    return {
      icon: faInstagram,
      color: "text-pink-500",
      bgColor: isDark ? "bg-pink-900/50" : "bg-pink-100",
      borderColor: "border-pink-500/30",
      name: "Instagram",
    };
  } else if (
    lowerUrl.includes("youtube.com") ||
    lowerUrl.includes("youtu.be")
  ) {
    return {
      icon: faYoutube,
      color: "text-red-500",
      bgColor: isDark ? "bg-red-900/50" : "bg-red-100",
      borderColor: "border-red-500/30",
      name: "YouTube",
    };
  } else if (lowerUrl.includes("tiktok.com")) {
    return {
      icon: faTiktok,
      color: isDark ? "text-white" : "text-black",
      bgColor: isDark ? "bg-gray-900/50" : "bg-gray-100",
      borderColor: "border-gray-500/30",
      name: "TikTok",
    };
  } else if (lowerUrl.includes("twitter.com") || lowerUrl.includes("x.com")) {
    return {
      icon: faXTwitter,
      color: "text-blue-500",
      bgColor: isDark ? "bg-blue-900/50" : "bg-blue-100",
      borderColor: "border-blue-500/30",
      name: "Twitter/X",
    };
  } else if (lowerUrl.includes("facebook.com")) {
    return {
      icon: faFacebook,
      color: "text-blue-600",
      bgColor: isDark ? "bg-blue-900/50" : "bg-blue-100",
      borderColor: "border-blue-600/30",
      name: "Facebook",
    };
  } else if (lowerUrl.includes("linkedin.com")) {
    return {
      icon: faLinkedin,
      color: "text-blue-700",
      bgColor: isDark ? "bg-blue-900/50" : "bg-blue-100",
      borderColor: "border-blue-700/30",
      name: "LinkedIn",
    };
  } else {
    return {
      icon: faStar,
      color: "text-purple-500",
      bgColor: isDark ? "bg-purple-900/50" : "bg-purple-100",
      borderColor: "border-purple-500/30",
      name: "Social Media",
    };
  }
};

/**
 * Gets gradient colors for styling based on index
 * @param index - Index for color variation
 * @returns Gradient class string
 */
export const getGradientColors = (index: number): string => {
  const gradients = [
    "from-purple-500 to-pink-500",
    "from-blue-500 to-cyan-500",
    "from-green-500 to-teal-500",
    "from-orange-500 to-red-500",
    "from-indigo-500 to-purple-500",
  ];
  return gradients[index % gradients.length];
};
export const getPlatformName = (url: string): string => {
  if (!url || typeof url !== "string") return "Social Media";
  return getPlatformInfo(url).name;
};

/**
 * Checks if a URL is from a supported social media platform
 * @param url - The URL to check
 * @returns Boolean indicating if the platform is supported
 */
export const isSupportedPlatform = (url: string): boolean => {
  if (!url || typeof url !== "string") return false;
  const lowerUrl = url.toLowerCase();
  return (
    lowerUrl.includes("instagram.com") ||
    lowerUrl.includes("youtube.com") ||
    lowerUrl.includes("youtu.be") ||
    lowerUrl.includes("tiktok.com") ||
    lowerUrl.includes("twitter.com") ||
    lowerUrl.includes("x.com") ||
    lowerUrl.includes("facebook.com") ||
    lowerUrl.includes("linkedin.com")
  );
};
