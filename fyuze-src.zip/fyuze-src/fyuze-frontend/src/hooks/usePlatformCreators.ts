/**
 * PLATFORM-AWARE CREATOR HOOKS
 *
 * Enhanced hooks that use the platform abstraction layer
 * for dynamic creator data processing.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import { useMemo } from "react";
import { useCreator as useBaseCreator } from "./useSupabaseQuery";
import { platformService } from "../services/PlatformService";
import type { PlatformCreatorProfile } from "../types/platform.types";

/**
 * Enhanced creator hook that returns platform-abstracted data
 */
export const usePlatformCreator = (creatorId: string) => {
  const { data: rawData, ...queryResult } = useBaseCreator(creatorId);

  const creator = useMemo((): PlatformCreatorProfile | null => {
    // Handle different possible data structures
    let creatorData: any = null;

    if (rawData) {
      if ((rawData as any).rows && Array.isArray((rawData as any).rows)) {
        creatorData = (rawData as any).rows[0];
      } else if (Array.isArray(rawData)) {
        creatorData = rawData[0];
      } else if (typeof rawData === "object") {
        creatorData = rawData;
      }
    }

    if (!creatorData) {
      return null;
    }

    try {
      // Detect platform from raw data
      const platform = platformService.detectPlatform(creatorData);

      if (!platform) {
        console.warn("Could not detect platform for creator:", creatorId);
        return null;
      }

      // Extract profile using platform abstraction
      const result = platformService.extractCreatorProfile(
        creatorData,
        platform,
        "database"
      );

      if (!result.success) {
        console.error("Failed to extract creator profile:", result.errors);
        return null;
      }

      return result.profile;
    } catch (error) {
      console.error(
        "Error processing creator with platform abstraction:",
        error
      );
      return null;
    }
  }, [rawData, creatorId]);

  return {
    ...queryResult,
    data: creator,
    rawData, // Keep raw data available if needed
  };
};

/**
 * Enhanced creators hook for multiple creators with platform abstraction
 */
export const usePlatformCreators = () => {
  // This would use useCreators but process results through platform abstraction
  // For now, we can rely on the processing done in the dashboard component
  // In the future, this could be enhanced to provide a unified interface
  return null; // Placeholder for future implementation
};

/**
 * Data normalization hook that works with PlatformCreatorProfile
 */
export const usePlatformCreatorNormalization = (
  creators: PlatformCreatorProfile[] = []
) => {
  const normalizedCreators = useMemo(() => {
    if (!creators || !Array.isArray(creators)) {
      return [];
    }

    return creators.map((creator) => {
      // Extract posts data
      const posts = creator.posts || [];

      // Calculate engagement metrics from posts
      let totalLikes = 0;
      let totalComments = 0;
      let totalViews = 0;
      let postsWithData = 0;

      posts.forEach((post) => {
        totalLikes += post.likes || 0;
        totalComments += post.comments || 0;
        totalViews += post.views || 0;
        postsWithData++;
      });

      const averageLikes = postsWithData > 0 ? totalLikes / postsWithData : 0;
      const averageComments =
        postsWithData > 0 ? totalComments / postsWithData : 0;
      const averageViews = postsWithData > 0 ? totalViews / postsWithData : 0;

      // Enhanced engagement metrics
      const engagementData = {
        averageLikes,
        averageComments,
        averageViews,
        engagementRate: creator.engagementRate,
        totalEngagement: totalLikes + totalComments,
        averageEngagement:
          postsWithData > 0 ? (totalLikes + totalComments) / postsWithData : 0,
      };

      return {
        ...creator,
        engagementData,
        normalizedPosts: posts,
        analytics: {
          postsCount: postsWithData,
          avgLikesPerPost: averageLikes,
          avgCommentsPerPost: averageComments,
          avgViewsPerPost: averageViews,
          engagementRate: creator.engagementRate,
        },
      };
    });
  }, [creators]);

  return normalizedCreators;
};
