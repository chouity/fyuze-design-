import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

export const useUserBalance = (userId: string) => {
  const [balance, setBalance] = useState<number | null>(null);

  useEffect(() => {
    if (!userId) {
      return;
    }

    // 1️⃣ Load initial balance
    const fetchBalance = async () => {
      const { data, error } = await supabase
        .from("user_points")
        .select("balance")
        .eq("user_id", userId)
        .single();

      if (!error) {
        setBalance(data.balance);
      }
    };

    fetchBalance();

    // 2️⃣ Try realtime subscription first
    const subscription = supabase
      .channel(`user_balance_${userId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "user_points",
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          if (payload.eventType === "UPDATE") {
            setBalance(payload.new.balance);
          }
          if (payload.eventType === "INSERT") {
            setBalance(payload.new.balance);
          }
        }
      )
      .subscribe((status) => {
        // If realtime fails, fall back to polling
        if (status !== "SUBSCRIBED") {
          // const pollInterval = setInterval(fetchBalance, 5000); // Poll every 5 seconds
          // return () => clearInterval(pollInterval);
        }
      });

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [userId]);

  return balance;
};
