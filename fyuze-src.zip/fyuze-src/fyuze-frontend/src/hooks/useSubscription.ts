import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { SubscriptionService } from "../services/SubscriptionService";
import type { SubscriptionPlan } from "../types/subscription";

export const useSubscriptionPlans = () => {
  return useQuery({
    queryKey: ["subscription-plans"],
    queryFn: SubscriptionService.getSubscriptionPlans,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
};

export const useChooseSubscriptionPlan = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (planCode: string) =>
      SubscriptionService.chooseSubscriptionPlan(planCode),
    onSuccess: () => {
      // Invalidate and refetch any subscription-related queries
      queryClient.invalidateQueries({ queryKey: ["subscription-plans"] });
      queryClient.invalidateQueries({ queryKey: ["user-subscription"] });
    },
  });
};

export const useSubscription = () => {
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(
    null
  );
  const [isModalOpen, setIsModalOpen] = useState(false);

  const plansQuery = useSubscriptionPlans();
  const choosePlanMutation = useChooseSubscriptionPlan();

  const selectPlan = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
    setIsModalOpen(true);
  };

  const confirmPlan = async () => {
    if (!selectedPlan) return;

    try {
      await choosePlanMutation.mutateAsync(selectedPlan.code);
      setIsModalOpen(false);
      setSelectedPlan(null);
      return true;
    } catch (error) {
      console.error("Failed to choose plan:", error);
      return false;
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedPlan(null);
  };

  return {
    plans: plansQuery.data || [],
    isLoading: plansQuery.isLoading,
    error: plansQuery.error,
    selectedPlan,
    isModalOpen,
    isConfirming: choosePlanMutation.isPending,
    selectPlan,
    confirmPlan,
    closeModal,
    refetch: plansQuery.refetch,
  };
};
