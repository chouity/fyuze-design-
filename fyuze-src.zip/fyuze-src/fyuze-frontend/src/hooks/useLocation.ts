import { useSupabaseQuery } from "./useSupabaseQuery";

// Hook for getting locations by level
export function useLocations(level: string) {
  return useSupabaseQuery(
    "get_locations",
    { level },
    {
      staleTime: 10 * 60 * 1000, // 10 minutes
      gcTime: 30 * 60 * 1000, // 30 minutes
      enabled: !!level, // Only run if level is provided
    }
  );
}

// Hook for getting country-city pairs
export function useCountryCityPairs(country: string) {
  return useSupabaseQuery(
    "get_country_city_pairs",
    { country },
    {
      staleTime: 10 * 60 * 1000, // 10 minutes
      gcTime: 30 * 60 * 1000, // 30 minutes
      enabled: !!country, // Only run if country is provided
    }
  );
}
