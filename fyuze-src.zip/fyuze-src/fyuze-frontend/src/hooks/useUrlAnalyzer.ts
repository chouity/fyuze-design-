import { useState, useCallback } from "react";
import { UrlAnalyzerResponse } from "../types/staticResponseAi";
import { UrlAnalyzer } from "../lib/supabaseClient";

const USE_UrlAnalyzer_STATIC_DATA = false;

export interface UrlAnalyzerState {
  url: string;
  name: string;
  type: string;
  industry: string;
  services: string[];
  mission: string;
  contact_info: string;
  summary_markdown: string;
}

export interface UseUrlAnalyzerReturn {
  data: UrlAnalyzerState | null;
  isLoading: boolean;
  error: string | null;
  analyzeUrl: (url: string) => Promise<void>;
  reset: () => void;
}

export const useUrlAnalyzer = (): UseUrlAnalyzerReturn => {
  const [data, setData] = useState<UrlAnalyzerState | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const analyzeUrl = useCallback(async (url: string) => {
    if (!url.trim()) {
      setError("URL is required");
      return;
    }

    // Basic URL validation
    try {
      new URL(url);
    } catch {
      setError("Please enter a valid URL");
      return;
    }

    setIsLoading(true);
    setError(null);
    setData(null);

    try {
      if (USE_UrlAnalyzer_STATIC_DATA) {
        // Use static data for development/testing
        await new Promise((resolve) => setTimeout(resolve, 1500)); // Simulate API delay

        setData({
          url: UrlAnalyzerResponse.url,
          name: UrlAnalyzerResponse.name,
          type: UrlAnalyzerResponse.type,
          industry: UrlAnalyzerResponse.industry,
          services: UrlAnalyzerResponse.services,
          mission: UrlAnalyzerResponse.mission,
          contact_info: UrlAnalyzerResponse.contact_info,
          summary_markdown: UrlAnalyzerResponse.summary_markdown,
        });
      } else {
        // Use actual Supabase function
        const response = await UrlAnalyzer(url);

        if (response.error) {
          throw new Error(response.error.message || "Failed to analyze URL");
        }

        if (!response.data) {
          throw new Error("No data received from URL analysis");
        }

        // Parse the response based on your API structure
        const analysisData = response.data;

        setData({
          url: analysisData.url || url,
          name: analysisData.name || "Unknown",
          type: analysisData.type || "Unknown",
          industry: analysisData.industry || "Unknown",
          services: Array.isArray(analysisData.services)
            ? analysisData.services
            : [],
          mission: analysisData.mission || "Not available",
          contact_info: analysisData.contact_info || "Not available",
          summary_markdown:
            analysisData.summary_markdown || "No summary available",
        });
      }
    } catch (err) {
      console.error("URL Analysis error:", err);

      let errorMessage = "An unexpected error occurred";

      if (err instanceof Error) {
        errorMessage = err.message;

        // Check for specific API error responses
        if ((err as any).apiError) {
          const apiError = (err as any).apiError;
          errorMessage = apiError.message || err.message;
        }
      }

      // Don't show toast here - global handler will do it
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setData(null);
    setError(null);
    setIsLoading(false);
  }, []);

  return {
    data,
    isLoading,
    error,
    analyzeUrl,
    reset,
  };
};
