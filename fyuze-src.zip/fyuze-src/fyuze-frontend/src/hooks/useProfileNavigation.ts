import { useNavigate } from "react-router-dom";
import { useCallback } from "react";
import { callDatabaseFunction } from "../lib/supabaseClient";
import { extractPlatformFromUrl } from "../utils/platformUtils";
import type { Creator } from "../types/influencer";
import type { Influencer } from "../types/chat";

/**
 * Custom hook for handling influencer profile navigation
 */
export const useProfileNavigation = () => {
  const navigate = useNavigate();

  /**
   * Transforms influencer data to creator format for fallback
   */
  const transformInfluencerToCreator = useCallback(
    (influencer: Influencer, platform: string): Creator => {
      // Use original platform data if available, otherwise create basic structure
      const platformData =
        influencer.originalPlatformData ||
        (platform === "tiktok"
          ? {
              // TikTok format fallback
              uid: influencer.username || "unknown",
              unique_id: influencer.username,
              nickname: influencer.fullName || influencer.username,
              signature: influencer.biography || "",
              follower_count: influencer.followersCount || 0,
              following_count: 0,
              total_favorited: 0,
              aweme_count: 0,
              region: "Unknown",
              birthday: "1900-01-01",
              verification_type: 0,
              is_verified: false,
              avatar_url:
                influencer.avatar_url || influencer.profilePicUrl || "",
              videos: {
                count: 0,
                videos: [],
              },
              engagementRate: 0.0,
            }
          : {
              // Instagram format fallback
              id: influencer.username || "unknown",
              username: influencer.username,
              bio: influencer.biography || "",
              links: [influencer.url || ""],
              fb_link: null,
              full_name: influencer.fullName || influencer.username,
              followers: influencer.followersCount || 0,
              following: 0,
              category: "Influencer",
              is_verified: false,
              posts: {
                count: 0,
                edges: [],
              },
              engagementRate: 0.0,
            });

      const creatorResult = {
        name: influencer.fullName || influencer.username || "Unknown User",
        full_name: influencer.fullName,
        username: influencer.username,
        platform: platform,
        followers: influencer.followersCount || 0,
        bio: influencer.biography,
        avatar_url: influencer.avatar_url || influencer.profilePicUrl,
        url: influencer.url,
        location: "Not specified",
        verified: false,
        engagement_rate: "N/A",
        // Add the platform_data field that the profile page expects
        platform_data: JSON.stringify(platformData),
        // Add profileData field for enhanced processing
        profileData: platformData,
        // Add dataSource to indicate this comes from AI chat
        dataSource: "ai_search",
        audience_demographics: {
          quality_audience: 0,
          followers_growth: 0,
          authentic_engagement: 0,
          post_frequency: "Unknown",
        },
        content_categories: [],
      };

      return creatorResult;
    },
    []
  );

  /**
   * Navigates to creator profile with fallback data
   */
  const navigateWithFallbackData = useCallback(
    (influencer: Influencer, username: string, platform: string): void => {
      const transformedCreator = transformInfluencerToCreator(
        influencer,
        platform
      );

      navigate(`/creators/${username}`, {
        state: {
          creator: transformedCreator,
          originalInfluencer: influencer,
          dataSource: "ai_search_fallback",
        },
      });
    },
    [navigate, transformInfluencerToCreator]
  );

  /**
   * Handles viewing creator profile by fetching data and navigating
   */
  const handleViewProfile = useCallback(
    async (influencer: Influencer): Promise<void> => {
      try {
        const platform = extractPlatformFromUrl(influencer.url);
        const username = influencer.username;

        // Check if we have rich chatbot data - if so, use it directly instead of database lookup
        if (influencer.originalPlatformData) {
          // Use the rich chatbot data directly
          const transformedCreator = transformInfluencerToCreator(
            influencer,
            platform
          );

          navigate(`/creators/${username}`, {
            state: {
              creator: transformedCreator,
              originalInfluencer: influencer,
              dataSource: "ai_search", // Explicitly mark as AI search data
            },
          });
          return;
        }

        // Call get_creators function with username and platform using Supabase client
        const response = await callDatabaseFunction("get_creators", {
          username: username,
          platform: platform,
        });

        if (!response.error && response.data) {
          // Navigate to creator profile page with the fetched data
          const creatorData = Array.isArray(response.data)
            ? response.data[0]
            : response.data;

          navigate(`/creators/${username}`, {
            state: {
              creator: creatorData,
              originalInfluencer: influencer,
              dataSource: "database",
            },
          });
        } else {
          // Fallback: navigate with influencer data transformed to creator format
          navigateWithFallbackData(influencer, username, platform);
        }
      } catch (error) {
        // Fallback: navigate with influencer data transformed to creator format
        const platform = extractPlatformFromUrl(influencer.url);
        navigateWithFallbackData(influencer, influencer.username, platform);
      }
    },
    [navigate, navigateWithFallbackData, transformInfluencerToCreator]
  );

  /**
   * Handles viewing creator profile in a new tab - simple approach
   */
  const handleViewProfileInNewTab = useCallback(
    async (influencer: Influencer): Promise<void> => {
      const username = influencer.username;
      // Simply open creator profile in new tab
      window.open(`/creators/${username}`, "_blank");
    },
    []
  );

  return {
    handleViewProfile,
    handleViewProfileInNewTab,
  };
};
