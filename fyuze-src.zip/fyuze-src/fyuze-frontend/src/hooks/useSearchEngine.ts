import { useState, useCallback } from "react";
import { SeatchEngine } from "../lib/supabaseClient";
import { SearchEngineResponse } from "../types/staticResponseAi";
const USE_SEARCHENGINE_STATIC_DATA = false;

export interface UrlAnalyzerState {
  kind: string;
  title: string;
  html_title: string;
  link: string;
  display_link: string;
  snippet: string;
  html_snippet: string;
  formatted_url: string;
  html_formatted_url: string;
  pagemap?: Pagemap | null;
}

export interface Pagemap {
  cse_thumbnail?: Array<{
    src: string;
    width: string;
    height: string;
  }>;
  metatags?: Array<{
    [key: string]: string;
  }>;
  cse_image?: Array<{
    src: string;
  }>;
}

export interface SearchApiResponse {
  query: string;
  request_time: string;
  finish_time: string;
  execution_time: number;
  success: boolean;
  error_message: string;
  response: UrlAnalyzerState[];
}

export interface UseSearchEngine {
  data: UrlAnalyzerState[] | null;
  isLoading: boolean;
  error: string | null;
  searchEngine: (query: string, gl: string) => Promise<void>;
  reset: () => void;
}

export const useSearchEngine = (): UseSearchEngine => {
  const [data, setData] = useState<UrlAnalyzerState[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchEngine = useCallback(async (query: string, gl: string) => {
    setIsLoading(true);
    setError(null);
    setData(null);

    try {
      if (USE_SEARCHENGINE_STATIC_DATA) {
        // Use static data for development/testing
        await new Promise((resolve) => setTimeout(resolve, 1500)); // Simulate API delay

        // For static data, we'll use a mock response array
        setData([
          {
            kind: SearchEngineResponse.response.kind,
            title: SearchEngineResponse.response.title,
            html_title: SearchEngineResponse.response.html_title,
            link: SearchEngineResponse.response.link,
            display_link: SearchEngineResponse.response.display_link,
            snippet: SearchEngineResponse.response.snippet,
            html_snippet: SearchEngineResponse.response.html_snippet,
            formatted_url: SearchEngineResponse.response.formatted_url,
            html_formatted_url:
              SearchEngineResponse.response.html_formatted_url,
            pagemap: SearchEngineResponse.response.pagemap,
          },
        ]);
      } else {
        // Use actual Supabase function
        const response = await SeatchEngine(query, gl);

        if (response.error) {
          throw new Error(response.error.message || "Failed to Search ");
        }

        if (!response.data) {
          throw new Error("No data received from the searching");
        }

        // Parse the response based on the new API structure
        const analysisData = response.data as SearchApiResponse;

        if (!analysisData.success) {
          throw new Error(analysisData.error_message || "Search failed");
        }

        // Set the response array directly
        setData(analysisData.response || []);
      }
    } catch (err) {
      console.error("Search Engine error:", err);

      let errorMessage = "An unexpected error occurred";

      if (err instanceof Error) {
        errorMessage = err.message;

        // Check for specific API error responses
        if ((err as any).apiError) {
          const apiError = (err as any).apiError;
          errorMessage = apiError.message || err.message;
        }
      }

      // Don't show toast here - global handler will do it
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setData(null);
    setError(null);
    setIsLoading(false);
  }, []);

  return {
    data,
    isLoading,
    error,
    searchEngine,
    reset,
  };
};
