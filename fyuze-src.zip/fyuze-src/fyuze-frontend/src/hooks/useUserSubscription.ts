import { useQuery } from "@tanstack/react-query";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../contexts/AuthContext";

interface UserSubscription {
  status: string;
  plan_code: string;
  end_date: string;
}

export const useUserSubscriptionStatus = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["user-subscription", user?.id],
    queryFn: async (): Promise<UserSubscription | null> => {
      if (!user?.id) return null;

      try {
        const { data, error } = await supabase
          .from("v_user_active_subscription")
          .select("*")
          .eq("user_id", user.id)
          .maybeSingle();

        if (error) {
          console.error("Error fetching user subscription:", error);
          // Return null instead of throwing to allow the app to continue
          return null;
        }

        return data as UserSubscription | null;
      } catch (error) {
        console.error("Exception in subscription query:", error);
        return null;
      }
    },
    enabled: !!user?.id,
    staleTime: 2 * 60 * 1000, // 2 minutes
    retry: 1, // Only retry once
    retryDelay: 1000, // Wait 1 second before retry
    gcTime: 5 * 60 * 1000, // 5 minutes cache time
  });
};

export const useHasActiveSubscription = () => {
  const subscriptionQuery = useUserSubscriptionStatus();

  const hasActiveSubscription = subscriptionQuery.data?.status === "active";
  const isLoading = subscriptionQuery.isLoading;
  const error = subscriptionQuery.error;

  return {
    hasActiveSubscription,
    isLoading,
    error,
    subscription: subscriptionQuery.data,
    refetch: subscriptionQuery.refetch,
  };
};
