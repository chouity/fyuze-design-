import { useState, useRef, useEffect } from "react";
import { adjustTextareaHeight } from "../utils/chatUtils";

interface UseChatInputProps {
  onSubmit: (message: string) => void;
  isLoading: boolean;
  messages: any[];
  isMobile: boolean;
}

export const useChatInput = ({
  onSubmit,
  isLoading,
  messages,
  isMobile,
}: UseChatInputProps) => {
  const [input, setInput] = useState("");
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [animatedPlaceholder, setAnimatedPlaceholder] = useState("");
  const [typing, setTyping] = useState(true);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const placeholders = [
    "Ask me who are the top 10 instagram food influencers in Dubai",
    "Ask me anything you need...",
    "Ask me to find you influencers in your field if you paste your brand's URL",
    "Ask me to help you with your crypto launch campaign on X",
    "Ask me who are the highest rated fashion micro influencers that speak French",
  ];

  const placeholderText = placeholders[placeholderIndex];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const message = input.trim();
    setInput("");
    await onSubmit(message);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    setTimeout(() => {
      textareaRef.current?.focus();
    }, 100);
  };

  useEffect(() => {
    adjustTextareaHeight(textareaRef.current);
  }, [input]);

  // Animated placeholder effect
  useEffect(() => {
    if (isMobile) {
      setAnimatedPlaceholder("Ask me anything...");
      return;
    }

    if (messages.length > 0) {
      setAnimatedPlaceholder("Ask anything...");
      return;
    }

    let timeout: NodeJS.Timeout;
    if (input !== "") {
      if (animatedPlaceholder !== "") setAnimatedPlaceholder("");
      return;
    }
    if (typing) {
      if (animatedPlaceholder.length < placeholderText.length) {
        timeout = setTimeout(() => {
          setAnimatedPlaceholder(
            placeholderText.slice(0, animatedPlaceholder.length + 1)
          );
        }, 40);
      } else {
        timeout = setTimeout(() => setTyping(false), 1200);
      }
    } else {
      if (animatedPlaceholder.length > 0) {
        timeout = setTimeout(() => {
          setAnimatedPlaceholder(
            placeholderText.slice(0, animatedPlaceholder.length - 1)
          );
        }, 30);
      } else {
        setTyping(true);
        setPlaceholderIndex((i) => (i + 1) % placeholders.length);
      }
    }
    return () => clearTimeout(timeout);
  }, [
    animatedPlaceholder,
    typing,
    placeholderText,
    input,
    isMobile,
    messages.length,
  ]);

  return {
    input,
    setInput,
    textareaRef,
    animatedPlaceholder,
    handleSubmit,
    handleKeyPress,
    handleSuggestionClick,
  };
};
