import { useMemo } from "react";
import {
  processCreatorsWithDetection,
  type ExtractedCreatorData,
} from "../utils/platformDataExtractor";

/**
 * Enhanced Creator interface for UI compatibility
 * Extends the new ExtractedCreatorData with legacy fields for backward compatibility
 */
export interface EnhancedCreator extends Omit<ExtractedCreatorData, "posts"> {
  // Display aliases
  name: string; // alias for displayName
  url?: string; // profile URL if available

  // Avatar field compatibility
  avatar_url?: string; // Database field
  profile_pic_url?: string; // Alternative field name

  // Legacy fields for table compatibility
  content_categories?: string[];
  audience_demographics?: any;
  engagement_rate_raw?: number | string;
  rate_per_post?: number;
  rate_per_reel?: number;
  rate_per_story?: number;
  recent_posts?: any;
  languages?: string;
  match_score?: number;
  match_reason?: string;
  scraped_at?: string;
  is_active?: boolean;
  created_at?: string;
  updated_at?: string;
  engagement_rate: number;

  // Rich profile data structure for backward compatibility
  profileData?: {
    id: string;
    username: string;
    fullName: string;
    bio?: string;
    profilePicUrl?: string;
    followers: number;
    following: number;
    postsCount: number;
    isVerified: boolean;
    isBusinessAccount?: boolean;
    isProfessionalAccount?: boolean;
    category?: string;
    externalUrl?: string;
    links: string[];
    contactEmail?: string;
    phoneNumber?: string;
    businessCategory?: string;
    businessContactMethod?: string;
    businessAddress?: any;
    engagementRate: number;
    highlightReelCount?: number;
    hasClips?: boolean;
    hasGuides?: boolean;
    hasChannel?: boolean;
    posts: any[];
    location?: string;
    fbId?: string;
    isPrivate?: boolean;
    pronouns?: string[];
  };

  posts?: {
    count: number;
    edges: any[];
  };
}

export const useCreatorsParsing = () => {
  const parseCreatorData = useMemo(() => {
    return (
      apiResponse: any,
      dataSource?: "ai_search" | "get_creators" | "endpoint"
    ): EnhancedCreator[] => {
      if (!apiResponse) {
        return [];
      }

      try {
        // Extract raw creators based on data source
        let rawCreators: any[] = [];
        const detectedSource = dataSource || detectDataSource(apiResponse);

        switch (detectedSource) {
          case "ai_search":
            // Handle AI search responses - now with nested data structure
            if (Array.isArray(apiResponse)) {
              rawCreators = apiResponse;
            } else if (
              apiResponse.data?.platform_data &&
              Array.isArray(apiResponse.data.platform_data)
            ) {
              // New structure: { data: { platform_data: [...] } }
              rawCreators = apiResponse.data.platform_data;
            } else if (
              apiResponse.platform_data &&
              Array.isArray(apiResponse.platform_data)
            ) {
              // Legacy structure: { platform_data: [...] }
              rawCreators = apiResponse.platform_data;
            } else if (apiResponse.data && Array.isArray(apiResponse.data)) {
              // Direct data array: { data: [...] }
              rawCreators = apiResponse.data;
            } else {
              // Single creator object
              rawCreators = [apiResponse];
            }
            break;

          case "get_creators":
            // Handle database responses
            rawCreators = apiResponse.data?.rows || apiResponse.rows || [];
            break;

          case "endpoint":
            // Handle direct endpoint responses (now may have .data field)
            if (
              apiResponse.data?.platform_data &&
              Array.isArray(apiResponse.data.platform_data)
            ) {
              rawCreators = apiResponse.data.platform_data;
            } else if (apiResponse.data && Array.isArray(apiResponse.data)) {
              rawCreators = apiResponse.data;
            } else if (Array.isArray(apiResponse)) {
              rawCreators = apiResponse;
            } else {
              rawCreators = [apiResponse];
            }
            break;

          default:
            rawCreators = Array.isArray(apiResponse)
              ? apiResponse
              : [apiResponse];
        }

        // Ensure rawCreators is always an array
        if (!Array.isArray(rawCreators)) {
          rawCreators = rawCreators ? [rawCreators] : [];
        }

        // Process creators using the new dynamic platform detection and extraction
        const extractedCreators = processCreatorsWithDetection(
          rawCreators,
          detectedSource
        );

        // Convert to EnhancedCreator format for backward compatibility
        const enhancedCreators = extractedCreators.map((creator) => {
          const enhanced: EnhancedCreator = {
            // Copy all ExtractedCreatorData properties
            ...creator,

            // Add display-specific aliases for UI compatibility
            engagement_rate: creator.engagementRate,
            name: creator.displayName || creator.username,
            url: generateProfileUrl(creator.platform, creator.username),

            // Add avatar_url for direct compatibility with database field
            avatar_url: creator.avatarUrl,
            profile_pic_url: creator.avatarUrl,

            // Legacy fields for backward compatibility
            content_categories: creator.category ? [creator.category] : [],
            engagement_rate_raw: creator.engagementRate,

            // Build profileData structure for components that expect it
            profileData: {
              id: creator.id,
              username: creator.username,
              fullName: creator.displayName,
              bio: creator.bio,
              profilePicUrl: creator.avatarUrl,
              followers: creator.followers,
              following: creator.following,
              postsCount: creator.postsCount,
              isVerified: creator.verified,
              category: creator.category,
              links: [],
              contactEmail: creator.contactEmail,
              engagementRate: creator.engagementRate,
              posts: creator.posts || [], // Use actual posts data
              location: creator.location,
            },

            // Build posts structure if available
            posts: {
              count: creator.postsCount,
              edges: creator.posts || [], // Use actual posts data
            },
          };

          return enhanced;
        });

        return enhancedCreators;
      } catch (error) {
        return [];
      }
    };
  }, []);

  return {
    parseCreatorData,
  };
};

// ===== UTILITY FUNCTIONS =====

/**
 * Detect data source from API response structure
 */
function detectDataSource(
  apiResponse: any
): "ai_search" | "get_creators" | "endpoint" {
  // Check for get_creators structure (database responses)
  if (apiResponse.data?.rows && Array.isArray(apiResponse.data.rows)) {
    return "get_creators";
  }

  if (apiResponse.status === "success" && apiResponse.data?.rows) {
    return "get_creators";
  }

  // Check for AI search structure
  if (apiResponse.platform_data && Array.isArray(apiResponse.platform_data)) {
    return "ai_search";
  }

  // Default to endpoint for direct API responses
  return "endpoint";
}

/**
 * Generate profile URL for a platform/username combination
 */
function generateProfileUrl(platform: string, username: string): string {
  if (!username) return "";

  const platformUrls: Record<string, string> = {
    instagram: `https://instagram.com/${username}`,
    tiktok: `https://tiktok.com/@${username}`,
    youtube: `https://youtube.com/@${username}`,
    twitter: `https://twitter.com/${username}`,
    x: `https://x.com/${username}`,
    facebook: `https://facebook.com/${username}`,
    linkedin: `https://linkedin.com/in/${username}`,
    snapchat: `https://snapchat.com/add/${username}`,
    pinterest: `https://pinterest.com/${username}`,
    twitch: `https://twitch.tv/${username}`,
  };

  return platformUrls[platform.toLowerCase()] || "";
}

// Export types for external use
export type { ExtractedCreatorData };

export default useCreatorsParsing;
