import { useToastActions } from "../contexts/ToastContext";

/**
 * Custom hook that provides convenient methods for showing toast notifications
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const toast = useToastNotification();
 *
 *   const handleSuccess = () => {
 *     toast.success('Operation completed successfully!');
 *   };
 *
 *   const handleError = () => {
 *     toast.error('Something went wrong!', { persistent: true });
 *   };
 *
 *   return (
 *     <div>
 *       <button onClick={handleSuccess}>Success</button>
 *       <button onClick={handleError}>Error</button>
 *     </div>
 *   );
 * }
 * ```
 */
export function useToastNotification() {
  const actions = useToastActions();

  return {
    /**
     * Show a success toast
     * @param message - The message to display
     * @param options - Toast options (duration, persistent)
     */
    success: actions.success,

    /**
     * Show an error toast
     * @param message - The error message to display
     * @param options - Toast options (duration, persistent)
     */
    error: actions.error,

    /**
     * Show a warning toast
     * @param message - The warning message to display
     * @param options - Toast options (duration, persistent)
     */
    warning: actions.warning,

    /**
     * Show an info toast
     * @param message - The info message to display
     * @param options - Toast options (duration, persistent)
     */
    info: actions.info,

    /**
     * Hide a specific toast by ID
     * @param id - The toast ID to hide
     */
    hide: actions.hide,

    /**
     * Clear all toasts
     */
    clearAll: actions.clearAll,
  };
}

/**
 * Hook for API error handling with automatic toast display
 *
 * @example
 * ```tsx
 * function DataComponent() {
 *   const { handleError } = useApiErrorHandler();
 *
 *   const fetchData = async () => {
 *     try {
 *       const response = await fetch('/api/data');
 *       // ... handle success
 *     } catch (error) {
 *       handleError(error); // Automatically shows error toast
 *     }
 *   };
 * }
 * ```
 */
export function useApiErrorHandler() {
  const { error } = useToastActions();

  const handleError = (err: unknown, customMessage?: string) => {
    let message = customMessage || "An unexpected error occurred";

    if (err instanceof Error) {
      message = customMessage || err.message;
    } else if (typeof err === "string") {
      message = customMessage || err;
    }

    error(message);
  };

  const handleApiResponse = <T>(
    response: { data: T | null; error: any | null },
    successMessage?: string
  ) => {
    if (response.error) {
      handleError(response.error);
      return false;
    }

    if (successMessage) {
      const { success } = useToastActions();
      success(successMessage);
    }

    return true;
  };

  return {
    handleError,
    handleApiResponse,
  };
}

/**
 * Hook for form submission with toast feedback
 *
 * @example
 * ```tsx
 * function ContactForm() {
 *   const { submitWithToast, isSubmitting } = useFormSubmission();
 *
 *   const handleSubmit = async (formData) => {
 *     await submitWithToast(
 *       () => submitContactForm(formData),
 *       'Message sent successfully!',
 *       'Failed to send message'
 *     );
 *   };
 * }
 * ```
 */
export function useFormSubmission() {
  const { success, error } = useToastActions();

  const submitWithToast = async <T>(
    submitFn: () => Promise<T>,
    successMessage: string = "Operation completed successfully",
    errorMessage: string = "Operation failed"
  ): Promise<T | null> => {
    try {
      const result = await submitFn();
      success(successMessage);
      return result;
    } catch (err) {
      const finalErrorMessage =
        err instanceof Error ? err.message : errorMessage;
      error(finalErrorMessage);
      return null;
    }
  };

  return {
    submitWithToast,
  };
}

export default useToastNotification;
