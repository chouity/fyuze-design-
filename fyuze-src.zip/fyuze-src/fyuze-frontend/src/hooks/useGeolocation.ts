import { useState, useEffect, useCallback } from "react";
import {
  getUserLocation,
  clearLocationCache,
  getGoogleSearchCountryCode,
  type LocationData,
} from "../utils/geolocation";

export interface UseGeolocationReturn {
  location: LocationData | null;
  countryCode: string;
  isLoading: boolean;
  error: string | null;
  refetchLocation: () => Promise<void>;
  clearCache: () => void;
}

export function useGeolocation(): UseGeolocationReturn {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchLocation = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const detectedLocation = await getUserLocation();
      setLocation(detectedLocation);

      console.log("🌍 Location updated:", detectedLocation);
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to detect location";
      setError(errorMessage);
      console.error("❌ Location detection failed:", err);

      // Set fallback location on error
      setLocation({
        country: "United States",
        countryCode: "us",
        region: "Unknown",
        city: "Unknown",
      });
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refetchLocation = useCallback(async () => {
    clearLocationCache();
    await fetchLocation();
  }, [fetchLocation]);

  const clearCache = useCallback(() => {
    clearLocationCache();
    setLocation(null);
    setError(null);
  }, []);

  // Fetch location on mount
  useEffect(() => {
    fetchLocation();
  }, [fetchLocation]);

  // Get the country code for Google Search API
  const countryCode = location
    ? getGoogleSearchCountryCode(location.countryCode)
    : "us";

  return {
    location,
    countryCode,
    isLoading,
    error,
    refetchLocation,
    clearCache,
  };
}
