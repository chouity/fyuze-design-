import { useState, useCallback } from "react";
import { searchTiktokCreators, searchCreators } from "../lib/supabaseClient";
import { AICreatorSearchResponse } from "../types/staticResponseAi";

interface UseAICreatorSearchParams {
  useMockData?: boolean;
}

interface AICreatorSearchResult {
  profileData?: any;
  showcaseData?: any[];
}

interface UseAICreatorSearchReturn {
  data: AICreatorSearchResult | null;
  isLoading: boolean;
  error: string | null;
  searchTiktokCreators: (
    topic: string,
    location: string,
    platform: string,
    searchResults: number,
    keywords?: string[]
  ) => Promise<void>;
  reset: () => void;
}

export const useAICreatorSearch = ({
  useMockData = false,
}: UseAICreatorSearchParams = {}): UseAICreatorSearchReturn => {
  const [data, setData] = useState<AICreatorSearchResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = useCallback(
    async (
      topic: string,
      location: string,
      platform: string,
      searchResults: number,
      keywords: string[] = []
    ) => {
     
      setIsLoading(true);
      setError(null);

      try {
        if (useMockData) {
        
          await new Promise((resolve) => setTimeout(resolve, 1500));

        
          // Return mock data
          setData(AICreatorSearchResponse);
        } else {
        
          let response;

          // Use different API functions based on platform
          if (platform.toLowerCase() === "tiktok") {
           
            response = await searchTiktokCreators(
              topic,
              location,
              platform,
              searchResults,
              keywords
            );
          } else {
           
            response = await searchCreators(
              topic,
              location,
              platform,
              searchResults,
              keywords
            );
          }

            // Handle different response formats
          let result: AICreatorSearchResult = {};

          if (response) {
         
            if (response.data.profileData && response.data.showcaseData) {
            
              result = {
                profileData: response.data.profileData,
                showcaseData: response.data.showcaseData,
              };
            } else if (response.data.showcaseData) {
            
              result = {
                showcaseData: response.data.showcaseData,
              };
            } else if (Array.isArray(response)) {
            
              result = {
                showcaseData: response,
              };
            } else if (response.data && Array.isArray(response.data)) {
            
              result = {
                showcaseData: response.data,
              };
            } else if (
              response.data?.platform_data &&
              Array.isArray(response.data.platform_data)
            ) {
            
              result = {
                showcaseData: response.data.platform_data,
              };
            } else if (
              response.profileData.data &&
              Array.isArray(response.profileData.data)
            ) {
             
              result = {
                showcaseData: response.profileData,
              };
            } else if (
              response.platform_data &&
              Array.isArray(response.platform_data)
            ) {
             
              result = {
                showcaseData: response.platform_data,
              };
            } else if (
              response.output?.all_info &&
              Array.isArray(response.output.all_info)
            ) {
              

              result = {
                showcaseData: response.output.all_info,
              };
            } else {
             

              result = {
                showcaseData: [response],
              };
            }
          } else {
          }


          // Log individual creators if available
          if (result.showcaseData && Array.isArray(result.showcaseData)) {
            // result.showcaseData.forEach((creator, index) => {
              // console.log(`👤 Creator ${index + 1}:`, {
              //   id: creator.id,
              //   username: creator.username,
              //   name: creator.name || creator.full_name,
              //   platform: creator.platform,
              //   followers: creator.followers,
              //   hasPlatformData: !!creator.platform_data,
              //   platformDataType: typeof creator.platform_data,
              // });

            // });
          }

          setData(result);
        }
      } catch (err) {
       

        setError(
          err instanceof Error ? err.message : "Failed to search creators"
        );
        setData(null);
      } finally {
         setIsLoading(false);
      }
    },
    [useMockData]
  );

  const reset = useCallback(() => {
    setData(null);
    setError(null);
    setIsLoading(false);
  }, []);

  return {
    data,
    isLoading,
    error,
    searchTiktokCreators: handleSearch,
    reset,
  };
};

export default useAICreatorSearch;
