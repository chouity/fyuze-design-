import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type {
  UseQueryOptions,
  UseMutationOptions,
} from "@tanstack/react-query";
import { callDatabaseFunction } from "../lib/supabaseClient";
import type { FunctionResponse } from "../lib/supabaseClient";
import type { Database } from "../../database.types";
import { queryKeys } from "../lib/queryKeys";

// Generic hook for querying database functions
export function useSupabaseQuery<T = any>(
  functionName: keyof Database["public"]["Functions"],
  params: Record<string, any> = {},
  options?: Omit<
    UseQueryOptions<FunctionResponse<T>, Error, T>,
    "queryKey" | "queryFn"
  >
) {
  return useQuery({
    queryKey: queryKeys.functions.function(functionName as string, params),
    queryFn: () => callDatabaseFunction<T>(functionName, params),
    select: (data) => data.data,
    ...options,
  });
}

// Generic hook for mutating database functions
export function useSupabaseMutation<T = any, TVariables = Record<string, any>>(
  functionName: keyof Database["public"]["Functions"],
  options?: UseMutationOptions<FunctionResponse<T>, Error, TVariables>
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (variables: TVariables) =>
      callDatabaseFunction<T>(functionName, variables as Record<string, any>),
    onSuccess: () => {
      // Invalidate related queries when mutation succeeds
      queryClient.invalidateQueries({
        queryKey: [functionName],
      });
    },
    ...options,
  });
}

// Specific hook for creators with enhanced caching
export function useCreators(params: Record<string, any> = {}) {
  return useSupabaseQuery("get_creators", params, {
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes (formerly cacheTime)
    refetchOnWindowFocus: false,
    retry: 3,
  });
}

// Specific hook for fetching a single creator by ID or username
export function useCreator(
  creatorIdentifier: string,
  options?: Parameters<typeof useSupabaseQuery>[2]
) {
  // Determine if the identifier is likely a username or ID
  // UUIDs typically have dashes, usernames typically don't
  const isLikelyId =
    creatorIdentifier.includes("-") || creatorIdentifier.length > 20;

  // Use appropriate parameter key based on identifier type
  const params = isLikelyId
    ? { id: creatorIdentifier }
    : { username: creatorIdentifier };

  console.log("useCreator: Looking up creator with params:", params);

  return useSupabaseQuery("get_creators", params, {
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes (formerly cacheTime)
    refetchOnWindowFocus: false,
    retry: 3,
    enabled: !!creatorIdentifier, // Only run query if creatorIdentifier is provided
    ...options, // Allow overriding options
  });
}
// Specific hook for locations with enhanced caching
export function useLocation(params: Record<string, any> = {}) {
  return useSupabaseQuery("get_locations", params, {
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes (formerly cacheTime)
    refetchOnWindowFocus: false,
    retry: 3,
  });
}
// Specific hook for locations with enhanced caching
export function usePlatforms() {
  return useSupabaseQuery("get_creator_platforms");
}
// Specific hook for categories with enhanced caching
export function useCategories() {
  return useSupabaseQuery("get_creator_categories");
}

// Hook for invalidating specific query patterns
export function useInvalidateQueries() {
  const queryClient = useQueryClient();

  return {
    invalidateCreators: () =>
      queryClient.invalidateQueries({ queryKey: queryKeys.creators.all }),
    invalidateSpecificCreators: (params: Record<string, any>) =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.creators.list(params),
      }),
    invalidateAll: () => queryClient.invalidateQueries(),
    removeQueries: (queryKey: readonly unknown[]) =>
      queryClient.removeQueries({ queryKey }),
  };
}
