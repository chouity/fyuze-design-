import { useState } from "react";
import { copyToClipboard } from "../utils/chatUtils";

export const useMessageActions = () => {
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  const handleCopyMessage = async (text: string, messageId: string) => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopiedMessageId(messageId);
      setTimeout(() => {
        setCopiedMessageId(null);
      }, 2000);
      console.log("Message copied to clipboard");
    }
  };

  const handleEditMessage = (messageId: string, text: string) => {
    setEditingMessageId(messageId);
    setEditText(text);
  };

  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setEditText("");
  };

  const handleSubmitEdit = async (
    _messageId: string,
    clearChat: () => void,
    sendMessage: (text: string) => void
  ) => {
    if (!editText.trim()) return;

    setEditingMessageId(null);
    const editedText = editText.trim();
    setEditText("");

    clearChat();
    setTimeout(() => {
      sendMessage(editedText);
    }, 100);
  };

  return {
    editingMessageId,
    editText,
    setEditText,
    copiedMessageId,
    handleCopyMessage,
    handleEditMessage,
    handleCancelEdit,
    handleSubmitEdit,
  };
};
