import { useState, useCallback } from "react";
import { createUserSession, fyuzeAICreators } from "../lib/supabaseClient";
import { useAuth } from "../contexts/AuthContext";
import { staticResponseAi } from "../types/staticResponseAi";
import type { Influencer } from "../types/chat";

const USE_STATIC_DATA = false;

export interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: Date;
  influencer_found?: Influencer[];
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  sessionId: string | null;
  userId: string;
}

export const useChat = () => {
  const { user } = useAuth();
  const userId = user?.id;
  const [chatState, setChatState] = useState<ChatState>({
    messages: [],
    isLoading: false,
    sessionId: null,
    userId: userId || `userId`,
  });

  const initializeSession = useCallback(async () => {
    try {
      const sessionRes = await createUserSession();
      const sessionId = sessionRes?.data;
      if (sessionId) {
        setChatState((prev) => ({
          ...prev,
          sessionId: sessionId,
        }));
        return sessionId;
      } else {
        throw new Error("Failed to create session");
      }
    } catch (error) {
      throw error;
    }
  }, []);

  const sendMessage = useCallback(
    async (message: string) => {
      // Add user message immediately
      const userMessage: Message = {
        id: Date.now(),
        text: message,
        isUser: true,
        timestamp: new Date(),
      };

      setChatState((prev) => ({
        ...prev,
        messages: [...prev.messages, userMessage],
        isLoading: true,
      }));

      try {
        let aiResponse;

        if (USE_STATIC_DATA) {
          // Use static data for testing - simulate network delay
          await new Promise((resolve) => setTimeout(resolve, 2000));

          // The static data now has the structure: { data: { text: "...", influencers_found: [...] } }
          // Use it directly since it already matches the expected API response format
          aiResponse = staticResponseAi;
        } else {
          // Use real AI agent
          let currentSessionId = chatState.sessionId;

          // Create session if this is the first message
          if (!currentSessionId) {
            currentSessionId = await initializeSession();
          }

          if (!currentSessionId) {
            throw new Error("No session ID available");
          }

          // Call the AI function
          aiResponse = await fyuzeAICreators(
            currentSessionId,
            message,
            chatState.userId
          );
        }

        // Extract data from response wrapper - handle multiple possible structures
        let responseData;
        if (aiResponse.success && aiResponse.data) {
          // Structure: { success: true, data: { text: "...", influencers_found: [...] } }
          responseData = aiResponse.data;
        } else if (aiResponse.data) {
          // Structure: { data: { text: "...", influencers_found: [...] } }
          responseData = aiResponse.data;
        } else {
          // Direct structure: { text: "...", influencers_found: [...] }
          responseData = aiResponse;
        }

        // Transform influencers to match the expected Influencer interface
        const transformedInfluencers =
          responseData.influencers_found?.map((creator: any) => {
            // Handle TikTok creators
            if (creator.unique_id || creator.uid) {
              const avatarUrl =
                creator.avatar_url || creator.profile_pic_url || "";
              return {
                username: creator.unique_id || creator.username || "unknown",
                url: `https://tiktok.com/@${
                  creator.unique_id || creator.username || "unknown"
                }`,
                biography: creator.signature || creator.bio || "",
                fullName:
                  creator.nickname ||
                  creator.name ||
                  creator.unique_id ||
                  "Unknown User",
                followersCount:
                  creator.follower_count || creator.followers || 0,
                profilePicUrl: avatarUrl,
                avatar_url: avatarUrl,
                originalPlatformData: creator,
                platform: "tiktok",
              };
            }
            // Handle Instagram creators
            else if (creator.username || creator.id) {
              const avatarUrl =
                creator.profile_pic_url || creator.avatar_url || "";
              return {
                username:
                  creator.username?.replace("@", "") || creator.id || "unknown",
                url: `https://instagram.com/${
                  creator.username?.replace("@", "") || creator.id
                }`,
                biography: creator.bio || creator.signature || "",
                fullName:
                  creator.full_name ||
                  creator.name ||
                  creator.username ||
                  "Unknown User",
                followersCount:
                  creator.followers_count || creator.followers || 0,
                profilePicUrl: avatarUrl,
                avatar_url: avatarUrl,
                originalPlatformData: creator,
                platform: "instagram",
              };
            }
            // Fallback for unknown format
            else {
              const avatarUrl =
                creator.profile_pic_url || creator.avatar_url || "";
              return {
                username: creator.username || creator.unique_id || "unknown",
                url: creator.url || "#",
                biography: creator.bio || creator.signature || "",
                fullName:
                  creator.full_name ||
                  creator.nickname ||
                  creator.name ||
                  "Unknown User",
                followersCount:
                  creator.followers_count ||
                  creator.follower_count ||
                  creator.followers ||
                  0,
                profilePicUrl: avatarUrl,
                avatar_url: avatarUrl,
                originalPlatformData: creator,
                platform: creator.platform || "unknown",
              };
            }
          }) || [];

        // Create AI message
        const aiMessage: Message = {
          id: Date.now() + 1,
          text: responseData.text || aiResponse.text || "No response received",
          isUser: false,
          timestamp: new Date(),
          influencer_found: transformedInfluencers,
        };

        if (
          aiMessage.influencer_found &&
          aiMessage.influencer_found.length > 0
        ) {
        }

        setChatState((prev) => ({
          ...prev,
          messages: [...prev.messages, aiMessage],
          isLoading: false,
        }));
      } catch (error) {
        // Extract error message for chat display
        let errorMessage = "Sorry, I encountered an error. Please try again.";

        if (error instanceof Error) {
          // Check for specific API error responses
          if ((error as any).apiError) {
            const apiError = (error as any).apiError;
            errorMessage = apiError.message || error.message;
          } else {
            errorMessage = error.message;
          }
        }

        // Add error message to chat (don't show toast here - global handler will do it)
        const chatErrorMessage: Message = {
          id: Date.now() + 1,
          text: errorMessage,
          isUser: false,
          timestamp: new Date(),
        };

        setChatState((prev) => ({
          ...prev,
          messages: [...prev.messages, chatErrorMessage],
          isLoading: false,
        }));
      }
    },
    [chatState.sessionId, chatState.userId, initializeSession]
  );

  const clearChat = useCallback(() => {
    setChatState((prev) => ({
      ...prev,
      messages: [],
      sessionId: null,
    }));
  }, []);

  return {
    messages: chatState.messages,
    isLoading: chatState.isLoading,
    sessionId: chatState.sessionId,
    userId: chatState.userId,
    sendMessage,
    clearChat,
  };
};
