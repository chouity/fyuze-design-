import { useMemo } from "react";
import type { Creator } from "../types/influencer";

export interface NormalizedCreator extends Omit<Creator, "posts"> {
  posts: any[];
  hashtags: string[];
  engagementData: {
    averageLikes: number;
    averageComments: number;
    engagementRate: number;
  };
}

export const useCreatorDataNormalization = (creators: Creator[] = []) => {
  const normalizedCreators = useMemo(() => {
    if (!creators || !Array.isArray(creators)) {
      return [];
    }

    return creators.map((creator): NormalizedCreator => {
      // Extract posts from various possible locations
      let posts: any[] = [];

      if (creator.posts?.edges && Array.isArray(creator.posts.edges)) {
        posts = creator.posts.edges.map((edge: any) => edge.node || edge);
      } else if (Array.isArray(creator.posts)) {
        posts = creator.posts;
      }

      // Calculate engagement metrics from posts
      let totalLikes = 0;
      let totalComments = 0;
      let postsWithEngagement = 0;

      posts.forEach((post: any) => {
        if (post.like_count || post.likes_count) {
          totalLikes += post.like_count || post.likes_count || 0;
          postsWithEngagement++;
        }
        if (post.comment_count || post.comments_count) {
          totalComments += post.comment_count || post.comments_count || 0;
        }
      });

      const averageLikes =
        postsWithEngagement > 0 ? totalLikes / postsWithEngagement : 0;
      const averageComments =
        postsWithEngagement > 0 ? totalComments / postsWithEngagement : 0;

      // Calculate engagement rate
      const followers = creator.followers || 0;
      const engagementRate =
        followers > 0
          ? ((averageLikes + averageComments) / followers) * 100
          : 0;

      // Extract hashtags from posts
      const hashtags: Set<string> = new Set();
      posts.forEach((post: any) => {
        const caption = post.caption || post.description || "";
        const hashtagMatches = caption.match(/#\w+/g);
        if (hashtagMatches) {
          hashtagMatches.forEach((hashtag: string) => hashtags.add(hashtag));
        }
      });

      return {
        ...creator,
        posts,
        hashtags: Array.from(hashtags),
        engagementData: {
          averageLikes,
          averageComments,
          engagementRate,
        },
      };
    });
  }, [creators]);

  return {
    normalizedCreators,
    posts: normalizedCreators.flatMap((creator) => creator.posts),
    isLoading: false,
    error: null,
  };
};
