import React, { useState, useEffect } from "react";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { ThemeProvider, useTheme } from "./contexts/ThemeContext";
import { ChatProvider, useChat } from "./contexts/ChatContext";
import { ToastProvider } from "./contexts/ToastContext";
import ToastContainer from "./components/common/ToastContainer";
import MiddlewareInitializer from "./components/common/MiddlewareInitializer";
import AuthPage from "./pages/AuthPage";
import Sidebar from "./components/sidebar/Sidebar";
import ChatInterface from "./Layout/ChatInterface";
import ForgetPassword from "./pages/ForgetPassword";
import UpdatePassword from "./pages/updatePassword";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import { QueryClientProvider } from "@tanstack/react-query";
import { createQueryClient } from "./lib/queryClient";
import ChatHeader from "./components/chatInterface/ChatHeader";
import UrlAnalyzerPage from "./pages/urlAnalyzerPage";
import { supabase } from "./lib/supabaseClient";
import MagicLinkSentPage from "./pages/MagicLinkSentPage";

// Lazy load heavy components
const CreatorDashboardPage = React.lazy(
  () => import("./pages/CreatorDashboardPage")
);
const CreatorProfilePage = React.lazy(
  () => import("./pages/CreatorProfilePage")
);
const ContactUsPage = React.lazy(() => import("./pages/ContactUsPage"));
const AdminDashboardPage = React.lazy(
  () => import("./pages/adminDashboardPage")
);
const SearchEnginePage = React.lazy(
  () => import("./pages/searchEnginePageFixed")
);

const queryClient = createQueryClient();

// Email verification pending component
const EmailVerificationPending: React.FC = () => {
  const { user, logout } = useAuth();
  const [resendLoading, setResendLoading] = useState(false);
  const [resendMessage, setResendMessage] = useState("");

  const handleResendEmail = async () => {
    if (!user?.email) return;

    setResendLoading(true);
    setResendMessage("");

    try {
      const { error } = await supabase.auth.resend({
        type: "signup",
        email: user.email,
      });

      if (error) {
        setResendMessage(
          "Failed to send verification email. Please try again."
        );
      } else {
        setResendMessage(
          "Verification email sent! Please check your inbox and spam folder."
        );
      }
    } catch (error) {
      setResendMessage("An error occurred. Please try again.");
    } finally {
      setResendLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-purple-900 dark:to-pink-900">
      <div className="max-w-md w-full mx-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-8 text-center">
          <div className="mb-6">
            <img
              src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
              alt="Fyuze Logo"
              className="w-20 h-20 mx-auto mb-4"
            />
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
              Verify Your Email
            </h1>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              We've sent a verification email to <strong>{user?.email}</strong>.
              Please check your inbox and click the verification link to access
              Fyuze.
            </p>
          </div>

          <div className="space-y-4">
            <button
              onClick={handleResendEmail}
              disabled={resendLoading}
              className="w-full bg-gradient-to-r from-pink-500 to-orange-500 text-white py-3 px-4 rounded-lg font-medium hover:from-pink-600 hover:to-orange-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {resendLoading ? "Sending..." : "Resend Verification Email"}
            </button>

            {resendMessage && (
              <div
                className={`p-3 rounded-lg text-sm ${
                  resendMessage.includes("sent")
                    ? "bg-green-50 text-green-800 dark:bg-green-900 dark:text-green-200"
                    : "bg-red-50 text-red-800 dark:bg-red-900 dark:text-red-200"
                }`}
              >
                {resendMessage}
              </div>
            )}

            <button
              onClick={logout}
              className="w-full bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 py-3 px-4 rounded-lg font-medium hover:bg-gray-200 dark:hover:bg-gray-600 transition-all"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
const AuthCallback: React.FC = () => {
  const { user } = useAuth();
  const [hasRedirected, setHasRedirected] = useState(false);

  useEffect(() => {
    // Check if user is authenticated and email confirmed
    if (!hasRedirected) {
      if (user && user.emailConfirmed) {
        // User is authenticated and confirmed, redirect to main app
        setHasRedirected(true);
        window.location.replace("/");
      } else if (user && !user.emailConfirmed) {
        // User signed up but email not confirmed yet, redirect to auth page
        setHasRedirected(true);
        window.location.replace("/auth");
      } else {
        // No user, redirect to auth page
        setHasRedirected(true);
        window.location.replace("/auth");
      }
    }
  }, [user, hasRedirected]);

  // Fallback redirect if auth takes too long
  useEffect(() => {
    const fallbackTimer = setTimeout(() => {
      if (!hasRedirected) {
        setHasRedirected(true);
        window.location.replace("/auth");
      }
    }, 5000);

    return () => clearTimeout(fallbackTimer);
  }, [hasRedirected]);

  // Return null - component will redirect before rendering
  return null;
};

const AppContent: React.FC = () => {
  const { user, isInitializing } = useAuth();
  const { theme, toggleTheme, isDark } = useTheme();
  const { createNewConversation } = useChat();

  // Show loading screen while checking authentication
  if (isInitializing) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center  ${
          isDark
            ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
            : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
        }`}
      >
        <div className="text-center">
          <div className="relative">
            <img
              src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
              alt="Fyuze Logo"
              className="w-16 h-16 mx-auto mb-6 animate-spin"
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <AppRoutes
        isInitializing={isInitializing}
        user={user}
        theme={theme}
        toggleTheme={toggleTheme}
        isDark={isDark}
        createNewConversation={createNewConversation}
      />
    </BrowserRouter>
  );
};

// Separate component that handles routing and has access to useLocation
const AppRoutes: React.FC<{
  user: any;
  isInitializing: boolean;
  theme: string;
  toggleTheme: () => void;
  isDark: boolean;
  createNewConversation: () => void;
}> = ({ user, theme, toggleTheme, isDark, createNewConversation }) => {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<
    | "chat"
    | "creators"
    | "contactus"
    | "adminDashboard"
    | "urlAnalyzer"
    | "searchEngine"
  >("chat");

  // Update currentPage based on the current route
  useEffect(() => {
    if (location.pathname.startsWith("/creators/")) {
      setCurrentPage("creators");
    } else if (location.pathname === "/app") {
      // Keep the current page or default to chat for /app route
      // Don't override if already set
    }
  }, [location.pathname]);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <Routes>
      {/* Public routes - accessible without authentication */}
      <Route path="/forget-password" element={<ForgetPassword />} />
      <Route path="/reset-password" element={<UpdatePassword />} />
      <Route path="/contactus" element={<ContactUsPage />} />
      <Route path="/auth/callback" element={<AuthCallback />} />

      {/* If user is not logged in, show AuthPage for all other routes */}
      {!user && (
        <>
          <Route path="*" element={<AuthPage />} />
        </>
      )}

      {/* If user is logged in but not confirmed, show email verification for all other routes */}
      {user && !user.emailConfirmed && (
        <>
          <Route path="*" element={<EmailVerificationPending />} />
        </>
      )}

      {/* If user is logged in and confirmed, show app routes */}
      {user && user.emailConfirmed && (
        <>
          <Route
            path="/app"
            element={
              <div className="bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-purple-900 dark:to-pink-900 h-dvh sm:h-screen">
                <Sidebar
                  isOpen={sidebarOpen}
                  onClose={() => setSidebarOpen(false)}
                  onToggle={toggleSidebar}
                  currentPage={currentPage}
                  setCurrentPage={setCurrentPage}
                />
                <div className="flex flex-col h-full">
                  <ChatHeader
                    onToggleSidebar={toggleSidebar}
                    onClearChat={createNewConversation}
                    onToggleTheme={toggleTheme}
                    theme={theme}
                    isDark={isDark}
                    userName={user?.name}
                    userEmail={user?.email}
                  />
                  <div
                    className={`flex-1 transition-all duration-300 ${
                      sidebarOpen ? "lg:ml-72" : ""
                    } ${
                      currentPage === "chat"
                        ? "overflow-hidden"
                        : "overflow-auto"
                    }`}
                  >
                    {currentPage === "chat" && <ChatInterface />}
                    {currentPage === "searchEngine" && <SearchEnginePage />}
                    {currentPage === "contactus" && <ContactUsPage />}
                    {currentPage === "creators" && <CreatorDashboardPage />}
                    {currentPage === "adminDashboard" && <AdminDashboardPage />}
                    {currentPage === "urlAnalyzer" && <UrlAnalyzerPage />}
                  </div>
                </div>
              </div>
            }
          />
          <Route
            path="/creators/:id"
            element={
              <div className="bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-purple-900 dark:to-pink-900 min-h-screen">
                <CreatorProfilePage />
              </div>
            }
          />
          <Route path="/" element={<MagicLinkSentPage />} />
          {/* Fallback: redirect all other routes to main app */}
          <Route path="*" element={<AuthPage />} />
        </>
      )}
    </Routes>
  );
};

export default function App() {
  return (
    <>
      <ThemeProvider>
        <AuthProvider>
          <ToastProvider>
            <ChatProvider>
              <QueryClientProvider client={queryClient}>
                <MiddlewareInitializer />
                <AppContent />
                <ToastContainer />
                <ReactQueryDevtools initialIsOpen={false} />
              </QueryClientProvider>
            </ChatProvider>
          </ToastProvider>
        </AuthProvider>
      </ThemeProvider>
    </>
  );
}
