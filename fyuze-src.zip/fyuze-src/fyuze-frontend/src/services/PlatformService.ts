/**
 * PLATFORM ABSTRACTION SERVICE
 *
 * Main service class that handles dynamic platform operations.
 * This service uses adapters to provide a unified interface
 * for all supported social media platforms.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import type {
  PlatformType,
  PlatformAdapter,
  DataSourceType,
  PlatformDataExtractionResult,
} from "../types/platform.types";
import { getPlatformConfig } from "../config/platforms";
import { InstagramAdapter } from "./adapters/InstagramAdapter";
import { TikTokAdapter } from "./adapters/TikTokAdapter";

export class PlatformService {
  private adapters: Map<PlatformType, PlatformAdapter> = new Map();

  constructor() {
    this.initializeAdapters();
  }

  private initializeAdapters(): void {
    // Register all platform adapters
    this.adapters.set("instagram", new InstagramAdapter());
    this.adapters.set("tiktok", new TikTokAdapter());

    // Future platforms can be added here:
    // this.adapters.set('youtube', new YouTubeAdapter());
    // this.adapters.set('twitter', new TwitterAdapter());
  }

  /**
   * Get adapter for a specific platform
   */
  getAdapter(platform: PlatformType): PlatformAdapter | null {
    return this.adapters.get(platform) || null;
  }

  /**
   * Check if a platform is supported
   */
  isPlatformSupported(platform: PlatformType): boolean {
    return this.adapters.has(platform);
  }

  /**
   * Get all supported platforms
   */
  getSupportedPlatforms(): PlatformType[] {
    return Array.from(this.adapters.keys());
  }

  /**
   * Extract creator profile from raw data using appropriate adapter
   */
  extractCreatorProfile(
    rawData: any,
    platform: PlatformType,
    dataSource: DataSourceType
  ): PlatformDataExtractionResult {
    const adapter = this.getAdapter(platform);

    if (!adapter) {
      return {
        profile: null as any,
        success: false,
        errors: [`Platform ${platform} is not supported`],
      };
    }

    try {
      // Validate data first
      if (!adapter.validateData(rawData)) {
        return {
          profile: null as any,
          success: false,
          errors: [`Invalid data format for platform ${platform}`],
        };
      }

      const profile = adapter.extractProfile(rawData, dataSource);

      return {
        profile,
        success: true,
        errors: [],
      };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Unknown error";
      return {
        profile: null as any,
        success: false,
        errors: [`Failed to extract profile for ${platform}: ${errorMessage}`],
      };
    }
  }

  /**
   * Normalize engagement rate across platforms
   */
  normalizeEngagementRate(rate: any, platform: PlatformType): number {
    const adapter = this.getAdapter(platform);
    if (!adapter) return 0;

    return adapter.normalizeEngagementRate(rate);
  }

  /**
   * Get platform configuration
   */
  getPlatformConfig(platform: PlatformType) {
    return getPlatformConfig(platform);
  }

  /**
   * Auto-detect platform from data
   */
  detectPlatform(data: any): PlatformType | null {
    // Try to detect platform from data structure
    if (data.platform) {
      return data.platform as PlatformType;
    }

    // Check for platform-specific identifiers
    if (data.uid || data.aweme_id || data.unique_id) {
      return "tiktok";
    }

    if (data.edge_followed_by || data.biography || data.profile_pic_url_hd) {
      return "instagram";
    }

    return null;
  }

  /**
   * Register a new platform adapter
   */
  registerAdapter(platform: PlatformType, adapter: PlatformAdapter): void {
    this.adapters.set(platform, adapter);
  }

  /**
   * Batch process multiple creators
   */
  async batchExtractProfiles(
    creators: Array<{
      data: any;
      platform: PlatformType;
      dataSource: DataSourceType;
    }>
  ): Promise<PlatformDataExtractionResult[]> {
    return Promise.all(
      creators.map(({ data, platform, dataSource }) =>
        this.extractCreatorProfile(data, platform, dataSource)
      )
    );
  }
}

// Export singleton instance
export const platformService = new PlatformService();
