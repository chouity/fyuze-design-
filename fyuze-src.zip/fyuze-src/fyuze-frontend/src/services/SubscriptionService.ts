import { supabase } from "../lib/supabaseClient";
import type {
  SubscriptionPlansResponse,
  CurrentSubscriptionResponse,
  ChooseSubscriptionResponse,
} from "../types/subscription";

export class SubscriptionService {
  // Helper method to check if user is authenticated
  private static async ensureAuthenticated() {
    const {
      data: { session },
      error,
    } = await supabase.auth.getSession();
    if (error || !session) {
      throw new Error("User must be authenticated to access subscription data");
    }
    return session;
  }

  static async getSubscriptionPlans(): Promise<SubscriptionPlansResponse> {
    try {
      // Ensure user is authenticated for RLS
      await this.ensureAuthenticated();

      const { data, error } = await supabase.rpc("get_subscription_plans", {
        input_json: {},
      });

      if (error) {
        throw new Error(error.message);
      }

      return data as SubscriptionPlansResponse;
    } catch (error) {
      console.error("Error fetching subscription plans:", error);
      throw error;
    }
  }

  static async getCurrentSubscription(): Promise<CurrentSubscriptionResponse> {
    try {
      // Ensure user is authenticated for RLS
      await this.ensureAuthenticated();

      const { data, error } = await supabase.rpc("get_current_subscription");

      if (error) {
        throw new Error(error.message);
      }

      return data as CurrentSubscriptionResponse;
    } catch (error) {
      console.error("Error fetching current subscription:", error);
      throw error;
    }
  }

  static async chooseSubscriptionPlan(
    planCode?: string
  ): Promise<ChooseSubscriptionResponse> {
    try {
      // Ensure user is authenticated for RLS
      await this.ensureAuthenticated();

      const { data, error } = await supabase.rpc("choose_subscription_plan", {
        p_plan_code: planCode || null,
      });

      if (error) {
        throw new Error(error.message);
      }

      return data as ChooseSubscriptionResponse;
    } catch (error) {
      console.error("Error choosing subscription plan:", error);
      throw error;
    }
  }
}
