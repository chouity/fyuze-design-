/**
 * TIKTOK PLATFORM ADAPTER
 *
 * Handles TikTok-specific data extraction and normalization.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import type {
  PlatformAdapter,
  PlatformCreatorProfile,
  PlatformPost,
} from "../../types/platform.types";

export class TikTokAdapter implements PlatformAdapter {
  platform = "tiktok" as const;

  extractProfile(rawData: any, dataSource: string): PlatformCreatorProfile {
    const platformData = this.parsePlatformData(rawData, dataSource);

    return {
      id: this.extractId(platformData),
      username: this.extractUsername(platformData),
      displayName: this.extractDisplayName(platformData),
      platform: "tiktok",
      bio: this.extractBio(platformData),
      avatarUrl: this.extractAvatarUrl(platformData),
      isVerified: this.extractVerified(platformData),
      followers: this.extractFollowers(platformData),
      following: this.extractFollowing(platformData),
      postsCount: this.extractPostsCount(platformData),
      engagementRate: this.normalizeEngagementRate(
        this.extractEngagementRate(platformData)
      ),
      contactEmail: this.extractContactEmail(platformData),
      externalLinks: this.extractExternalLinks(platformData),
      location: this.extractLocation(platformData),
      category: this.extractCategory(platformData),
      posts: this.extractPosts(platformData),
      platformSpecific: platformData,
      dataSource: dataSource as any,
      lastUpdated: new Date().toISOString(),
    };
  }

  extractPosts(rawData: any): PlatformPost[] {
    const posts = this.getPostsArray(rawData);
    if (!Array.isArray(posts)) return [];

    return posts.map((post, index) => ({
      id: post.aweme_id || post.id || `post_${index}`,
      caption: this.extractPostCaption(post),
      thumbnail: this.extractPostThumbnail(post),
      url: post.video_url,
      likes: this.extractPostLikes(post),
      comments: this.extractPostComments(post),
      shares: post.share_count || 0,
      views: post.play_count || post.view_count || 0,
      createdAt: this.extractPostDate(post),
      type: "video" as const,
      platform: "tiktok",
    }));
  }

  normalizeEngagementRate(rate: any): number {
    if (typeof rate === "number") return rate;
    if (typeof rate === "string") {
      const parsed = parseFloat(rate);
      return isNaN(parsed) ? 0 : parsed;
    }
    return 0;
  }

  validateData(data: any): boolean {
    if (!data) return false;

    // Check for TikTok-specific fields
    return !!(
      data.uid ||
      data.unique_id ||
      data.aweme_count !== undefined ||
      data.follower_count !== undefined ||
      data.platform === "tiktok"
    );
  }

  // Private helper methods
  private parsePlatformData(rawData: any, dataSource: string) {
    if (dataSource === "ai_search") {
      return rawData;
    }

    if (dataSource === "database" && rawData.platform_data) {
      try {
        return typeof rawData.platform_data === "string"
          ? JSON.parse(rawData.platform_data)
          : rawData.platform_data;
      } catch {
        return rawData;
      }
    }

    return rawData;
  }

  private extractId(data: any): string {
    return data.uid || data.id || data.user_id || "";
  }

  private extractUsername(data: any): string {
    return data.unique_id || data.username || "";
  }

  private extractDisplayName(data: any): string {
    return (
      data.nickname || data.display_name || data.name || data.unique_id || ""
    );
  }

  private extractBio(data: any): string {
    return data.signature || data.bio || "";
  }

  private extractAvatarUrl(data: any): string {
    return data.avatar_url || data.avatar_larger?.url_list?.[0] || "";
  }

  private extractVerified(data: any): boolean {
    return !!(data.is_verified || data.verified || data.verification_type);
  }

  private extractFollowers(data: any): number {
    return data.follower_count || data.followers || 0;
  }

  private extractFollowing(data: any): number {
    return data.following_count || data.following || 0;
  }

  private extractPostsCount(data: any): number {
    return data.aweme_count || data.videos?.count || data.posts?.count || 0;
  }

  private extractEngagementRate(data: any): any {
    return data.engagementRate || data.engagement_rate || 0;
  }

  private extractContactEmail(data: any): string | undefined {
    return data.contact_email;
  }

  private extractExternalLinks(data: any): string[] {
    const links: string[] = [];
    if (data.links && Array.isArray(data.links)) links.push(...data.links);
    return links;
  }

  private extractLocation(data: any): string | undefined {
    return data.region || data.location;
  }

  private extractCategory(data: any): string | undefined {
    return data.category;
  }

  private getPostsArray(data: any): any[] {
    if (data.videos?.videos && Array.isArray(data.videos.videos)) {
      return data.videos.videos;
    }
    if (Array.isArray(data.posts)) return data.posts;
    if (Array.isArray(data.videos)) return data.videos;
    return [];
  }

  private extractPostCaption(post: any): string {
    return post.desc || post.caption || "";
  }

  private extractPostThumbnail(post: any): string {
    return post.cover_url || post.thumbnail || "";
  }

  private extractPostLikes(post: any): number {
    return post.like_count || post.digg_count || 0;
  }

  private extractPostComments(post: any): number {
    return post.comment_count || 0;
  }

  private extractPostDate(post: any): string {
    if (post.create_time) {
      return new Date(post.create_time * 1000).toISOString();
    }
    return post.created_time || new Date().toISOString();
  }
}
