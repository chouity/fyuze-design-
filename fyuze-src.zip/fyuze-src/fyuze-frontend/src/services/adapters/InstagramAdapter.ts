/**
 * INSTAGRAM PLATFORM ADAPTER
 *
 * Handles Instagram-specific data extraction and normalization.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import type {
  PlatformAdapter,
  PlatformCreatorProfile,
  PlatformPost,
} from "../../types/platform.types";

export class InstagramAdapter implements PlatformAdapter {
  platform = "instagram" as const;

  extractProfile(rawData: any, dataSource: string): PlatformCreatorProfile {
    const platformData = this.parsePlatformData(rawData, dataSource);

    return {
      id: this.extractId(platformData),
      username: this.extractUsername(platformData),
      displayName: this.extractDisplayName(platformData),
      platform: "instagram",
      bio: this.extractBio(platformData),
      avatarUrl: this.extractAvatarUrl(platformData),
      isVerified: this.extractVerified(platformData),
      followers: this.extractFollowers(platformData),
      following: this.extractFollowing(platformData),
      postsCount: this.extractPostsCount(platformData),
      engagementRate: this.normalizeEngagementRate(
        this.extractEngagementRate(platformData)
      ),
      contactEmail: this.extractContactEmail(platformData),
      externalLinks: this.extractExternalLinks(platformData),
      location: this.extractLocation(platformData),
      category: this.extractCategory(platformData),
      posts: this.extractPosts(platformData),
      platformSpecific: platformData,
      dataSource: dataSource as any,
      lastUpdated: new Date().toISOString(),
    };
  }

  extractPosts(rawData: any): PlatformPost[] {
    const posts = this.getPostsArray(rawData);
    if (!Array.isArray(posts)) return [];

    return posts.map((post, index) => ({
      id: post.id || post.shortcode || `post_${index}`,
      caption: this.extractPostCaption(post),
      thumbnail: this.extractPostThumbnail(post),
      url: post.permalink || post.display_url,
      likes: this.extractPostLikes(post),
      comments: this.extractPostComments(post),
      shares: post.share_count || 0,
      views: post.view_count || post.play_count || 0,
      createdAt: this.extractPostDate(post),
      type: this.determinePostType(post),
      platform: "instagram",
    }));
  }

  normalizeEngagementRate(rate: any): number {
    if (typeof rate === "number") return rate;
    if (typeof rate === "string") {
      const parsed = parseFloat(rate);
      return isNaN(parsed) ? 0 : parsed;
    }
    return 0;
  }

  validateData(data: any): boolean {
    if (!data) return false;

    // Check for Instagram-specific fields
    return !!(
      data.username ||
      data.biography !== undefined ||
      data.profile_pic_url ||
      data.edge_followed_by ||
      (data.platform_data && typeof data.platform_data === "string")
    );
  }

  // Private helper methods
  private parsePlatformData(rawData: any, dataSource: string) {
    if (dataSource === "ai_search") {
      return rawData;
    }

    if (dataSource === "database" && rawData.platform_data) {
      try {
        return typeof rawData.platform_data === "string"
          ? JSON.parse(rawData.platform_data)
          : rawData.platform_data;
      } catch {
        return rawData;
      }
    }

    return rawData;
  }

  private extractId(data: any): string {
    return data.id || data.pk || data.user_id || "";
  }

  private extractUsername(data: any): string {
    return data.username || "";
  }

  private extractDisplayName(data: any): string {
    return data.full_name || data.name || data.username || "";
  }

  private extractBio(data: any): string {
    return data.biography || data.bio || "";
  }

  private extractAvatarUrl(data: any): string {
    return (
      data.profile_pic_url_hd || data.profile_pic_url || data.avatar_url || ""
    );
  }

  private extractVerified(data: any): boolean {
    return !!(data.is_verified || data.verified);
  }

  private extractFollowers(data: any): number {
    return data.edge_followed_by?.count || data.followers || 0;
  }

  private extractFollowing(data: any): number {
    return data.edge_follow?.count || data.following || 0;
  }

  private extractPostsCount(data: any): number {
    return data.edge_owner_to_timeline_media?.count || data.posts?.count || 0;
  }

  private extractEngagementRate(data: any): any {
    return data.engagementRate || data.engagement_rate || 0;
  }

  private extractContactEmail(data: any): string | undefined {
    return data.business_email || data.contact_email;
  }

  private extractExternalLinks(data: any): string[] {
    const links: string[] = [];
    if (data.external_url) links.push(data.external_url);
    if (data.links && Array.isArray(data.links)) links.push(...data.links);
    return links;
  }

  private extractLocation(data: any): string | undefined {
    return data.location;
  }

  private extractCategory(data: any): string | undefined {
    return data.category_name || data.category;
  }

  private getPostsArray(data: any): any[] {
    if (data.posts?.edges)
      return data.posts.edges.map((edge: any) => edge.node || edge);
    if (Array.isArray(data.posts)) return data.posts;
    if (data.edge_owner_to_timeline_media?.edges) {
      return data.edge_owner_to_timeline_media.edges.map(
        (edge: any) => edge.node
      );
    }
    return [];
  }

  private extractPostCaption(post: any): string {
    if (post.caption?.text) return post.caption.text;
    if (post.edge_media_to_caption?.edges?.[0]?.node?.text) {
      return post.edge_media_to_caption.edges[0].node.text;
    }
    return post.caption || "";
  }

  private extractPostThumbnail(post: any): string {
    return post.display_url || post.thumbnail_src || "";
  }

  private extractPostLikes(post: any): number {
    return post.like_count || post.edge_liked_by?.count || 0;
  }

  private extractPostComments(post: any): number {
    return post.comment_count || post.edge_media_to_comment?.count || 0;
  }

  private extractPostDate(post: any): string {
    if (post.taken_at_timestamp) {
      return new Date(post.taken_at_timestamp * 1000).toISOString();
    }
    return post.created_time || new Date().toISOString();
  }

  private determinePostType(post: any): "image" | "video" | "carousel" {
    if (post.is_video) return "video";
    if (post.__typename === "GraphSidecar" || post.typename === "GraphSidecar")
      return "carousel";
    return "image";
  }
}
