import type { NavigateFunction } from "react-router-dom";
import { callDatabaseFunction } from "../lib/supabaseClient";
import { extractPlatformFromUrl } from "../utils/platformUtils";
import type { Creator } from "../types/influencer";
import type { Influencer } from "../types/chat";

/**
 * Service for handling influencer profile navigation and data fetching
 */
export class ProfileNavigationService {
  private navigate: NavigateFunction;

  constructor(navigate: NavigateFunction) {
    this.navigate = navigate;
  }

  /**
   * Transforms influencer data to creator format for fallback
   */
  private transformInfluencerToCreator(
    influencer: Influencer,
    platform: string
  ): Creator {
    return {
      name: influencer.fullName || influencer.username || "Unknown User",
      full_name: influencer.fullName,
      username: influencer.username,
      platform: platform,
      followers: influencer.followersCount,
      bio: influencer.biography,
      avatar_url: influencer.profilePicUrl,
      url: influencer.url,
      location: "Not specified",
      verified: false,
      engagement_rate: "N/A",
      audience_demographics: {
        quality_audience: 0,
        followers_growth: 0,
        authentic_engagement: 0,
        post_frequency: "Unknown",
      },
    };
  }

  /**
   * Navigates to creator profile with fallback data
   */
  private navigateWithFallbackData(
    influencer: Influencer,
    username: string,
    platform: string
  ): void {
    this.navigate(`/creators/${username}`, {
      state: {
        creator: this.transformInfluencerToCreator(influencer, platform),
        originalInfluencer: influencer,
      },
    });
  }

  /**
   * Opens creator profile in a new tab with fallback data
   */
  private openInNewTabWithFallbackData(
    influencer: Influencer,
    username: string,
    platform: string
  ): void {
    const url = `/creators/${username}`;
    const creatorData = this.transformInfluencerToCreator(influencer, platform);

    // Store data in sessionStorage for the new tab to access
    const tabId = `creator_${Date.now()}_${Math.random()
      .toString(36)
      .substr(2, 9)}`;
    sessionStorage.setItem(
      `creator_data_${tabId}`,
      JSON.stringify({
        creator: creatorData,
        originalInfluencer: influencer,
      })
    );

    // Open in new tab with tab ID as query parameter
    window.open(`${url}?tabId=${tabId}`, "_blank");
  }

  /**
   * Handles viewing creator profile by fetching data and navigating
   */
  async handleViewProfile(influencer: Influencer): Promise<void> {
    try {
      const platform = extractPlatformFromUrl(influencer.url);
      const username = influencer.username;

      // Call get_creators function with username and platform using Supabase client
      const response = await callDatabaseFunction("get_creators", {
        username: username,
        platform: platform,
      });

      if (!response.error && response.data) {
        // Navigate to creator profile page with the fetched data
        const creatorData = Array.isArray(response.data)
          ? response.data[0]
          : response.data;

        this.navigate(`/creators/${username}`, {
          state: {
            creator: creatorData,
            originalInfluencer: influencer,
          },
        });
      } else {
        console.error("Failed to fetch creator data:", response.error);
        // Fallback: navigate with influencer data transformed to creator format
        this.navigateWithFallbackData(influencer, username, platform);
      }
    } catch (error) {
      console.error("Error fetching creator profile:", error);
      // Fallback: navigate with influencer data transformed to creator format
      const platform = extractPlatformFromUrl(influencer.url);
      this.navigateWithFallbackData(influencer, influencer.username, platform);
    }
  }

  /**
   * Handles viewing creator profile in a new tab by fetching data and opening new window
   */
  async handleViewProfileInNewTab(influencer: Influencer): Promise<void> {
    try {
      const platform = extractPlatformFromUrl(influencer.url);
      const username = influencer.username;

      // Call get_creators function with username and platform using Supabase client
      const response = await callDatabaseFunction("get_creators", {
        username: username,
        platform: platform,
      });

      if (!response.error && response.data) {
        // Open creator profile page in new tab with the fetched data
        const creatorData = Array.isArray(response.data)
          ? response.data[0]
          : response.data;

        const url = `/creators/${username}`;

        // Store data in sessionStorage for the new tab to access
        const tabId = `creator_${Date.now()}_${Math.random()
          .toString(36)
          .substr(2, 9)}`;
        sessionStorage.setItem(
          `creator_data_${tabId}`,
          JSON.stringify({
            creator: creatorData,
            originalInfluencer: influencer,
          })
        );

        // Open in new tab with tab ID as query parameter
        window.open(`${url}?tabId=${tabId}`, "_blank");
      } else {
        console.error("Failed to fetch creator data:", response.error);
        // Fallback: open with influencer data transformed to creator format
        this.openInNewTabWithFallbackData(influencer, username, platform);
      }
    } catch (error) {
      console.error("Error fetching creator profile:", error);
      // Fallback: open with influencer data transformed to creator format
      const platform = extractPlatformFromUrl(influencer.url);
      this.openInNewTabWithFallbackData(
        influencer,
        influencer.username,
        platform
      );
    }
  }
}
