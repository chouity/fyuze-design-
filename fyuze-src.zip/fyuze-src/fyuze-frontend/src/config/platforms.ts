/**
 * PLATFORM CONFIGURATION SYSTEM
 *
 * This file contains the complete configuration for all supported social media platforms.
 * Adding a new platform is as simple as adding a new configuration object.
 *
 * @author Fyuze Team
 * @version 2.0.0
 * @last-updated 2025-09-23
 */

import {
  faInstagram,
  faYoutube,
  faTiktok,
  faTwitter,
  faFacebookF,
  faLinkedin,
  faSnapchat,
  faPinterest,
  faTwitch,
} from "@fortawesome/free-brands-svg-icons";

// ===== TYPE DEFINITIONS =====

export type PlatformType =
  | "instagram"
  | "tiktok"
  | "youtube"
  | "twitter"
  | "x"
  | "facebook"
  | "linkedin"
  | "snapchat"
  | "pinterest"
  | "twitch";

export interface PlatformFieldMapping {
  // Primary identifiers
  id: string[];
  username: string[];
  displayName: string[];

  // Social metrics
  followers: string[];
  following: string[];
  posts: string[];

  // Profile data
  bio: string[];
  avatar: string[];
  verified: string[];

  // Platform-specific fields
  platformSpecific: {
    [key: string]: string[];
  };
}

export interface PlatformDetectionRules {
  // Required fields that indicate this platform
  requiredFields: string[];
  // Unique fields that only this platform has
  uniqueFields: string[];
  // Explicit platform identifiers
  explicitIdentifiers: string[];
}

export interface PlatformConfiguration {
  // Basic information
  id: PlatformType;
  name: string;
  displayName: string;

  // Visual representation
  icon: any; // FontAwesome icon
  color: string;
  backgroundColor: string;
  borderColor: string;

  // Data mapping
  fieldMapping: PlatformFieldMapping;
  detectionRules: PlatformDetectionRules;

  // API configuration
  apiEndpoints?: {
    search?: string;
    profile?: string;
    posts?: string;
  };

  // Content types supported
  contentTypes: string[];

  // Engagement metrics available
  engagementMetrics: string[];
}

// ===== PLATFORM CONFIGURATIONS =====

export const PLATFORM_CONFIGS: Record<PlatformType, PlatformConfiguration> = {
  instagram: {
    id: "instagram",
    name: "instagram",
    displayName: "Instagram",
    icon: faInstagram,
    color: "#E4405F",
    backgroundColor: "rgba(228, 64, 95, 0.1)",
    borderColor: "rgba(228, 64, 95, 0.3)",
    fieldMapping: {
      id: ["id", "instagram_id", "user_id"],
      username: ["username", "instagram_username"],
      displayName: ["full_name", "name", "display_name"],
      followers: ["followers", "follower_count", "edge_followed_by.count"],
      following: ["following", "following_count", "edge_follow.count"],
      posts: ["posts", "media_count", "edge_owner_to_timeline_media.count"],
      bio: ["bio", "biography", "description"],
      avatar: ["profile_pic_url", "profile_pic_url_hd", "avatar_url"],
      verified: ["is_verified", "verified"],
      platformSpecific: {
        businessAccount: ["is_business_account"],
        professionalAccount: ["is_professional_account"],
        category: ["category_name", "business_category_name"],
        externalUrl: ["external_url"],
        isPrivate: ["is_private"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: [
        "edge_followed_by",
        "edge_follow",
        "edge_owner_to_timeline_media",
      ],
      explicitIdentifiers: ["instagram"],
    },
    contentTypes: ["photo", "video", "reel", "story", "igtv"],
    engagementMetrics: ["likes", "comments", "shares", "saves"],
  },

  tiktok: {
    id: "tiktok",
    name: "tiktok",
    displayName: "TikTok",
    icon: faTiktok,
    color: "#000000",
    backgroundColor: "rgba(0, 0, 0, 0.1)",
    borderColor: "rgba(0, 0, 0, 0.3)",
    fieldMapping: {
      id: ["uid", "user_id", "id"],
      username: ["unique_id", "username"],
      displayName: ["nickname", "display_name", "name"],
      followers: ["follower_count", "followers"],
      following: ["following_count", "following"],
      posts: ["aweme_count", "video_count", "posts_count"],
      bio: ["signature", "bio", "description"],
      avatar: ["avatar_url", "profile_pic_url"],
      verified: ["is_verified", "verified", "verification_type"],
      platformSpecific: {
        totalFavorited: ["total_favorited"],
        region: ["region"],
        birthday: ["birthday"],
        verificationType: ["verification_type"],
        videos: ["videos"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: [
        "unique_id",
        "aweme_count",
        "signature",
        "total_favorited",
      ],
      explicitIdentifiers: ["tiktok"],
    },
    contentTypes: ["video", "live"],
    engagementMetrics: ["likes", "comments", "shares", "views", "favorites"],
  },

  youtube: {
    id: "youtube",
    name: "youtube",
    displayName: "YouTube",
    icon: faYoutube,
    color: "#FF0000",
    backgroundColor: "rgba(255, 0, 0, 0.1)",
    borderColor: "rgba(255, 0, 0, 0.3)",
    fieldMapping: {
      id: ["channel_id", "id", "youtube_id"],
      username: ["username", "handle", "custom_url"],
      displayName: ["title", "name", "channel_name"],
      followers: ["subscriber_count", "subscribers", "followers"],
      following: ["subscription_count", "following"],
      posts: ["video_count", "videos", "upload_count"],
      bio: ["description", "bio", "channel_description"],
      avatar: ["thumbnail_url", "avatar_url", "profile_image_url"],
      verified: ["is_verified", "verified"],
      platformSpecific: {
        viewCount: ["view_count", "total_views"],
        country: ["country"],
        publishedAt: ["published_at", "created_at"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: ["channel_id", "subscriber_count", "video_count"],
      explicitIdentifiers: ["youtube"],
    },
    contentTypes: ["video", "short", "live", "premiere"],
    engagementMetrics: [
      "views",
      "likes",
      "dislikes",
      "comments",
      "subscribers",
    ],
  },

  twitter: {
    id: "twitter",
    name: "twitter",
    displayName: "Twitter",
    icon: faTwitter,
    color: "#1DA1F2",
    backgroundColor: "rgba(29, 161, 242, 0.1)",
    borderColor: "rgba(29, 161, 242, 0.3)",
    fieldMapping: {
      id: ["id", "user_id", "twitter_id"],
      username: ["username", "screen_name"],
      displayName: ["name", "display_name"],
      followers: ["followers_count", "followers"],
      following: ["friends_count", "following_count", "following"],
      posts: ["statuses_count", "tweet_count", "posts"],
      bio: ["description", "bio"],
      avatar: ["profile_image_url", "profile_image_url_https", "avatar_url"],
      verified: ["verified", "is_verified"],
      platformSpecific: {
        location: ["location"],
        url: ["url"],
        favouritesCount: ["favourites_count"],
        listedCount: ["listed_count"],
        createdAt: ["created_at"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: [
        "screen_name",
        "friends_count",
        "statuses_count",
        "favourites_count",
      ],
      explicitIdentifiers: ["twitter"],
    },
    contentTypes: ["tweet", "retweet", "quote_tweet", "reply"],
    engagementMetrics: ["likes", "retweets", "replies", "quotes"],
  },

  x: {
    id: "x",
    name: "x",
    displayName: "X (Twitter)",
    icon: faTwitter, // Using Twitter icon until X icon is available
    color: "#000000",
    backgroundColor: "rgba(0, 0, 0, 0.1)",
    borderColor: "rgba(0, 0, 0, 0.3)",
    fieldMapping: {
      id: ["id", "user_id", "x_id"],
      username: ["username", "handle"],
      displayName: ["name", "display_name"],
      followers: ["followers_count", "followers"],
      following: ["following_count", "following"],
      posts: ["posts_count", "post_count"],
      bio: ["description", "bio"],
      avatar: ["profile_image_url", "avatar_url"],
      verified: ["verified", "is_verified"],
      platformSpecific: {
        location: ["location"],
        url: ["url"],
        createdAt: ["created_at"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: ["x_id", "posts_count"],
      explicitIdentifiers: ["x"],
    },
    contentTypes: ["post", "repost", "quote", "reply"],
    engagementMetrics: ["likes", "reposts", "replies", "quotes", "bookmarks"],
  },

  facebook: {
    id: "facebook",
    name: "facebook",
    displayName: "Facebook",
    icon: faFacebookF,
    color: "#1877F2",
    backgroundColor: "rgba(24, 119, 242, 0.1)",
    borderColor: "rgba(24, 119, 242, 0.3)",
    fieldMapping: {
      id: ["id", "facebook_id", "page_id"],
      username: ["username", "page_username"],
      displayName: ["name", "page_name"],
      followers: ["fan_count", "followers", "likes"],
      following: ["following_count"],
      posts: ["posts_count"],
      bio: ["about", "description", "bio"],
      avatar: ["picture", "avatar_url", "profile_pic"],
      verified: ["is_verified", "verified"],
      platformSpecific: {
        category: ["category"],
        website: ["website"],
        phone: ["phone"],
        location: ["location"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: ["fan_count", "page_id"],
      explicitIdentifiers: ["facebook"],
    },
    contentTypes: ["post", "photo", "video", "story", "reel"],
    engagementMetrics: ["likes", "comments", "shares", "reactions"],
  },

  linkedin: {
    id: "linkedin",
    name: "linkedin",
    displayName: "LinkedIn",
    icon: faLinkedin,
    color: "#0A66C2",
    backgroundColor: "rgba(10, 102, 194, 0.1)",
    borderColor: "rgba(10, 102, 194, 0.3)",
    fieldMapping: {
      id: ["id", "linkedin_id"],
      username: ["username", "public_identifier"],
      displayName: ["name", "full_name"],
      followers: ["follower_count", "followers"],
      following: ["following_count", "connections"],
      posts: ["posts_count"],
      bio: ["summary", "headline", "bio"],
      avatar: ["profile_picture", "avatar_url"],
      verified: ["is_verified"],
      platformSpecific: {
        headline: ["headline"],
        industry: ["industry"],
        location: ["location"],
        connections: ["num_connections"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: ["public_identifier", "headline", "num_connections"],
      explicitIdentifiers: ["linkedin"],
    },
    contentTypes: ["post", "article", "video"],
    engagementMetrics: ["likes", "comments", "shares", "reactions"],
  },

  snapchat: {
    id: "snapchat",
    name: "snapchat",
    displayName: "Snapchat",
    icon: faSnapchat,
    color: "#FFFC00",
    backgroundColor: "rgba(255, 252, 0, 0.1)",
    borderColor: "rgba(255, 252, 0, 0.3)",
    fieldMapping: {
      id: ["id", "snapchat_id"],
      username: ["username"],
      displayName: ["display_name", "name"],
      followers: ["subscriber_count", "followers"],
      following: ["following_count"],
      posts: ["snap_count"],
      bio: ["bio"],
      avatar: ["bitmoji_url", "avatar_url"],
      verified: ["is_verified"],
      platformSpecific: {
        snapchatScore: ["snap_score"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: ["snap_score", "bitmoji_url"],
      explicitIdentifiers: ["snapchat"],
    },
    contentTypes: ["snap", "story"],
    engagementMetrics: ["views", "screenshots"],
  },

  pinterest: {
    id: "pinterest",
    name: "pinterest",
    displayName: "Pinterest",
    icon: faPinterest,
    color: "#E60023",
    backgroundColor: "rgba(230, 0, 35, 0.1)",
    borderColor: "rgba(230, 0, 35, 0.3)",
    fieldMapping: {
      id: ["id", "pinterest_id"],
      username: ["username"],
      displayName: ["full_name", "name"],
      followers: ["follower_count", "followers"],
      following: ["following_count"],
      posts: ["pin_count"],
      bio: ["about", "bio"],
      avatar: ["image", "avatar_url"],
      verified: ["is_verified"],
      platformSpecific: {
        boardCount: ["board_count"],
        monthlyViews: ["monthly_views"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: ["pin_count", "board_count"],
      explicitIdentifiers: ["pinterest"],
    },
    contentTypes: ["pin", "story", "idea"],
    engagementMetrics: ["saves", "clicks", "impressions"],
  },

  twitch: {
    id: "twitch",
    name: "twitch",
    displayName: "Twitch",
    icon: faTwitch,
    color: "#9146FF",
    backgroundColor: "rgba(145, 70, 255, 0.1)",
    borderColor: "rgba(145, 70, 255, 0.3)",
    fieldMapping: {
      id: ["id", "twitch_id"],
      username: ["login", "username"],
      displayName: ["display_name", "name"],
      followers: ["follower_count", "followers"],
      following: ["following_count"],
      posts: ["video_count"],
      bio: ["description", "bio"],
      avatar: ["profile_image_url", "avatar_url"],
      verified: ["is_verified", "partnered"],
      platformSpecific: {
        viewCount: ["view_count"],
        broadcasterType: ["broadcaster_type"],
        createdAt: ["created_at"],
      },
    },
    detectionRules: {
      requiredFields: [],
      uniqueFields: ["login", "broadcaster_type", "view_count"],
      explicitIdentifiers: ["twitch"],
    },
    contentTypes: ["stream", "video", "clip"],
    engagementMetrics: ["views", "followers", "subscribers"],
  },
};

// ===== UTILITY FUNCTIONS =====

/**
 * Get platform configuration by platform type
 */
export const getPlatformConfig = (
  platform: PlatformType
): PlatformConfiguration => {
  return PLATFORM_CONFIGS[platform];
};

/**
 * Get all supported platforms
 */
export const getAllPlatforms = (): PlatformType[] => {
  return Object.keys(PLATFORM_CONFIGS) as PlatformType[];
};

/**
 * Get platform by name (case insensitive)
 */
export const getPlatformByName = (name: string): PlatformType | null => {
  const normalizedName = name.toLowerCase();
  const platforms = getAllPlatforms();
  return (
    platforms.find(
      (platform) =>
        platform === normalizedName ||
        PLATFORM_CONFIGS[platform].name === normalizedName ||
        PLATFORM_CONFIGS[platform].displayName.toLowerCase() === normalizedName
    ) || null
  );
};

/**
 * Check if a platform is supported
 */
export const isPlatformSupported = (platform: string): boolean => {
  return getPlatformByName(platform) !== null;
};

/**
 * Get platform color scheme
 */
export const getPlatformColors = (platform: PlatformType) => {
  const config = getPlatformConfig(platform);
  return {
    color: config.color,
    backgroundColor: config.backgroundColor,
    borderColor: config.borderColor,
  };
};

/**
 * Get platform icon props for FontAwesome component
 */
export const getPlatformIcon = (platform: PlatformType) => {
  const config = getPlatformConfig(platform);

  // Handle undefined/null platform gracefully
  if (!platform || !config) {
    return null;
  }

  return {
    icon: config.icon,
    style: { color: config.color },
    className: "text-lg",
  };
};
