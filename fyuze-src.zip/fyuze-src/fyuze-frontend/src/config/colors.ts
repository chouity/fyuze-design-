export const themeColors = {
  // Primary brand colors (matching logo)
  primary: {
    start: "from-orange-500",
    middle: "via-red-500",
    end: "to-yellow-500",
    hover: {
      start: "from-orange-600",
      middle: "via-red-600",
      end: "to-yellow-600",
    },
  },

  // Secondary gradient (complementary)
  secondary: {
    start: "from-pink-500",
    middle: "via-purple-500",
    end: "to-orange-500",
    hover: {
      start: "from-pink-600",
      middle: "via-purple-600",
      end: "to-orange-600",
    },
  },

  // Accent colors
  accent: {
    orange: "text-orange-500",
    red: "text-red-500",
    yellow: "text-yellow-500",
    pink: "text-pink-500",
    purple: "text-purple-500",
  },

  // Background gradients
  background: {
    dark: {
      primary: "from-gray-900 via-purple-900 to-pink-400",
      secondary: "from-slate-900 via-purple-900 to-pink-900",
    },
    light: {
      primary: "from-orange-200 via-red-200 to-yellow-200",
      secondary: "from-pink-200 via-purple-200 to-orange-200",
    },
  },

  // UI element colors
  ui: {
    dark: {
      surface: "bg-gray-900/80",
      border: "border-gray-700/50",
      hover: "hover:bg-gray-800/50",
      text: {
        primary: "text-white",
        secondary: "text-gray-300",
        muted: "text-gray-400",
      },
    },
    light: {
      surface: "bg-white/80",
      border: "border-white/50",
      hover: "hover:bg-white/50",
      text: {
        primary: "text-gray-900",
        secondary: "text-gray-700",
        muted: "text-gray-500",
      },
    },
  },

  // Message colors
  messages: {
    user: {
      dark: "bg-gradient-to-r from-orange-600 to-red-600",
      light: "bg-gradient-to-r from-orange-500 to-red-500",
    },
    ai: {
      dark: "bg-gray-800/80",
      light: "bg-white/80",
    },
  },

  // Button states
  buttons: {
    primary: {
      enabled: "bg-gradient-to-r from-orange-500 via-red-500 to-yellow-500",
      hover: "hover:from-orange-600 hover:via-red-600 hover:to-yellow-600",
      disabled: {
        dark: "bg-gray-700",
        light: "bg-gray-200",
      },
    },
    secondary: {
      enabled: "bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500",
      hover: "hover:from-pink-600 hover:via-purple-600 hover:to-orange-600",
    },
  },
};

// Helper function to get theme colors
export const getThemeColors = (isDark: boolean) => ({
  background: isDark
    ? themeColors.background.dark.primary
    : themeColors.background.light.primary,
  surface: isDark ? themeColors.ui.dark.surface : themeColors.ui.light.surface,
  border: isDark ? themeColors.ui.dark.border : themeColors.ui.light.border,
  hover: isDark ? themeColors.ui.dark.hover : themeColors.ui.light.hover,
  text: {
    primary: isDark
      ? themeColors.ui.dark.text.primary
      : themeColors.ui.light.text.primary,
    secondary: isDark
      ? themeColors.ui.dark.text.secondary
      : themeColors.ui.light.text.secondary,
    muted: isDark
      ? themeColors.ui.dark.text.muted
      : themeColors.ui.light.text.muted,
  },
  messages: {
    user: isDark
      ? themeColors.messages.user.dark
      : themeColors.messages.user.light,
    ai: isDark ? themeColors.messages.ai.dark : themeColors.messages.ai.light,
  },
  buttons: {
    primary: {
      enabled: themeColors.buttons.primary.enabled,
      hover: themeColors.buttons.primary.hover,
      disabled: isDark
        ? themeColors.buttons.primary.disabled.dark
        : themeColors.buttons.primary.disabled.light,
    },
  },
});
