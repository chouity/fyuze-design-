export interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  influencer_found?: Influencer[];
}

export interface Influencer {
  username: string;
  url: string;
  biography: string;
  fullName?: string;
  followersCount?: number;
  profilePicUrl: string;
  avatar_url?: string; // Database field for avatar URL
  originalPlatformData?: any; // Store original platform data (TikTok/Instagram format)
  platform?: string; // Platform identifier
}

export interface LoadingMessageProps {
  message: string;
  isDark: boolean;
}

export interface ChatMessage extends Message {
  // Additional chat-specific properties can be added here
}

export interface SuggestionButtonProps {
  suggestion: string;
  onClick: (suggestion: string) => void;
  isDark: boolean;
}
