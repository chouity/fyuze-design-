export const loading_messages = {
  zero: [],
  first: [
    "Warming up the search engines 🚀",
    "Polishing the data goggles 👓",
    "Aligning AI antennas 📡",
    "Getting things ready behind the curtains 🎭",
    "Cracking the agent’s neurons 🧠",
  ],
  second: [
    "Casting the digital net 🎣",
    "Scanning the influencer universe ✨",
    "Looking under hashtags and hidden corners 🔍",
    "Checking every feed twice 📲",
  ],
  third: [
    "Collecting stories, likes, and hashtags 🗂️",
    "Knocking on influencers’ digital doors 🚪",
    "Gathering followers, bios, and vibes 🌐",
    "Scrolling faster than humanly possible ⚡",
    "Filling the basket with raw social data 🧺",
  ],
  fourth: [
    "Crunching numbers and spotting patterns 📊",
    "AI whispering to the data 🧠",
    "Sorting the hype from the noise 🔎",
    "Translating followers into real influence 🪄",
    "Cooking up insights in the AI kitchen 🍳",
  ],
  fifth: [
    "Still stirring the data soup... hang tight 🍲",
    "This influencer galaxy is bigger than expected 🌌",
    "Our AI is double-checking the results 🔁",
    "Patience—good insights take time ⏳",
    "Heavy lifting in progress, results almost there 🏋️",
  ],
};
