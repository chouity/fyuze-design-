/**
 * PLATFORM ABSTRACTION TYPES
 *
 * Core types for the platform abstraction layer that enables
 * dynamic handling of different social media platforms.
 *
 * @author Fyuze Team
 * @version 1.0.0
 */

import type { PlatformType } from "../config/platforms";

// Re-export PlatformType for convenience
export type { PlatformType } from "../config/platforms";

// ===== CORE PLATFORM INTERFACES =====

export interface PlatformPost {
  id: string;
  caption: string;
  thumbnail: string;
  url?: string;
  likes: number;
  comments: number;
  shares?: number;
  views?: number;
  createdAt: string;
  type: "image" | "video" | "carousel";
  platform: PlatformType;
}

export interface PlatformCreatorProfile {
  // Core identity
  id: string;
  username: string;
  displayName: string;
  platform: PlatformType;

  // Profile data
  bio: string;
  avatarUrl: string;
  isVerified: boolean;

  // Social metrics
  followers: number;
  following: number;
  postsCount: number;
  engagementRate: number;

  // Contact & links
  contactEmail?: string;
  externalLinks: string[];
  location?: string;
  category?: string;

  // Posts
  posts: PlatformPost[];

  // Platform-specific data (raw)
  platformSpecific: Record<string, any>;

  // Metadata
  dataSource: "database" | "endpoint" | "ai_search";
  lastUpdated: string;
}

export interface PlatformAdapter {
  platform: PlatformType;
  extractProfile(rawData: any, dataSource: string): PlatformCreatorProfile;
  extractPosts(rawData: any): PlatformPost[];
  normalizeEngagementRate(rate: any): number;
  validateData(data: any): boolean;
}

// ===== DATA SOURCE TYPES =====

export interface DatabaseResponse {
  data: {
    rows: Array<{
      id: string;
      platform: PlatformType;
      platform_data: string | object;
      [key: string]: any;
    }>;
  };
  status: string;
  message: string;
}

export interface EndpointResponse {
  [key: string]: any;
  engagementRate?: number;
  followers?: number;
  posts?: any;
}

export interface AISearchResponse {
  [key: string]: any;
  platform: PlatformType;
  engagementRate?: number;
  engagement_rate?: number;
}

// ===== UTILITY TYPES =====

export type DataSourceType = "database" | "endpoint" | "ai_search";

export interface PlatformDataExtractionResult {
  profile: PlatformCreatorProfile;
  success: boolean;
  errors: string[];
}

export interface PlatformCompatibilityCheck {
  platform: PlatformType;
  supported: boolean;
  version: string;
  capabilities: string[];
}
