export interface Creator {
  id?: string;
  name: string;
  full_name?: string;
  username: string;
  platform: string;
  followers?: number;
  following?: number;
  bio?: string;
  avatar_url?: string;
  profile_pic_url?: string;
  url?: string;
  location?: string;
  verified?: boolean;
  is_verified?: boolean;
  engagement_rate?: string;
  contact_email?: string;
  category?: string;
  links?: string[];
  posts?: {
    count: number;
    edges: any[];
  };
  audience_demographics?: {
    quality_audience: number;
    followers_growth: number;
    authentic_engagement: number;
    post_frequency: string;
  };
  content_categories?: string[];
  platform_data?: string | any; // Can be string (JSON) or parsed object
  profileData?: any; // Platform-specific profile data object
  dataSource?: string; // Source of the data (e.g., 'ai_search', 'get_creators')
}

export interface PlatformInfo {
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgColor: string;
  borderColor: string;
  name: string;
}
