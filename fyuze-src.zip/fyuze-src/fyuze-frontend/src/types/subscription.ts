export interface SubscriptionPlan {
  id: string;
  code: string;
  name: string;
  price: number;
  currency: string;
  features: Record<string, any>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  description: string;
  billing_cycle: string;
  monthly_points: number;
  duration_months: number;
}

export interface SubscriptionPlansResponse {
  data: SubscriptionPlan[];
  status?: string;
  message?: string;
}

export interface CurrentSubscription {
  end_date: string;
  plan_name: string;
  created_at: string;
  updated_at: string;
}

export interface CurrentSubscriptionResponse {
  status: string;
  subscription: CurrentSubscription | null;
}

export interface ChooseSubscriptionResponse {
  data: {
    plan_id: string;
    end_date: string;
    allocated_points: number;
    old_balance_deducted: number;
  };
  status: string;
  message: string;
}
