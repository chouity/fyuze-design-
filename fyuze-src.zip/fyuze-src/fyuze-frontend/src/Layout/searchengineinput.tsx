// put this outside SearchEnginePage
import React from "react";
import { Search } from "lucide-react";

export type SearchFormProps = {
  query: string;
  setQuery: (v: string) => void;
  isCompact?: boolean;
  isDark: boolean;
  isLoading: boolean;
  handleSubmit: (e: React.FormEvent) => void;
  handleKeyPress: (e: React.KeyboardEvent) => void;
  animatedPlaceholder?: string;
};

const SearchForm = React.forwardRef<HTMLTextAreaElement, SearchFormProps>(
  (
    {
      query,
      setQuery,
      isCompact,
      isDark,
      isLoading,
      handleSubmit,
      handleKeyPress,
      animatedPlaceholder = "Search the web...",
    },
    ref
  ) => {
    return (
      <form onSubmit={handleSubmit} className={isCompact ? "w-full" : "w-full"}>
        <div
          className={`relative transition-all duration-300 ${
            isCompact
              ? `rounded-full ${
                  isDark
                    ? "bg-gray-900/80 border border-gray-600/50"
                    : "bg-white/80 border border-gray-300/50"
                } shadow-lg hover:shadow-xl backdrop-blur-xl`
              : `rounded-3xl max-w-4xl mx-auto shadow-2xl backdrop-blur-xl ${
                  isDark
                    ? "bg-gray-900/80 border border-gray-700/50"
                    : "bg-white/90 border border-white/50"
                }`
          }`}
        >
          <div
            className={`relative flex  items-center ${
              isCompact ? "px-6 py-4" : "px-8 py-6"
            }`}
          >
            <Search
              className={`${
                isCompact ? "w-5 h-5" : "w-6 h-6"
              } text-gray-400 mr-4 sm:block hidden   ${
                !isCompact ? "animate-pulse" : ""
              }`}
            />
            {isCompact ? (
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleSubmit(e);
                  }
                }}
                className={`flex-1 bg-transparent border-none outline-none text-lg focus:ring-0 ${
                  isDark
                    ? "bg-gray-900/80 border border-gray-700/50"
                    : "bg-white/90 border border-white/50"
                } `}
                placeholder="Search..."
              />
            ) : (
              <textarea
                ref={ref}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={
                  window.innerWidth >= 640 ? animatedPlaceholder : ""
                }
                className={`flex-1 bg-transparent placeholder-transparent sm:placeholder-gray-500 border-none outline-none resize-none text-xl  transition-all duration-300 focus:ring-0 ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
                rows={1}
                autoComplete="off"
              />
            )}
            <button
              type="submit"
              disabled={!query.trim() || isLoading}
              className={`ml-4 px-6 py-3 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 ${
                query.trim() && !isLoading
                  ? isDark
                    ? "bg-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg"
                    : "bg-red-500  hover:from-red-600 hover:via-orange-600 hover:to-orange-600 text-white shadow-lg"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
            >
              {isLoading ? (
                "Searching..."
              ) : (
                <>
                  <span className="hidden sm:inline">Search</span>
                  <Search className="w-5 h-5 sm:hidden" />
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    );
  }
);

export default SearchForm;
