import React from "react";
import { useTheme } from "../contexts/ThemeContext";
import { useProfileNavigation } from "../hooks/useProfileNavigation";
import InfluencerHeader from "../components/influencerCard/InfluencerHeader";
import InfluencerGrid from "../components/influencerCard/InfluencerGrid";
import type { Influencer } from "../types/chat";

interface InfluencerCardsProps {
  influencers: Influencer[];
  title?: string;
  subtitle?: string;
}

const InfluencerCards: React.FC<InfluencerCardsProps> = ({
  influencers,
  title,
  subtitle,
}) => {
  const { isDark } = useTheme();
  const { handleViewProfileInNewTab } = useProfileNavigation();

  if (!influencers || influencers.length === 0) {
    return null;
  }

  return (
    <div className="mt-6 space-y-4">
      <InfluencerHeader
        count={influencers.length}
        isDark={isDark}
        title={title}
        subtitle={subtitle}
      />

      <InfluencerGrid
        influencers={influencers}
        isDark={isDark}
        onViewProfile={handleViewProfileInNewTab}
      />
    </div>
  );
};

export default InfluencerCards;
