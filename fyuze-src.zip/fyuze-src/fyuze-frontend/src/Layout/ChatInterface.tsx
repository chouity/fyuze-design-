import React, { useState, useRef, useEffect } from "react";
import { useTheme } from "../contexts/ThemeContext";
import { useAuth } from "../contexts/AuthContext";
import { useChat } from "../hooks/useChat";
import type { Message } from "../hooks/useChat";
import { useChatInput, useMessageActions } from "../hooks";
import InfluencerCards from "./InfluencerCards";
import ChatBackground from "../components/chatInterface/ChatBackground";
import {
  LoadingMessage,
  SuggestionButtons,
  MessageAvatar,
  MessageActions,
  EditableMessage,
  MessageContent,
  ChatInputArea,
} from "../components";
import {
  formatTime,
  getRandomMessage,
  getLoadingSection,
  scrollToBottom,
} from "../utils/chatUtils";
import { loading_messages } from "../types/loadingMessages";
import "highlight.js/styles/github.css";

type ChatInterfaceProps = {
  onToggleSidebar?: () => void;
};

const ChatInterface: React.FC<ChatInterfaceProps> = () => {
  const { isDark } = useTheme();
  const { user } = useAuth();
  const { messages, isLoading, sendMessage } = useChat();
  const [isMobile, setIsMobile] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState("");
  const [loadingStartTime, setLoadingStartTime] = useState<number | null>(null);
  const [currentSection, setCurrentSection] = useState("");

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const {
    input,
    setInput,
    textareaRef,
    animatedPlaceholder,
    handleSubmit: handleInputSubmit,
    handleKeyPress,
    handleSuggestionClick,
  } = useChatInput({
    onSubmit: sendMessage,
    isLoading,
    messages,
    isMobile,
  });

  const {
    editingMessageId,
    editText,
    setEditText,
    copiedMessageId,
    handleCopyMessage,
    handleEditMessage,
    handleCancelEdit,
    handleSubmitEdit,
  } = useMessageActions();

  const suggestions = [
    "Find top 10 Instagram food influencers in Dubai",
    "Help me with crypto launch campaign on X",
    "Find fashion micro influencers who speak French",
  ];

  useEffect(() => {
    scrollToBottom(messagesEndRef.current);
  }, [messages]);

  // Mobile detection
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Loading message management
  useEffect(() => {
    if (isLoading && !loadingStartTime) {
      setLoadingStartTime(Date.now());
      setLoadingMessage(getRandomMessage(loading_messages.zero));
      setCurrentSection("zero");
    } else if (!isLoading) {
      setLoadingStartTime(null);
      setLoadingMessage("");
      setCurrentSection("");
    }
  }, [isLoading, loadingStartTime]);

  // Update loading message only when section changes
  useEffect(() => {
    if (!isLoading || !loadingStartTime) return;

    let lastSection = currentSection;
    const interval = setInterval(() => {
      const elapsed = (Date.now() - loadingStartTime) / 1000;
      const section = getLoadingSection(elapsed);
      if (section !== lastSection) {
        setCurrentSection(section);
        setLoadingMessage(getRandomMessage(loading_messages[section]));
        lastSection = section;
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isLoading, loadingStartTime, currentSection]);

  return (
    <div
      className={`relative flex flex-col w-full h-full transition-all duration-500 overflow-hidden ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      <ChatBackground isDark={isDark} />

      {/* Messages Area */}
      <div
        className={`px-4 relative z-10 transition-all duration-1000 ease-out pt-8 md:pt-22 ${
          messages.length === 0
            ? "flex-1 flex items-center justify-center min-h-0"
            : "flex-1 overflow-y-auto min-h-0"
        }`}
      >
        {messages.length === 0 ? (
          <div className="text-center max-w-2xl mx-auto p-0 sm:p-8 sm:mb-40 transform transition-all duration-1000 ease-out opacity-100 translate-y-0">
            <h2
              className={`text-4xl font-bold bg-gradient-to-r bg-clip-text text-transparent mb-4 pb-2 transform transition-all duration-1000 ease-out ${
                isDark
                  ? "text-white"
                  : "from-pink-500 via-purple-500 to-orange-500"
              }`}
            >
              The Future of Influence
            </h2>
            <p
              className={`text-lg mb-8 leading-relaxed transform transition-all duration-1200 ease-out ${
                isDark ? "text-gray-300" : "text-gray-600"
              }`}
            >
              The biggest and most advanced Ai-powered influancer marketing
              platform on earth
            </p>

            <SuggestionButtons
              suggestions={suggestions}
              onSuggestionClick={handleSuggestionClick}
              isDark={isDark}
            />
          </div>
        ) : (
          <div className="max-w-4xl mx-auto space-y-6 transform transition-all duration-1000 ease-out opacity-100 translate-y-0">
            {messages.map((message: Message) => (
              <div
                key={message.id}
                className={`flex items-start space-x-4 transform transition-all duration-800 ease-out opacity-100 translate-y-0 ${
                  message.isUser ? "flex-row-reverse space-x-reverse" : ""
                }`}
              >
                {/* Avatar */}
                <div className="flex-shrink-0 w-10 h-10 rounded-full  items-center justify-center hidden sm:flex">
                  <MessageAvatar
                    isUser={message.isUser}
                    userName={user?.name}
                    userEmail={user?.email}
                  />
                </div>

                {/* Message */}
                <div
                  className={`flex-1 max-w-3xl ${
                    message.isUser ? "text-right" : ""
                  }`}
                >
                  {/* Text message */}
                  {editingMessageId === String(message.id) ? (
                    <EditableMessage
                      editText={editText}
                      setEditText={setEditText}
                      onSubmitEdit={() =>
                        handleSubmitEdit(
                          String(message.id),
                          () => {}, // Empty function since clearChat is not available
                          sendMessage
                        )
                      }
                      onCancelEdit={handleCancelEdit}
                      isUser={message.isUser}
                      isDark={isDark}
                    />
                  ) : (
                    <MessageContent
                      text={message.text}
                      isUser={message.isUser}
                      isDark={isDark}
                    />
                  )}

                  {/* Influencer cards - separate from text message */}
                  {!message.isUser &&
                    message.influencer_found &&
                    message.influencer_found.length > 0 && (
                      <InfluencerCards influencers={message.influencer_found} />
                    )}

                  <div
                    className={`text-xs mt-2 flex items-center justify-between ${
                      isDark ? "text-gray-400" : "text-gray-500"
                    }`}
                  >
                    <span>{formatTime(message.timestamp)}</span>
                    <MessageActions
                      messageId={String(message.id)}
                      messageText={message.text}
                      isUser={message.isUser}
                      isDark={isDark}
                      copiedMessageId={copiedMessageId}
                      onCopy={handleCopyMessage}
                      onEdit={handleEditMessage}
                    />
                  </div>
                </div>
              </div>
            ))}

            {/* Loading indicator */}
            {isLoading && (
              <div className="flex items-start space-x-4 animate-slideInUp">
                <div className="flex-shrink-0 w-10 h-10 rounded-full  sm:flex items-center justify-center animate-pulse ">
                  <img
                    src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
                    className="w-10 h-10 text-white"
                    style={{ animationDuration: "3s" }}
                    alt="Loading"
                  />
                </div>
                <div className="flex-1 max-w-3xl">
                  <div
                    className={`inline-block p-4 rounded-2xl shadow-lg transition-all duration-500 transform hover:scale-105 ${
                      isDark
                        ? "bg-gray-800/90 backdrop-blur-xl border border-gray-600/50 shadow-purple-500/20"
                        : "bg-white/90 backdrop-blur-xl border border-white/60 shadow-gray-300/30"
                    }`}
                  >
                    <div className="flex flex-col space-y-3">
                      <div className="flex items-center space-x-3">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                          <div
                            className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"
                            style={{ animationDelay: "0.1s" }}
                          ></div>
                          <div
                            className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce"
                            style={{ animationDelay: "0.2s" }}
                          ></div>
                        </div>
                        <span
                          className={`text-xs font-medium ${
                            isDark ? "text-purple-400" : "text-purple-600"
                          }`}
                        >
                          AI is thinking...
                        </span>
                      </div>
                      <LoadingMessage
                        message={loadingMessage}
                        isDark={isDark}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input Area */}
      <div
        className={`w-full flex justify-center items-center px-4 py-4 relative z-10 flex-shrink-0 ${
          messages.length === 0 ? "pb-8" : "pb-6"
        }`}
      >
        <div
          className={`transform transition-all duration-1000 ease-out ${
            messages.length === 0 ? "scale-100" : "md:scale-95 scale-90"
          }`}
          style={{
            maxWidth: messages.length === 0 ? "720px" : "900px",
            width: "100%",
          }}
        >
          <ChatInputArea
            input={input}
            setInput={setInput}
            textareaRef={textareaRef}
            animatedPlaceholder={animatedPlaceholder}
            handleSubmit={handleInputSubmit}
            handleKeyPress={handleKeyPress}
            isLoading={isLoading}
            isDark={isDark}
            messagesExist={messages.length > 0}
          />
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
