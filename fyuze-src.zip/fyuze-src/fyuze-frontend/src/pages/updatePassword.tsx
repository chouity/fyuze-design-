import { Lock, Eye, EyeOff, CheckCircle } from "lucide-react";
import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

const UpdatePassword = () => {
  const { updateUserPassword } = useAuth();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const validatePassword = (pwd: string) => {
    const minLength = pwd.length >= 8;
    const hasUpperCase = /[A-Z]/.test(pwd);
    const hasLowerCase = /[a-z]/.test(pwd);
    const hasNumbers = /\d/.test(pwd);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);

    return {
      minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumbers,
      hasSpecialChar,
      isValid:
        minLength &&
        hasUpperCase &&
        hasLowerCase &&
        hasNumbers &&
        hasSpecialChar,
    };
  };

  const passwordValidation = validatePassword(password);
  const passwordsMatch = password === confirmPassword && confirmPassword !== "";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!passwordValidation.isValid) {
      setError("Please ensure your password meets all requirements.");
      return;
    }

    if (!passwordsMatch) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);
    setMessage("");
    setError("");

    try {
      const { error } = await updateUserPassword(password);
      if (error) {
        setError(error.message);
      } else {
        setMessage("Password updated successfully! Redirecting...");
        navigate("/"); // Redirect to home or dashboard immediately
      }
    } catch (err) {
      setError("Failed to update password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSubmit(e as any);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-yellow-50 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-20 -right-20 w-96 h-96 bg-gradient-to-br from-pink-400/20 to-orange-400/20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-gradient-to-tr from-purple-400/20 to-pink-400/20 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-orange-400/10 to-yellow-400/10 rounded-full blur-2xl"></div>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Update Password Form */}
        <div className="bg-white/80 backdrop-blur-xl border border-white/50 rounded-3xl shadow-2xl p-8 transition-all duration-500 transform hover:scale-[1.02]">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0  rounded-2xl  opacity-75 animate-pulse"></div>
                <div className="relative p-4  rounded-2xl">
                  <img
                    src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
                    alt="Fyuze Logo"
                    className="w-15 h-15"
                  />
                </div>
              </div>
            </div>
            <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500 bg-clip-text text-transparent">
              Update Password
            </h1>
            <p className="text-gray-600 text-lg">
              Enter your new password below
            </p>
          </div>

          <div className="space-y-6">
            {/* New Password */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-gray-700">
                New Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="w-full pl-12 pr-12 py-4 rounded-xl bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-purple-500 focus:bg-white/70 focus:ring-4 focus:ring-purple-500/20 backdrop-blur-sm transition-all duration-300 focus:scale-[1.02]"
                  placeholder="Enter new password"
                  disabled={loading}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors duration-200"
                  disabled={loading}
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>

              {/* Password Requirements */}
              {password && (
                <div className="mt-3 space-y-2 p-4 bg-gray-50/50 rounded-xl backdrop-blur-sm">
                  <div className="text-xs text-gray-600 mb-2 font-semibold">
                    Password requirements:
                  </div>
                  <div className="grid grid-cols-1 gap-1">
                    <div
                      className={`flex items-center gap-2 text-xs ${
                        passwordValidation.minLength
                          ? "text-green-600"
                          : "text-gray-500"
                      }`}
                    >
                      <CheckCircle
                        className={`w-3 h-3 ${
                          passwordValidation.minLength
                            ? "text-green-600"
                            : "text-gray-300"
                        }`}
                      />
                      At least 8 characters
                    </div>
                    <div
                      className={`flex items-center gap-2 text-xs ${
                        passwordValidation.hasUpperCase
                          ? "text-green-600"
                          : "text-gray-500"
                      }`}
                    >
                      <CheckCircle
                        className={`w-3 h-3 ${
                          passwordValidation.hasUpperCase
                            ? "text-green-600"
                            : "text-gray-300"
                        }`}
                      />
                      One uppercase letter
                    </div>
                    <div
                      className={`flex items-center gap-2 text-xs ${
                        passwordValidation.hasLowerCase
                          ? "text-green-600"
                          : "text-gray-500"
                      }`}
                    >
                      <CheckCircle
                        className={`w-3 h-3 ${
                          passwordValidation.hasLowerCase
                            ? "text-green-600"
                            : "text-gray-300"
                        }`}
                      />
                      One lowercase letter
                    </div>
                    <div
                      className={`flex items-center gap-2 text-xs ${
                        passwordValidation.hasNumbers
                          ? "text-green-600"
                          : "text-gray-500"
                      }`}
                    >
                      <CheckCircle
                        className={`w-3 h-3 ${
                          passwordValidation.hasNumbers
                            ? "text-green-600"
                            : "text-gray-300"
                        }`}
                      />
                      One number
                    </div>
                    <div
                      className={`flex items-center gap-2 text-xs ${
                        passwordValidation.hasSpecialChar
                          ? "text-green-600"
                          : "text-gray-500"
                      }`}
                    >
                      <CheckCircle
                        className={`w-3 h-3 ${
                          passwordValidation.hasSpecialChar
                            ? "text-green-600"
                            : "text-gray-300"
                        }`}
                      />
                      One special character
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-gray-700">
                Confirm Password
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="w-full pl-12 pr-12 py-4 rounded-xl bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70 focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm transition-all duration-300 focus:scale-[1.02]"
                  placeholder="Confirm new password"
                  disabled={loading}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-colors duration-200"
                  disabled={loading}
                >
                  {showConfirmPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>

              {/* Password Match Indicator */}
              {confirmPassword && (
                <div
                  className={`mt-2 text-xs font-semibold ${
                    passwordsMatch ? "text-green-600" : "text-red-500"
                  }`}
                >
                  {passwordsMatch
                    ? "✓ Passwords match"
                    : "✗ Passwords do not match"}
                </div>
              )}
            </div>

            {/* Messages */}
            {message && (
              <div className="text-green-600 text-sm text-center bg-green-500/10 border border-green-500/20 p-4 rounded-xl backdrop-blur-sm">
                {message}
              </div>
            )}

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 p-4 rounded-xl backdrop-blur-sm">
                {error}
              </div>
            )}

            {/* Submit Button */}
            <button
              onClick={handleSubmit}
              disabled={
                loading || !passwordValidation.isValid || !passwordsMatch
              }
              className="w-full py-4 px-6 rounded-xl font-bold text-white transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed focus:ring-4 focus:ring-purple-500/50 relative overflow-hidden group bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500 hover:from-pink-600 hover:via-purple-600 hover:to-orange-600 shadow-xl hover:shadow-2xl"
            >
              <span className="relative z-10">
                {loading ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Updating...</span>
                  </div>
                ) : (
                  "Update Password"
                )}
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-pink-600 via-purple-600 to-orange-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
          </div>

          <div className="mt-8 text-center">
            <Link
              to="/"
              className="text-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500 bg-clip-text font-semibold hover:from-pink-600 hover:via-purple-600 hover:to-orange-600 transition-all duration-300 transform hover:scale-105 inline-block"
            >
              Back to Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdatePassword;
