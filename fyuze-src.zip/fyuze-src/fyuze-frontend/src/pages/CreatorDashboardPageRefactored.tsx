/**
 * CREATOR DASHBOARD PAGE - PLATFORM AGNOSTIC
 *
 * Refactored to use the platform abstraction layer for dynamic
 * handling of different social media platforms and clean component architecture.
 *
 * @author Fyuze Team
 * @version 2.0.0
 */

import { useState, useMemo, useCallback } from "react";
import { useTheme } from "../contexts/ThemeContext";
import { platformService } from "../services/PlatformService";
import { parseFollowersInput } from "../utils/numberUtils";
import { useCreators, useDebounce, useCreatorsParsing } from "../hooks";
import { useAICreatorSearch } from "../hooks/useAICreatorSearch";

// Components
import ChatBackground from "../components/chatInterface/ChatBackground";
import {
  DashboardHeader,
  AISearchModal,
  DashboardFilters,
  DashboardResults,
} from "../components/dashboard";

// Types
import type { PlatformCreatorProfile } from "../types/platform.types";

export interface GetCreatorsParams {
  search?: string;
  platform?: string;
  category?: string;
  location?: string;
  verified?: boolean;
  followers_min?: number;
  followers_max?: number;
  engagement_rate_min?: number;
  engagement_rate_max?: number;
  limit?: number;
  offset?: number;
}

interface FilterState {
  search: string;
  platform: string;
  category: string;
  location: string;
  verified: boolean | null;
  followers_min: string;
  followers_max: string;
  engagement_rate_min: string;
  engagement_rate_max: string;
  audience_gender: string;
  audience_age_min: string;
  audience_age_max: string;
}

interface AISearchState {
  isOpen: boolean;
  topic: string;
  keywords: string;
  platform: string;
  location?: string;
  search_results: number;
}

const CreatorsDashboardRefactored = () => {
  // Theme hook
  const { isDark } = useTheme();

  // Dynamic creators parsing hook
  const { parseCreatorData } = useCreatorsParsing();

  // View toggle state
  const [viewMode, setViewMode] = useState<"table" | "cards">("table");

  // AI Search hook - toggle useMockData for development/production
  const [useMockData] = useState(false);
  const aiSearchHook = useAICreatorSearch({ useMockData });

  // AI Search state
  const [aiSearch, setAiSearch] = useState<AISearchState>({
    isOpen: false,
    topic: "",
    keywords: "",
    platform: "",
    location: "",
    search_results: 10,
  });

  // State to track if we're showing AI search results or regular results
  const [showingAIResults, setShowingAIResults] = useState(false);

  // UI states
  const [filters, setFilters] = useState<FilterState>({
    search: "",
    platform: "",
    category: "",
    location: "",
    verified: null,
    followers_min: "",
    followers_max: "",
    engagement_rate_min: "",
    engagement_rate_max: "",
    audience_gender: "any",
    audience_age_min: "18",
    audience_age_max: "65",
  });

  const [currentPage, setCurrentPage] = useState(1);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [resultsPerPage, setResultsPerPage] = useState(10);

  // Debounce search term
  const debouncedSearch = useDebounce(filters.search, 500);

  // Format number helper
  const formatNumber = useCallback((num: number | undefined | null) => {
    if (num == null || num === undefined) return "0";
    const numValue = Number(num);
    if (isNaN(numValue)) return "0";
    if (numValue >= 1000000) return (numValue / 1000000).toFixed(1) + "M";
    if (numValue >= 1000) return (numValue / 1000).toFixed(1) + "K";
    return numValue.toString();
  }, []);

  // Build query parameters
  const queryParams = useMemo(() => {
    const params: GetCreatorsParams = {
      limit: currentPage * resultsPerPage,
      offset: (currentPage - 1) * resultsPerPage,
    };

    if (debouncedSearch.trim()) params.search = debouncedSearch.trim();
    if (filters.platform) params.platform = filters.platform;
    if (filters.category) params.category = filters.category;
    if (filters.location) params.location = filters.location;
    if (filters.verified !== null) params.verified = filters.verified;
    if (filters.followers_min)
      params.followers_min = parseFollowersInput(filters.followers_min);
    if (filters.followers_max)
      params.followers_max = parseFollowersInput(filters.followers_max);
    if (filters.engagement_rate_min)
      params.engagement_rate_min = parseFloat(filters.engagement_rate_min);
    if (filters.engagement_rate_max)
      params.engagement_rate_max = parseFloat(filters.engagement_rate_max);

    return params;
  }, [
    debouncedSearch,
    filters.platform,
    filters.category,
    filters.location,
    filters.verified,
    filters.followers_min,
    filters.followers_max,
    filters.engagement_rate_min,
    filters.engagement_rate_max,
    currentPage,
    resultsPerPage,
  ]);

  // Use React Query to fetch creators
  const {
    data: creatorsData,
    isLoading: loading,
    error,
  } = useCreators(queryParams);

  // Extract raw creators data from both sources
  const rawCreators = useMemo(() => {
    if (showingAIResults) {
      return aiSearchHook.data?.showcaseData || [];
    }
    if (creatorsData?.status === "success") {
      return creatorsData.data?.rows || [];
    }
    return [];
  }, [creatorsData, showingAIResults, aiSearchHook.data?.showcaseData]);

  // Normalize creators data using the platform abstraction layer
  const creators = useMemo((): PlatformCreatorProfile[] => {
    if (rawCreators.length === 0) {
      return [];
    }

    try {
      if (showingAIResults) {
        // For AI search, process each creator with platform abstraction
        const processed = rawCreators
          .map((creator: any) => {
            const platform = platformService.detectPlatform(creator);
            if (!platform) return null;
            const result = platformService.extractCreatorProfile(
              creator,
              platform,
              "ai_search"
            );
            return result.success ? result.profile : null;
          })
          .filter(Boolean) as PlatformCreatorProfile[];

        return processed;
      } else {
        // For regular search, use parseCreatorData and then enhance with platform abstraction
        const parsedCreators = parseCreatorData(
          { data: { rows: rawCreators } },
          "get_creators"
        );

        // Convert to platform abstraction format
        const processedCreators = parsedCreators
          .map((creator: any) => {
            const platform = platformService.detectPlatform(creator);
            if (!platform) return null;
            const result = platformService.extractCreatorProfile(
              creator,
              platform,
              "database"
            );
            return result.success ? result.profile : null;
          })
          .filter(Boolean) as PlatformCreatorProfile[];

        return processedCreators;
      }
    } catch (error) {
      // ...existing code...
      return [];
    }
  }, [rawCreators, showingAIResults, parseCreatorData]);

  const totalResults = useMemo(() => {
    if (showingAIResults) {
      return aiSearchHook.data?.showcaseData?.length || 0;
    }
    if (creatorsData?.status === "success") {
      const total =
        creatorsData.data?.total || creatorsData.data?.count || creators.length;
      return total;
    }
    return 0;
  }, [
    creatorsData,
    creators.length,
    showingAIResults,
    aiSearchHook.data?.showcaseData?.length,
  ]);

  // Event handlers
  const handleFilterChange = useCallback((key: string, value: any) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  }, []);

  const handleToggleAdvancedFilters = useCallback(() => {
    setShowAdvancedFilters((prev) => !prev);
  }, []);

  const handleResultsPerPageChange = useCallback(
    (newResultsPerPage: number) => {
      setResultsPerPage(newResultsPerPage);
      setCurrentPage(1);
    },
    []
  );

  const clearFilters = useCallback(() => {
    setFilters({
      search: "",
      platform: "",
      category: "",
      location: "",
      verified: null,
      followers_min: "",
      followers_max: "",
      engagement_rate_min: "",
      engagement_rate_max: "",
      audience_gender: "any",
      audience_age_min: "18",
      audience_age_max: "65",
    });
    setCurrentPage(1);
  }, []);

  const resetToRegularResults = useCallback(() => {
    setShowingAIResults(false);
    setAiSearch((prev) => ({ ...prev, isOpen: false }));
  }, []);

  const handleAISearch = useCallback(async () => {
    try {
      await aiSearchHook.searchCreators(
        aiSearch.topic,
        "", // location - not using location filter in current implementation
        aiSearch.platform,
        aiSearch.search_results,
        aiSearch.keywords
          ? aiSearch.keywords.split(",").map((k) => k.trim())
          : []
      );

      setShowingAIResults(true);
      setAiSearch((prev) => ({ ...prev, isOpen: false }));
      setCurrentPage(1);
    } catch (error) {
      // ...existing code...
    }
  }, [aiSearch, aiSearchHook]);

  const handleOpenAISearch = useCallback(() => {
    setAiSearch((prev) => ({ ...prev, isOpen: true }));
  }, []);

  const handleUpdateAISearch = useCallback(
    (updates: Partial<AISearchState>) => {
      setAiSearch((prev) => ({ ...prev, ...updates }));
    },
    []
  );

  // Convert React Query error to string
  const errorMessage = error
    ? error instanceof Error
      ? error.message
      : "An error occurred while fetching creators"
    : null;

  return (
    <div
      className={`p-4 md:p-6 min-h-screen overflow-x-hidden ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      <ChatBackground isDark={isDark} />

      <div className="max-w-7xl mx-auto w-full space-y-6">
        {/* Header */}
        <DashboardHeader
          showingAIResults={showingAIResults}
          aiTopic={aiSearch.topic}
          aiPlatform={aiSearch.platform}
          useMockData={useMockData}
          onOpenAISearch={handleOpenAISearch}
          onClearAIResults={resetToRegularResults}
        />

        {/* Filters */}
        <DashboardFilters
          filters={filters}
          showAdvancedFilters={showAdvancedFilters}
          onFilterChange={handleFilterChange}
          onToggleAdvanced={handleToggleAdvancedFilters}
          onClearFilters={clearFilters}
        />

        {/* Results */}
        <DashboardResults
          creators={creators}
          loading={loading}
          error={errorMessage}
          totalResults={totalResults}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          currentPage={currentPage}
          resultsPerPage={resultsPerPage}
          onPageChange={setCurrentPage}
          onResultsPerPageChange={handleResultsPerPageChange}
          dataSource={showingAIResults ? "ai_search" : "regular"}
          formatNumber={formatNumber}
        />

        {/* AI Search Modal */}
        <AISearchModal
          aiSearch={aiSearch}
          onUpdateAISearch={handleUpdateAISearch}
          onSearch={handleAISearch}
          isLoading={aiSearchHook.isLoading}
        />
      </div>
    </div>
  );
};

export default CreatorsDashboardRefactored;
