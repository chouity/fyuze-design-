import React, { useState } from "react";
import { useTheme } from "../contexts/ThemeContext";
import {
  useAdminEmails,
  EmailDetailsPopup,
  type EmailData,
} from "../components/admin";
import {
  useNotificationPopup,
  type NotificationButton,
} from "../components/common/NotificationPopup";
const StatsCards = React.lazy(() =>
  import("../components/admin/StatsCards").then((module) => ({
    default: module.StatsCards,
  }))
);
const SearchAndFilters = React.lazy(() =>
  import("../components/admin/SearchAndFilters").then((module) => ({
    default: module.SearchAndFilters,
  }))
);
const EmailList = React.lazy(() =>
  import("../components/admin/EmailList").then((module) => ({
    default: module.EmailList,
  }))
);
const EmailDetails = React.lazy(() =>
  import("../components/admin/EmailDetails").then((module) => ({
    default: module.EmailDetails,
  }))
);

const AdminDashboardPage: React.FC = () => {
  const { isDark } = useTheme();
  const [isMobilePopupOpen, setIsMobilePopupOpen] = useState(false);
  const { showNotification, hideNotification, NotificationPopup } =
    useNotificationPopup();
  const {
    emails,
    selectedEmail,
    isLoading,
    isSearching,
    filters,
    pagination,
    availableStatuses,
    updateFilters,
    clearFilters,
    fetchEmails,
    handlePageChange,
    handleResultsPerPageChange,
    handleEmailSelect,
    handleStatusChange,
    handleEmailDelete,
    handleDragStart,
    handleDragOver,
    handleDrop,
  } = useAdminEmails();

  const handleEmailArchive = (emailId: string) => {
    handleStatusChange(emailId, "archived");
  };

  // Enhanced email selection for mobile
  const handleEmailSelectWithPopup = (email: EmailData) => {
    handleEmailSelect(email);
    // Open popup on mobile screens
    if (window.innerWidth < 1024) {
      setIsMobilePopupOpen(true);
    }
  };

  const handleCloseMobilePopup = () => {
    setIsMobilePopupOpen(false);
  };

  const handleArchiveConfirmation = (emailId: string) => {
    const email = emails.find((e) => e.id === emailId);
    if (!email) return;

    const buttons: NotificationButton[] = [
      {
        label: "Cancel",
        onClick: hideNotification,
        variant: "secondary",
      },
      {
        label: "Archive",
        onClick: () => {
          handleEmailArchive(emailId);
          hideNotification();
        },
        variant: "warning",
      },
    ];

    showNotification({
      title: "Archive Message",
      message: `Are you sure you want to archive the message from ${email.first_name} ${email.last_name}? You can find archived messages in the archived filter.`,
      buttons,
      type: "warning",
    });
  };

  const handleDeleteConfirmation = (emailId: string) => {
    const email = emails.find((e) => e.id === emailId);
    if (!email) return;

    const buttons: NotificationButton[] = [
      {
        label: "Cancel",
        onClick: hideNotification,
        variant: "secondary",
      },
      {
        label: "Delete",
        onClick: () => {
          handleEmailDelete(emailId);
          hideNotification();
        },
        variant: "danger",
      },
    ];

    showNotification({
      title: "Delete Message",
      message: `Are you sure you want to delete the message from ${email.first_name} ${email.last_name}? This action cannot be undone.`,
      buttons,
      type: "error",
    });
  };

  return (
    <div
      className={`min-h-screen p-6 ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1
            className={`text-4xl md:text-5xl font-bold mb-4 pb-4 ${
              isDark ? "text-white" : "text-gray-900"
            }`}
          >
            Message Management
          </h1>
          <p
            className={`text-lg md:text-xl ${
              isDark ? "text-gray-400" : "text-gray-600"
            } max-w-2xl mx-auto`}
          >
            Efficiently manage and respond to all incoming contact messages with
            powerful filtering and search capabilities
          </p>
        </div>

        {/* Stats Cards */}
        <StatsCards totalResults={pagination.totalResults} emails={emails} />

        {/* Filters and Search */}
        <SearchAndFilters
          filters={filters}
          onFiltersChange={updateFilters}
          onRefresh={fetchEmails}
          onClearFilters={clearFilters}
          availableStatuses={availableStatuses}
          isLoading={isLoading}
        />

        {/* Main Content */}
        <div className="grid grid-cols-3 lg:grid-cols-4 gap-8 min-w-0 h-[calc(200vh-50rem)]">
          {/* Email List */}
          <div className="lg:col-span-2">
            <EmailList
              emails={emails}
              selectedEmail={selectedEmail}
              isLoading={isLoading}
              isSearching={isSearching}
              totalResults={pagination.totalResults}
              pagination={pagination}
              onEmailSelect={handleEmailSelectWithPopup}
              onEmailArchive={handleArchiveConfirmation}
              onEmailDelete={handleDeleteConfirmation}
              onPageChange={handlePageChange}
              onResultsPerPageChange={handleResultsPerPageChange}
              onDragStart={handleDragStart}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
            />
          </div>

          {/* Email Details - Hidden on mobile, shown on desktop */}
          <div className="hidden lg:block lg:col-span-2">
            <EmailDetails
              selectedEmail={selectedEmail}
              onArchive={handleArchiveConfirmation}
              onDelete={handleDeleteConfirmation}
            />
          </div>
        </div>

        {/* Mobile Popup for Email Details */}
        <EmailDetailsPopup
          selectedEmail={selectedEmail}
          isOpen={isMobilePopupOpen}
          onClose={handleCloseMobilePopup}
          onArchive={handleArchiveConfirmation}
          onDelete={handleDeleteConfirmation}
        />
      </div>

      {/* Notification Popup - renders over entire dashboard */}
      {NotificationPopup}
    </div>
  );
};

export default AdminDashboardPage;
