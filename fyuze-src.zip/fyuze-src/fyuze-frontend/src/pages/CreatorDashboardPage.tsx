import { useState, useMemo, useCallback } from "react";
import {
  useCreators,
  useDebounce,
  useAICreatorSearch,
  useCreatorsParsing,
} from "../hooks";
import { useTheme } from "../contexts/ThemeContext";
import { parseFollowersInput } from "../utils/numberUtils";
import { Sparkles, X } from "lucide-react";
import React from "react";
import { AISearchModal } from "../components/dashboard/AISearchModal";

const ChatBackground = React.lazy(
  () => import("../components/chatInterface/ChatBackground")
);
const CreatorFilters = React.lazy(() =>
  import("../components/creators/CreatorFilters").then((module) => ({
    default: module.CreatorFilters,
  }))
);
const ResultsHeader = React.lazy(() =>
  import("../components/creators/ResultsHeader").then((module) => ({
    default: module.ResultsHeader,
  }))
);
const CreatorResults = React.lazy(() =>
  import("../components/creators/CreatorResults").then((module) => ({
    default: module.CreatorResults,
  }))
);
const Pagination = React.lazy(() =>
  import("../components/creators/Pagination").then((module) => ({
    default: module.Pagination,
  }))
);

export interface GetCreatorsParams {
  search?: string;
  platform?: string;
  category?: string;
  location?: string;
  verified?: boolean;
  followers_min?: number;
  followers_max?: number;
  engagement_rate_min?: number;
  engagement_rate_max?: number;
  limit?: number;
  offset?: number;
}

interface FilterState {
  search: string;
  platform: string;
  category: string;
  location: string;
  verified: boolean | null;
  followers_min: string;
  followers_max: string;
  engagement_rate_min: string;
  engagement_rate_max: string;
  audience_gender: string;
  audience_age_min: string;
  audience_age_max: string;
}

interface AISearchState {
  isOpen: boolean;
  topic: string;
  keywords: string;
  platform: string;
  search_results: number;
  location?: string;
}

const CreatorsDashboard = () => {
  // Theme hook
  const { isDark } = useTheme();

  // Dynamic creators parsing hook
  const { parseCreatorData } = useCreatorsParsing();

  // View toggle state
  const [viewMode, setViewMode] = useState<"table" | "cards">("table");

  const aiSearchHook = useAICreatorSearch();

  // AI Search state
  const [aiSearch, setAiSearch] = useState<AISearchState>({
    isOpen: false,
    topic: "",
    keywords: "",
    platform: "",
    location: "",
    search_results: 10,
  });

  // State to track if we're showing AI search results or regular results
  const [showingAIResults, setShowingAIResults] = useState(false);

  // UI states
  const [filters, setFilters] = useState<FilterState>({
    search: "",
    platform: "",
    category: "",
    location: "",
    verified: null,
    followers_min: "",
    followers_max: "",
    engagement_rate_min: "",
    engagement_rate_max: "",
    audience_gender: "any",
    audience_age_min: "18",
    audience_age_max: "65",
  });

  const [currentPage, setCurrentPage] = useState(1);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [resultsPerPage, setResultsPerPage] = useState(10);

  // Debounce search term
  const debouncedSearch = useDebounce(filters.search, 500);

  // Format number helper
  const formatNumber = (num: number | undefined | null) => {
    if (num == null || num === undefined) return "0";
    const numValue = Number(num);
    if (isNaN(numValue)) return "0";
    if (numValue >= 1000000) return (numValue / 1000000).toFixed(1) + "M";
    if (numValue >= 1000) return (numValue / 1000).toFixed(1) + "K";
    return numValue.toString();
  };

  // Build query parameters
  const queryParams = useMemo(() => {
    const params: GetCreatorsParams = {
      limit: currentPage * resultsPerPage, // Cumulative limit
      offset: (currentPage - 1) * resultsPerPage, // Standard offset calculation
    };

    if (debouncedSearch.trim()) params.search = debouncedSearch.trim();
    if (filters.platform) params.platform = filters.platform;
    if (filters.category) params.category = filters.category;
    if (filters.location) params.location = filters.location;
    if (filters.verified !== null) params.verified = filters.verified;
    if (filters.followers_min)
      params.followers_min = parseFollowersInput(filters.followers_min);
    if (filters.followers_max)
      params.followers_max = parseFollowersInput(filters.followers_max);
    if (filters.engagement_rate_min)
      params.engagement_rate_min = parseFloat(filters.engagement_rate_min);
    if (filters.engagement_rate_max)
      params.engagement_rate_max = parseFloat(filters.engagement_rate_max);

    return params;
  }, [
    debouncedSearch,
    filters.platform,
    filters.category,
    filters.location,
    filters.verified,
    filters.followers_min,
    filters.followers_max,
    filters.engagement_rate_min,
    filters.engagement_rate_max,
    currentPage,
    resultsPerPage,
  ]);

  // Use React Query to fetch creators
  const {
    data: creatorsData,
    isLoading: loading,
    error,
  } = useCreators(queryParams);

  // Extract raw creators data from both sources
  const rawCreators = useMemo(() => {
    if (showingAIResults) {
      return aiSearchHook.data?.showcaseData || [];
    }
    if (creatorsData?.status === "success") {
      return creatorsData.data?.rows || [];
    }
    return [];
  }, [creatorsData, showingAIResults, aiSearchHook.data?.showcaseData]);

  // Normalize creators data using the new unified parser
  const creators = useMemo(() => {
    if (rawCreators.length === 0) {
      return [];
    }

    let parsedCreators = [];

    if (showingAIResults) {
      parsedCreators = parseCreatorData(rawCreators, "ai_search");
    } else {
      const regularData = { data: { rows: rawCreators } };
      parsedCreators = parseCreatorData(regularData, "get_creators");
    }

    return parsedCreators;
  }, [rawCreators, showingAIResults]);

  const totalResults = useMemo(() => {
    if (showingAIResults) {
      return aiSearchHook.data?.showcaseData?.length || 0;
    }
    // If the API provides a total count, use it; otherwise fall back to current page results
    if (creatorsData?.status === "success") {
      const total =
        creatorsData.data?.total || creatorsData.data?.count || creators.length;
      return total;
    }
    return 0;
  }, [
    creatorsData,
    creators.length,
    showingAIResults,
    aiSearchHook.data?.showcaseData?.length,
  ]);

  // AI Search handlers
  const handleAISearch = useCallback(async () => {
    if (!aiSearch.topic.trim() || !aiSearch.platform.trim()) {
      return;
    }

    try {
      const keywordsArray = aiSearch.keywords
        .split(",")
        .map((k) => k.trim())
        .filter((k) => k.length > 0);

      await aiSearchHook.searchTiktokCreators(
        aiSearch.topic,
        aiSearch.location || "",
        aiSearch.platform,
        aiSearch.search_results,
        keywordsArray
      );

      setShowingAIResults(true);
      setAiSearch((prev) => ({ ...prev, isOpen: false }));

      // Reset pagination when showing AI results
      setCurrentPage(1);
    } catch (error) {
      // You might want to show an error message to the user here
    }
  }, [aiSearch, aiSearchHook]);

  const updateAISearch = useCallback((updates: Partial<AISearchState>) => {
    setAiSearch((prev) => ({ ...prev, ...updates }));
  }, []);

  const resetToRegularResults = useCallback(() => {
    setShowingAIResults(false);
    aiSearchHook.reset();
  }, [aiSearchHook]);

  // Filter handlers
  const updateFilter = useCallback((key: string, value: any) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setCurrentPage(1); // Reset to first page when filters change
  }, []);

  const handleResultsPerPageChange = useCallback((perPage: number) => {
    setResultsPerPage(perPage);
    setCurrentPage(1); // Reset to first page when changing results per page
  }, []);

  const clearFilters = useCallback(() => {
    setFilters({
      search: "",
      platform: "",
      category: "",
      location: "",
      verified: null,
      followers_min: "",
      followers_max: "",
      engagement_rate_min: "",
      engagement_rate_max: "",
      audience_gender: "any",
      audience_age_min: "18",
      audience_age_max: "65",
    });
    setCurrentPage(1);
  }, []);

  // Convert React Query error to string
  const errorMessage = error
    ? error instanceof Error
      ? error.message
      : "An error occurred while fetching creators"
    : null;

  return (
    <div
      className={`p-4 md:p-6 min-h-screen overflow-x-hidden ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      <ChatBackground isDark={isDark} />
      <div className="max-w-7xl mx-auto w-full">
        {/* Header */}
        <div className="mb-6 md:mb-8 text-center">
          <h1
            className={`text-2xl md:text-3xl font-bold mb-2  ${
              isDark ? "text-white" : "text-gray-900"
            }`}
          >
            Creator Discovery
          </h1>
          <p
            className={`text-sm md:text-base  ${
              isDark ? "text-gray-300" : "text-gray-600"
            }`}
          >
            Find and connect with creators that match your brand
          </p>

          {/* AI Search Button */}
          <div className="mt-4 flex justify-center gap-4">
            <button
              onClick={() => setAiSearch((prev) => ({ ...prev, isOpen: true }))}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg ${
                isDark
                  ? "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                  : "bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
              }`}
            >
              <Sparkles className="w-5 h-5" />
              AI Creator Search
            </button>

            {showingAIResults && (
              <div className="flex items-center gap-2">
                <div className={`px-2 py-1 rounded-full text-xs font-medium `}>
                  {/* {useMockData ? "Demo Data" : "Live API"} */}
                </div>
                <button
                  onClick={resetToRegularResults}
                  className={`flex items-center gap-2 px-4 py-3 rounded-lg font-medium transition-all duration-300 border ${
                    isDark
                      ? "border-gray-600 text-gray-300 hover:bg-gray-700"
                      : "border-gray-300 text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  <X className="w-4 h-4" />
                  Clear AI Results
                </button>
              </div>
            )}
          </div>
        </div>

        {/* AI Search Modal */}
        <AISearchModal
          aiSearch={aiSearch}
          onUpdateAISearch={updateAISearch}
          onSearch={handleAISearch}
          isLoading={aiSearchHook.isLoading}
        />

        {/* Filters */}
        <CreatorFilters
          filters={filters}
          showAdvancedFilters={showAdvancedFilters}
          onFilterChange={updateFilter}
          onToggleAdvanced={() => setShowAdvancedFilters(!showAdvancedFilters)}
          onClearFilters={clearFilters}
        />

        {/* Results Section */}
        <div
          className={`rounded-lg shadow-sm border overflow-hidden ${
            isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
          }`}
        >
          {/* AI Results Indicator */}
          {showingAIResults && (
            <div
              className={`px-4 py-3 border-b flex items-center justify-between ${
                isDark
                  ? "bg-gradient-to-r from-purple-900/30 to-blue-900/30 border-gray-700 text-purple-300"
                  : "bg-gradient-to-r from-purple-50 to-blue-50 border-gray-200 text-purple-700"
              }`}
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">
                  Showing AI search results for "{aiSearch.topic}" on{" "}
                  {aiSearch.platform}
                </span>
              </div>
              <button
                onClick={resetToRegularResults}
                className={`text-xs px-3 py-1 rounded-full border transition-colors ${
                  isDark
                    ? "border-purple-600 hover:bg-purple-800/30"
                    : "border-purple-300 hover:bg-purple-100"
                }`}
              >
                Back to regular results
              </button>
            </div>
          )}

          <ResultsHeader
            loading={loading}
            totalResults={totalResults}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
          />

          <div className="overflow-x-auto">
            <CreatorResults
              loading={loading}
              error={errorMessage}
              creators={creators}
              viewMode={viewMode}
              formatNumber={formatNumber}
              dataSource={showingAIResults ? "ai_search" : "regular"}
            />
          </div>

          {/* Pagination */}
          <Pagination
            currentPage={currentPage}
            totalResults={totalResults}
            resultsPerPage={resultsPerPage}
            onPageChange={setCurrentPage}
            onResultsPerPageChange={handleResultsPerPageChange}
          />
        </div>
      </div>
    </div>
  );
};

export default CreatorsDashboard;
