import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useTheme } from "../contexts/ThemeContext";
import { Link, useNavigate } from "react-router-dom";

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const { login, signup, isLoading } = useAuth();
  const { theme } = useTheme();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMessage("");

    if (!email || !password || (!isLogin && !name)) {
      setError("Please fill in all fields");
      return;
    }

    try {
      if (isLogin) {
        const success = await login(email, password);
        if (!success) {
          setError(
            "Login failed. Please check your email and password, and ensure your email is confirmed."
          );
        } else {
          // Navigate to main app after successful login
          navigate("/");
        }
      } else {
        const result = await signup(email, password, name);
        if (!result) {
          setError("Signup failed. Please try again.");
        } else {
          setSuccessMessage(
            "Account created! Please check your email for a verification link."
          );
          setError(""); // Clear any previous errors
        }
      }
    } catch (err) {
      setError("An error occurred. Please try again.");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSubmit(e as any);
    }
  };

  const isDark = theme === "dark";
  // const colors = getThemeColors(isDark);

  return (
    <div
      className={`min-h-screen transition-all duration-500 ${
        isDark
          ? "bg-gradient-to-br from-gray-900 to-purple-900"
          : "bg-gradient-to-br from-orange-50 to-red-50"
      } flex items-center justify-center p-4 relative overflow-hidden`}
    >
      <div className="w-full max-w-md relative z-10">
        {/* Theme Toggle */}
        {/* <div className="flex justify-end mb-6">
          <button
            onClick={toggleTheme}
            className={`p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 ${
              isDark
                ? "bg-gray-800/80 backdrop-blur-sm border border-gray-700"
                : "bg-white/80 backdrop-blur-sm border border-white/50"
            }`}
          >
            {theme === "light" ? (
              <Moon className="w-5 h-5 text-purple-600" />
            ) : (
              <Sun className="w-5 h-5 text-yellow-400" />
            )}
          </button>
        </div> */}

        {/* Auth Form */}
        <div
          className={`rounded-3xl shadow-2xl p-8 transition-all duration-500 transform hover:scale-[1.02] ${
            isDark
              ? "bg-gray-900/80 backdrop-blur-xl border border-gray-700/50"
              : "bg-white/80 backdrop-blur-xl border border-white/50"
          }`}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0  rounded-2xl  opacity-75 animate-pulse"></div>
                <div className="relative p-4  rounded-2xl">
                  <img
                    src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
                    alt="Fyuze Logo"
                    className="w-15 h-15"
                  />
                </div>
              </div>
            </div>
            <h1
              className={`text-4xl font-bold mb-3 ${
                isDark ? "text-orange-400" : "text-purple-600"
              }`}
            >
              {isLogin ? "Welcome Back" : "Join Us"}
            </h1>
            <p
              className={`${
                isDark ? "text-gray-300" : "text-gray-600"
              } text-lg`}
            >
              {isLogin
                ? "Sign in to continue your journey"
                : "Create your account and get started"}
            </p>
          </div>

          <div className="space-y-6">
            {!isLogin && (
              <div className="space-y-2">
                <label
                  className={`block text-sm font-semibold ${
                    isDark ? "text-gray-200" : "text-gray-700"
                  }`}
                >
                  Full Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className={`w-full px-4 py-4 rounded-xl transition-all duration-300 focus:scale-[1.02] ${
                    isDark
                      ? "bg-gray-800/50 border-2 border-gray-700 text-white focus:border-orange-500 focus:bg-gray-800/70"
                      : "bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70"
                  } focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm`}
                  placeholder="Enter your full name"
                />
              </div>
            )}

            <div className="space-y-2">
              <label
                className={`block text-sm font-semibold ${
                  isDark ? "text-gray-200" : "text-gray-700"
                }`}
              >
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyPress={handleKeyPress}
                className={`w-full px-4 py-4 rounded-xl transition-all duration-300 focus:scale-[1.02] outline-none ${
                  isDark
                    ? "bg-gray-800/50 border-2 border-gray-700 text-white focus:border-orange-500 focus:bg-gray-800/70"
                    : "bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70"
                } focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm`}
                placeholder="Enter your email"
              />
            </div>

            <div className="space-y-2">
              <label
                className={`block text-sm font-semibold ${
                  isDark ? "text-gray-200" : "text-gray-700"
                }`}
              >
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className={`w-full px-4 py-4 pr-12 rounded-xl transition-all duration-300 focus:scale-[1.02] outline-none ${
                    isDark
                      ? "bg-gray-800/50 border-2 border-gray-700 text-white focus:border-orange-500 focus:bg-gray-800/70"
                      : "bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70"
                  } focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm`}
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute right-4 top-1/2 transform -translate-y-1/2 ${
                    isDark
                      ? "text-gray-400 hover:text-gray-200"
                      : "text-gray-500 hover:text-gray-700"
                  } transition-colors duration-200`}
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 p-4 rounded-xl backdrop-blur-sm">
                {error}
              </div>
            )}

            {successMessage && (
              <div className="text-green-400 text-sm text-center bg-green-500/10 border border-green-500/20 p-4 rounded-xl backdrop-blur-sm">
                {successMessage}
              </div>
            )}

            <button
              onClick={handleSubmit}
              disabled={isLoading}
              className="w-full py-4 px-6 rounded-xl font-bold text-white transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed focus:ring-4 focus:ring-orange-500/50 relative overflow-hidden group bg-orange-600 hover:bg-orange-700 shadow-xl hover:shadow-2xl"
            >
              <span className="relative z-10">
                {isLoading ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Please wait...</span>
                  </div>
                ) : isLogin ? (
                  "Sign In"
                ) : (
                  "Create Account"
                )}
              </span>
              <div className="absolute inset-0 bg-orange-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
          </div>

          <div className="mt-8 text-center space-y-4">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className={`block w-full font-semibold transition-all duration-300 transform hover:scale-105 ${
                isDark
                  ? "text-purple-400 hover:text-purple-300"
                  : "text-purple-600 hover:text-purple-700"
              }`}
            >
              {isLogin
                ? "Don't have an account? Sign up"
                : "Already have an account? Sign in"}
            </button>

            {isLogin && (
              <Link
                to="/forget-password"
                className={`block font-medium transition-all duration-300 transform hover:scale-105 ${
                  isDark
                    ? "text-purple-400 hover:text-purple-300"
                    : "text-purple-600 hover:text-purple-700"
                }`}
              >
                Forgot your password?
              </Link>
            )}
          </div>

          {/* Social Login Divider */}
          <div className="mt-8">
            <div className="relative">
              <div className={`absolute inset-0 flex items-center`}>
                <div
                  className={`w-full border-t ${
                    isDark ? "border-gray-700" : "border-gray-200"
                  }`}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
