import React, { useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { useTheme } from "../contexts/ThemeContext";
import { useCreator, useCreatorsParsing } from "../hooks";
import {
  MapPin,
  Mail,
  Instagram,
  Verified,
  AlertCircle,
  Heart,
  MessageCircle,
  Play,
  TrendingUp,
  Users,
  Calendar,
  Hash,
  ExternalLink,
  UserPlus,
  ImageIcon,
  ChevronDown,
  ChevronUp,
  Lock,
} from "lucide-react";

const CreatorProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { isDark } = useTheme();
  const { parseCreatorData } = useCreatorsParsing();

  // State hooks - all called unconditionally
  const [showAllPosts, setShowAllPosts] = useState(false);
  const [imageErrors, setImageErrors] = useState<Set<string>>(new Set());
  const [selectedPost, setSelectedPost] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Memoize all values to prevent unnecessary re-renders
  const creatorFromState = React.useMemo(
    () => location.state?.creator,
    [location.state?.creator]
  );
  const dataSourceFromState = React.useMemo(
    () => location.state?.dataSource,
    [location.state?.dataSource]
  );

  // Stabilize the ID to prevent unnecessary re-renders - ensure it's never undefined
  const stableId = React.useMemo(() => id || "", [id]);

  // Early check for ID - this helps prevent hooks order issues
  const hasValidId = React.useMemo(() => Boolean(stableId), [stableId]);

  // Use useMemo to stabilize the enabled condition for useCreator hook
  // Make sure this condition is stable and doesn't change between renders
  const shouldFetchCreator = React.useMemo(
    () => hasValidId && !creatorFromState,
    [hasValidId, creatorFromState]
  );

  const {
    data: creatorData,
    isLoading: loading,
    error,
  } = useCreator(stableId, {
    enabled: shouldFetchCreator,
  });

  // Add a useEffect to handle initialization and prevent timing issues
  React.useEffect(() => {
    // This ensures the component properly initializes on mount
    // and helps prevent hooks order issues
    if (hasValidId && !creatorFromState) {
    } else if (hasValidId && creatorFromState) {
    } else {
    }
  }, [hasValidId, creatorFromState, stableId]);

  // Add error boundary-like error handling
  React.useEffect(() => {
    if (error) {
      console.error("CreatorProfilePage: Error loading creator data:", error);
    }
  }, [error]);

  // All callback hooks must be defined before conditional returns
  const handleImageError = React.useCallback((postId: string) => {
    setImageErrors((prev) => new Set(prev).add(postId));
  }, []);

  const handlePostClick = React.useCallback((post: any) => {
    setSelectedPost(post);
    setIsModalOpen(true);
  }, []);

  const closeModal = React.useCallback(() => {
    setIsModalOpen(false);
    setSelectedPost(null);
  }, []);

  // ========================================
  // ALL HOOKS MUST BE CALLED ABOVE THIS LINE
  // No conditional logic before all hooks are called
  // ========================================

  // Now we can do conditional logic and early returns
  if (!hasValidId) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-white">Creator not found</div>
      </div>
    );
  }

  const creator =
    creatorFromState ||
    (creatorData &&
    typeof creatorData === "object" &&
    "status" in creatorData &&
    (creatorData as any).status === "success"
      ? (creatorData as any).data?.rows?.[0]
      : null);

  // Debug likes and comments for AI chatbot data
  if (
    creator &&
    (dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search")
  ) {
    // ...existing code...
  }

  // Determine the actual data source - prefer explicit dataSourceFromState, then creator's dataSource
  const actualDataSource =
    dataSourceFromState || creatorFromState?.dataSource || "get_creators";

  // Check if this is AI search data (from chatbot)
  const isAISearchData =
    actualDataSource === "ai_search" ||
    actualDataSource === "ai_search_fallback" ||
    creatorFromState?.dataSource === "ai_search";

  const enhancedCreators = creator
    ? parseCreatorData(
        // Handle different data source formats
        isAISearchData
          ? { platform_data: creator } // AI search format - creator object is already the platform data
          : { data: { rows: [creator] } }, // Regular API format
        isAISearchData ? "ai_search" : "get_creators"
      )
    : [];

  const enhancedCreator = enhancedCreators[0];
  const enhancedData = enhancedCreator
    ? {
        summary: {
          id: enhancedCreator.id,
          username: enhancedCreator.username,
          fullName: enhancedCreator.name,
          platform: enhancedCreator.platform,
          followers: enhancedCreator.followers,
          isActive: true,
          isVerified: enhancedCreator.verified,
          contactEmail: enhancedCreator.contactEmail,
          instagram: enhancedCreator.profileData,
        },
        engagement: {
          averageLikes: (() => {
            // Calculate average likes from posts/videos - prioritize direct data for AI search
            const posts =
              (dataSourceFromState === "ai_search" ||
              creatorFromState?.dataSource === "ai_search"
                ? creator?.posts?.edges || creator?.videos?.videos || []
                : enhancedCreator.profileData?.posts) ||
              creator?.posts?.edges ||
              creator?.videos?.videos ||
              [];

            if (!Array.isArray(posts) || posts.length === 0) return 0;

            const totalLikes = posts.reduce((sum: number, post: any) => {
              const likes = post.like_count || post.edge_liked_by?.count || 0;
              return sum + likes;
            }, 0);
            return Math.round(totalLikes / posts.length);
          })(),
          averageComments: (() => {
            // Calculate average comments from posts/videos - prioritize direct data for AI search
            const posts =
              (dataSourceFromState === "ai_search" ||
              creatorFromState?.dataSource === "ai_search"
                ? creator?.posts?.edges || creator?.videos?.videos || []
                : enhancedCreator.profileData?.posts) ||
              creator?.posts?.edges ||
              creator?.videos?.videos ||
              [];

            if (!Array.isArray(posts) || posts.length === 0) return 0;

            const totalComments = posts.reduce((sum: number, post: any) => {
              const comments =
                post.comment_count || post.edge_media_to_comment?.count || 0;
              return sum + comments;
            }, 0);
            return Math.round(totalComments / posts.length);
          })(),
          engagementRate: enhancedCreator.engagementRate || 0,
          totalPosts: enhancedCreator.postsCount || 0,
        },
        posts:
          (dataSourceFromState === "ai_search" ||
          creatorFromState?.dataSource === "ai_search"
            ? creator?.posts?.edges || creator?.videos?.videos || []
            : enhancedCreator.profileData?.posts) || [],
        hashtags: [],
        instagramData: enhancedCreator.profileData,
      }
    : null;

  // Extract rich Instagram data from multiple possible sources
  const instagramData =
    creator?.platformData?.parsed || creator?.raw_data || creator;

  // Parse platform_data if it's a JSON string (from database)
  let parsedPlatformData = null;
  try {
    if (creator?.platform_data && typeof creator.platform_data === "string") {
      parsedPlatformData = JSON.parse(creator.platform_data);
    } else if (
      creator?.platform_data &&
      typeof creator.platform_data === "object" &&
      creator.platform_data !== null
    ) {
      parsedPlatformData = creator.platform_data;
    } else if (creator?.username && creator?.bio) {
      // If no platform_data, the data might be in direct fields (AI search format)
      parsedPlatformData = creator;
    }
  } catch (error) {
    // Try to handle malformed JSON by cleaning it up
    if (creator?.platform_data && typeof creator.platform_data === "string") {
      try {
        const cleanedData = creator.platform_data.trim();
        parsedPlatformData = JSON.parse(cleanedData);
      } catch (cleanError) {
        // Last resort: use the creator object itself if it has the right structure
        if (creator?.username && creator?.bio) {
          parsedPlatformData = creator;
        }
      }
    }
  }

  // Extract comprehensive profile data from the all_info structure
  const profileData = {
    // Basic profile info - prioritize direct data for AI search, then parsed data
    id:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? creator?.id
        : parsedPlatformData?.id ||
          creator?.id ||
          creator?.platformData?.parsed?.id ||
          instagramData?.id,
    username:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? creator?.username
        : parsedPlatformData?.username ||
          creator?.username ||
          creator?.platformData?.parsed?.username ||
          instagramData?.username,
    fullName:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? creator?.full_name
        : parsedPlatformData?.full_name ||
          creator?.full_name ||
          creator?.name ||
          creator?.platformData?.parsed?.full_name ||
          instagramData?.full_name,
    bio:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? creator?.bio || creator?.signature // TikTok uses 'signature' for bio
        : parsedPlatformData?.bio ||
          parsedPlatformData?.signature || // TikTok signature
          creator?.bio ||
          creator?.signature || // TikTok signature fallback
          creator?.platformData?.parsed?.bio ||
          instagramData?.biography ||
          instagramData?.bio,
    profilePicUrl:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? creator?.profile_pic_url || creator?.avatar_url // TikTok uses 'avatar_url'
        : parsedPlatformData?.profile_pic_url ||
          parsedPlatformData?.avatar_url || // TikTok avatar_url
          creator?.profile_pic_url ||
          creator?.avatar_url ||
          creator?.platformData?.parsed?.profile_pic_url ||
          creator?.platformData?.parsed?.profile_pic_url_hd ||
          instagramData?.profile_pic_url_hd ||
          instagramData?.profile_pic_url,

    // Social metrics - prioritize direct data for AI search
    followers:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? creator?.profileData?.follower_count ||
          creator?.profileData?.followers ||
          creator?.follower_count ||
          creator?.followers
        : parsedPlatformData?.follower_count || // TikTok
          parsedPlatformData?.followers || // Instagram
          creator?.follower_count || // TikTok fallback
          creator?.followers || // Instagram fallback
          creator?.platformData?.parsed?.followers ||
          instagramData?.edge_followed_by?.count ||
          instagramData?.followers,
    following:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? creator?.profileData?.following_count ||
          creator?.profileData?.following ||
          creator?.following_count ||
          creator?.following // TikTok uses following_count, Instagram uses following
        : parsedPlatformData?.following_count || // TikTok
          parsedPlatformData?.following || // Instagram
          creator?.following_count || // TikTok fallback
          creator?.following || // Instagram fallback
          creator?.platformData?.parsed?.following ||
          instagramData?.edge_follow?.count ||
          instagramData?.following,
    postsCount:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? // For AI search data, check TikTok video structure first, then Instagram posts
          creator?.videos?.count || // TikTok videos count
          creator?.aweme_count || // TikTok aweme count
          creator?.posts?.count || // Instagram posts count
          (creator?.posts?.edges ? creator.posts.edges.length : 0) ||
          (Array.isArray(creator?.posts) ? creator.posts.length : 0) ||
          (creator?.videos?.videos ? creator.videos.videos.length : 0) // TikTok videos array length
        : parsedPlatformData?.videos?.count || // TikTok videos count
          parsedPlatformData?.aweme_count || // TikTok aweme count
          parsedPlatformData?.posts?.count ||
          (Array.isArray(parsedPlatformData?.posts)
            ? parsedPlatformData.posts.length
            : 0) ||
          (parsedPlatformData?.videos?.videos
            ? parsedPlatformData.videos.videos.length
            : 0) || // TikTok videos array
          creator?.posts?.count ||
          instagramData?.edge_owner_to_timeline_media?.count ||
          instagramData?.posts?.count,

    // Verification and account type - prioritize direct data for AI search
    isVerified:
      creatorFromState?.dataSource === "ai_search"
        ? creator?.is_verified
        : parsedPlatformData?.is_verified ||
          creator?.is_verified ||
          creator?.verified ||
          creator?.platformData?.parsed?.is_verified ||
          instagramData?.is_verified,
    isBusinessAccount:
      creatorFromState?.dataSource === "ai_search"
        ? false // AI search doesn't provide this info
        : instagramData?.is_business_account ||
          parsedPlatformData?.is_business_account,
    isProfessionalAccount:
      creatorFromState?.dataSource === "ai_search"
        ? false // AI search doesn't provide this info
        : instagramData?.is_professional_account,
    category:
      creatorFromState?.dataSource === "ai_search"
        ? creator?.category
        : creator?.platformData?.parsed?.category ||
          creator?.category ||
          instagramData?.category_name ||
          instagramData?.category,

    // External links and contact - prioritize direct data for AI search
    externalUrl:
      creatorFromState?.dataSource === "ai_search"
        ? creator?.links?.[0]
        : parsedPlatformData?.links?.[0] ||
          creator?.links?.[0] ||
          creator?.platformData?.parsed?.links?.[0] ||
          instagramData?.external_url,
    links: (() => {
      // Try multiple sources for links array, prioritizing direct data for AI search
      let finalLinks: string[] = [];

      // Check direct creator links (AI search format)
      if (
        creatorFromState?.dataSource === "ai_search" &&
        creator?.links &&
        Array.isArray(creator.links)
      ) {
        finalLinks = creator.links;
      }
      // Check parsed platform_data links first
      else if (
        parsedPlatformData?.links &&
        Array.isArray(parsedPlatformData.links)
      ) {
        finalLinks = parsedPlatformData.links;
      }
      // Check direct creator links (AI search format)
      else if (creator?.links && Array.isArray(creator.links)) {
        finalLinks = creator.links;
      }
      // Check platformData.parsed.links
      else if (
        creator?.platformData?.parsed?.links &&
        Array.isArray(creator.platformData.parsed.links)
      ) {
        finalLinks = creator.platformData.parsed.links;
      }

      return finalLinks;
    })(),
    contactEmail:
      creatorFromState?.dataSource === "ai_search"
        ? (() => {
            // Extract email from bio if not found elsewhere
            const bio = creator?.bio;
            if (bio) {
              const emailRegex =
                /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/;
              const match = bio.match(emailRegex);
              if (match) {
                return match[0];
              }
            }
            return undefined;
          })()
        : parsedPlatformData?.contact_email ||
          creator?.contact_email ||
          instagramData?.business_email ||
          (() => {
            // Extract email from bio if not found elsewhere
            const bio = parsedPlatformData?.bio || creator?.bio;
            if (bio) {
              const emailRegex =
                /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/;
              const match = bio.match(emailRegex);
              if (match) {
                return match[0];
              }
            }
            return undefined;
          })(),
    phoneNumber:
      parsedPlatformData?.phone_number || instagramData?.business_phone_number,

    // Business info
    businessCategory: instagramData?.business_category_name,
    businessContactMethod: instagramData?.business_contact_method,
    businessAddress: instagramData?.business_address_json
      ? JSON.parse(instagramData.business_address_json)
      : null,

    // Engagement and content
    engagementRate:
      dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search"
        ? creator?.profileData?.engagementRate !== undefined
          ? creator.profileData.engagementRate
          : creator?.engagementRate !== undefined
          ? creator.engagementRate
          : creator?.engagement_rate
        : // Check endpoint structure first (engagementRate at root level)
        creator?.engagementRate !== undefined
        ? creator.engagementRate
        : parsedPlatformData?.engagementRate !== undefined
        ? parsedPlatformData.engagementRate
        : // Check database structure (TikTok and Instagram)
        parsedPlatformData?.engagement_rate !== undefined
        ? parsedPlatformData.engagement_rate
        : creator?.engagement_rate !== undefined
        ? creator.engagement_rate
        : creator?.platformData?.parsed?.engagement_rate !== undefined
        ? creator.platformData.parsed.engagement_rate
        : // Instagram specific fallbacks
          instagramData?.edge_followed_by?.count ||
          instagramData?.engagement_rate,
    highlightReelCount:
      creatorFromState?.dataSource === "ai_search"
        ? 0 // AI search doesn't provide this
        : instagramData?.highlight_reel_count,
    hasClips:
      creatorFromState?.dataSource === "ai_search"
        ? false // AI search doesn't provide this
        : instagramData?.has_clips,
    hasGuides:
      creatorFromState?.dataSource === "ai_search"
        ? false // AI search doesn't provide this
        : instagramData?.has_guides,
    hasChannel:
      creatorFromState?.dataSource === "ai_search"
        ? false // AI search doesn't provide this
        : instagramData?.has_channel,

    // Posts data - prioritize enhanced creator data, then direct data for AI search
    posts: (() => {
      // ...existing code...

      // Priority 1: Direct TikTok videos from creator data (AI search)
      if (
        (dataSourceFromState === "ai_search" ||
          creatorFromState?.dataSource === "ai_search") &&
        creator?.videos?.videos &&
        Array.isArray(creator.videos.videos) &&
        creator.videos.videos.length > 0
      ) {
        // Using TikTok videos from creator data
        return creator.videos.videos;
      }

      // Priority 1.5: TikTok videos from parsed platform data
      if (
        parsedPlatformData?.videos?.videos &&
        Array.isArray(parsedPlatformData.videos.videos) &&
        parsedPlatformData.videos.videos.length > 0
      ) {
        return parsedPlatformData.videos.videos;
      }

      // Priority 2: Enhanced creator posts array (new structure)
      if (
        enhancedCreator?.posts &&
        Array.isArray(enhancedCreator.posts) &&
        enhancedCreator.posts.length > 0
      ) {
        return enhancedCreator.posts;
      }

      // Priority 3: Enhanced creator profileData posts
      if (
        enhancedCreator?.profileData?.posts &&
        Array.isArray(enhancedCreator.profileData.posts) &&
        enhancedCreator.profileData.posts.length > 0
      ) {
        return enhancedCreator.profileData.posts;
      }

      // Priority 3: Enhanced creator posts.edges (legacy structure)
      if (
        enhancedCreator?.posts?.edges &&
        Array.isArray(enhancedCreator.posts.edges) &&
        enhancedCreator.posts.edges.length > 0
      ) {
        return enhancedCreator.posts.edges;
      }

      // Priority 4: Direct creator posts/videos for AI search
      if (
        dataSourceFromState === "ai_search" ||
        creatorFromState?.dataSource === "ai_search"
      ) {
        // Check for TikTok videos first
        if (creator?.videos?.videos && Array.isArray(creator.videos.videos)) {
          // Using AI search TikTok videos (fallback)
          return creator.videos.videos;
        } else if (
          creator?.posts?.edges &&
          Array.isArray(creator.posts.edges)
        ) {
          // Using AI search posts.edges (fallback)
          return creator.posts.edges;
        } else if (creator?.posts && Array.isArray(creator.posts)) {
          // Using AI search posts array (fallback)
          return creator.posts;
        }
        // ...existing code...
      }

      // Priority 5: Database posts (parsed platform_data)
      if (
        parsedPlatformData?.posts?.edges &&
        Array.isArray(parsedPlatformData.posts.edges)
      ) {
        return parsedPlatformData.posts.edges;
      } else if (
        parsedPlatformData?.posts &&
        Array.isArray(parsedPlatformData.posts)
      ) {
        return parsedPlatformData.posts;
      }

      return [];
    })(),

    // Location
    location: creator?.location,

    // Additional metadata
    fbId: instagramData?.fbid,
    isPrivate: instagramData?.is_private,
    pronouns: instagramData?.pronouns || [],
  };

  // Debug likes and comments specifically for AI chatbot data
  if (
    profileData.posts &&
    profileData.posts.length > 0 &&
    (dataSourceFromState === "ai_search" ||
      creatorFromState?.dataSource === "ai_search")
  ) {
    // ...existing code...
  }

  // Handle loading state (only when fetching from API)
  if (loading && !creatorFromState) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center ${
          isDark
            ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
            : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
        }`}
      >
        <div className="text-center">
          <div className="relative">
            <img
              src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
              alt="Fyuze Logo"
              className="w-16 h-16 mx-auto mb-6 animate-spin"
            />
          </div>
        </div>
      </div>
    );
  }

  // Handle error state (only when fetching from API)
  if (error && !creatorFromState) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center ${
          isDark
            ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
            : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
        }`}
      >
        <div className="text-center">
          <AlertCircle
            className={`w-8 h-8 mx-auto mb-4 ${
              isDark ? "text-red-400" : "text-red-600"
            }`}
          />
          <p
            className={`text-lg mb-4 ${
              isDark ? "text-gray-300" : "text-gray-700"
            }`}
          >
            Failed to load creator profile
          </p>
          <p
            className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}
          >
            {error.message || "Please try again later"}
          </p>
          <button
            onClick={() => navigate(-1)}
            className={`mt-4 px-4 py-2 rounded-lg font-medium transition-colors ${
              isDark
                ? "bg-gray-700 hover:bg-gray-600 text-gray-300"
                : "bg-gray-200 hover:bg-gray-300 text-gray-700"
            }`}
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  // Handle case where creator is not found
  if (!creator) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center ${
          isDark
            ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
            : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
        }`}
      >
        <div className="text-center">
          <AlertCircle
            className={`w-8 h-8 mx-auto mb-4 ${
              isDark ? "text-red-400" : "text-red-600"
            }`}
          />
          <p
            className={`text-lg mb-4 ${
              isDark ? "text-gray-300" : "text-gray-700"
            }`}
          >
            Creator not found
          </p>
          <p
            className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}
          >
            The creator you're looking for doesn't exist or has been removed.
          </p>
          <button
            onClick={() => navigate(-1)}
            className={`mt-4 px-4 py-2 rounded-lg font-medium transition-colors ${
              isDark
                ? "bg-gray-700 hover:bg-gray-600 text-gray-300"
                : "bg-gray-200 hover:bg-gray-300 text-gray-700"
            }`}
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  const formatNumber = (num: number | undefined | null) => {
    if (!num || typeof num !== "number" || isNaN(num)) return "0";
    if (num >= 1000000) return (num / 1000000).toFixed(2) + "M";
    if (num >= 1000) return (num / 1000).toFixed(2) + "K";
    return num.toFixed(0);
  };

  // Create a proxy URL for Instagram images to bypass CORS
  const getProxyImageUrl = (originalUrl: string, proxyIndex: number = 0) => {
    if (!originalUrl) return "/api/placeholder/300/300";

    // Try multiple CORS proxy services as fallbacks
    const proxyServices = [
      // Primary: Weserv.nl (fast and reliable)
      (url: string) =>
        `https://images.weserv.nl/?url=${encodeURIComponent(
          url
        )}&w=300&h=300&fit=cover`,
      // Fallback 1: AllOrigins (good alternative)
      (url: string) =>
        `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
      // Fallback 2: Cors-anywhere (requires headers, might be rate limited)
      (url: string) => `https://cors-anywhere.herokuapp.com/${url}`,
      // Fallback 3: Direct URL (will likely fail but worth trying)
      (url: string) => url,
    ];

    // Return the specified proxy service
    const selectedService =
      proxyServices[Math.min(proxyIndex, proxyServices.length - 1)];
    const result = selectedService(originalUrl);
    return result;
  };

  // Enhanced image URL handler with error recovery
  const getImageUrl = (originalUrl: string, postId?: string) => {
    if (!originalUrl) {
      return "/api/placeholder/300/300";
    }

    // If this image has already failed, use placeholder
    if (postId && imageErrors.has(postId)) {
      return "/api/placeholder/300/300";
    }

    // Try primary proxy first
    const proxyUrl = getProxyImageUrl(originalUrl, 0);
    return proxyUrl;
  };

  return (
    <div
      className={`min-h-full ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex justify-center items-center gap-4 mb-6">
          <div>
            <h1
              className={`text-4xl font-bold ${
                isDark ? "text-white" : "text-gray-900"
              }`}
            >
              Creator Profile
            </h1>
            <p className={` ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              Detailed information and analytics
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="space-y-8">
          {/* Modern Profile Header */}
          <div className="relative">
            {/* Background Gradient */}
            <div
              className={`absolute inset-0 rounded-3xl ${
                isDark
                  ? "bg-gradient-to-br from-purple-900/20 via-pink-900/20 to-blue-900/20"
                  : "bg-gradient-to-br from-purple-100/50 via-pink-100/50 to-blue-100/50"
              }`}
            />

            {/* Profile Card */}
            <div
              className={`relative p-8 rounded-3xl backdrop-blur-sm ${
                isDark
                  ? "bg-gray-900/80 border border-gray-700/50"
                  : "bg-white/80 border border-gray-200/50"
              } shadow-2xl`}
            >
              {/* Profile Picture - Top Center */}
              <div className="flex flex-col items-center mb-8">
                <div className="relative group">
                  <div
                    className={`absolute inset-0 rounded-full blur-xl ${
                      isDark
                        ? "bg-gradient-to-r from-purple-500/30 to-pink-500/30"
                        : "bg-gradient-to-r from-purple-300/30 to-pink-300/30"
                    } group-hover:blur-2xl transition-all duration-500`}
                  />
                  <img
                    src={getImageUrl(profileData.profilePicUrl, "profile-pic")}
                    alt={profileData.fullName || profileData.username}
                    className="relative w-32 h-32 rounded-full object-cover shadow-2xl ring-4 ring-white/20 group-hover:scale-105 transition-transform duration-300"
                    onError={() => handleImageError("profile-pic")}
                  />
                  {/* Subtle glow effect */}
                  <div
                    className={`absolute inset-0 rounded-full ring-2 ${
                      isDark ? "ring-purple-500/20" : "ring-purple-400/20"
                    }`}
                  />
                </div>
              </div>

              {/* Profile Info - Centered */}
              <div className="text-center mb-6">
                <h1
                  className={`text-3xl font-bold mb-2 ${
                    isDark ? "text-white" : "text-gray-900"
                  }`}
                >
                  {profileData.fullName}
                </h1>

                <div className="flex items-center justify-center gap-2 mb-3">
                  <Instagram className="w-5 h-5 text-pink-500" />
                  <span
                    className={`text-lg font-medium ${
                      isDark ? "text-gray-300" : "text-gray-700"
                    }`}
                  >
                    @{profileData.username}
                  </span>
                </div>

                {profileData.category && (
                  <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg">
                    {profileData.category}
                  </div>
                )}
              </div>

              {/* Bio */}
              {profileData.bio && (
                <div className="text-center mb-6">
                  <p
                    className={`text-base leading-relaxed max-w-2xl mx-auto ${
                      isDark ? "text-gray-300" : "text-gray-600"
                    }`}
                  >
                    {profileData.bio}
                  </p>
                </div>
              )}

              {/* Status Badges - Separate Section */}
              <div className="flex flex-wrap justify-center gap-3 mb-6">
                {profileData.isVerified && (
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg">
                    <Verified className="w-4 h-4" />
                    <span className="text-sm font-medium">Verified</span>
                  </div>
                )}

                {profileData.isProfessionalAccount && (
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg">
                    <Users className="w-4 h-4" />
                    <span className="text-sm font-medium">
                      {profileData.isBusinessAccount
                        ? "Business Account"
                        : "Creator Account"}
                    </span>
                  </div>
                )}

                {profileData.isPrivate && (
                  <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-gray-500 to-gray-600 text-white shadow-lg">
                    <Lock className="w-4 h-4" />
                    <span className="text-sm font-medium">Private Account</span>
                  </div>
                )}
              </div>

              {/* External Links */}
              {profileData.links && profileData.links.length > 0 && (
                <div className="text-center">
                  <div className="inline-flex flex-wrap justify-center gap-3">
                    {profileData.links.map((link: string, index: number) => (
                      <a
                        key={index}
                        href={link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 text-white hover:from-blue-600 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                      >
                        <ExternalLink className="w-4 h-4" />
                        <span className="text-sm font-medium">Visit Link</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* Location and Contact */}
              {(creator.location ||
                profileData.contactEmail ||
                creator.contact_email) && (
                <div className="flex flex-wrap justify-center gap-4 mt-6 pt-6 border-t border-gray-200/20">
                  {creator.location && (
                    <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/10 backdrop-blur-sm">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span
                        className={`text-sm ${
                          isDark ? "text-gray-300" : "text-gray-600"
                        }`}
                      >
                        {creator.location}
                      </span>
                    </div>
                  )}
                  {(profileData.contactEmail || creator.contact_email) && (
                    <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/10 backdrop-blur-sm">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <a
                        href={`mailto:${
                          profileData.contactEmail || creator.contact_email
                        }`}
                        className="text-sm text-blue-400 hover:text-blue-300 transition-colors"
                      >
                        Contact
                      </a>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div
              className={`p-4 rounded-xl ${
                isDark
                  ? "bg-gray-800 border border-gray-700"
                  : "bg-white border border-gray-200"
              } shadow-lg`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-5 h-5 text-blue-500" />
                <span
                  className={`text-sm font-medium ${
                    isDark ? "text-gray-400" : "text-gray-600"
                  }`}
                >
                  Followers
                </span>
              </div>
              <div
                className={`text-2xl font-bold ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                {formatNumber(profileData.followers)}
              </div>
            </div>

            <div
              className={`p-4 rounded-xl ${
                isDark
                  ? "bg-gray-800 border border-gray-700"
                  : "bg-white border border-gray-200"
              } shadow-lg`}
            >
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-green-500" />
                <span
                  className={`text-sm font-medium ${
                    isDark ? "text-gray-400" : "text-gray-600"
                  }`}
                >
                  Engagement
                </span>
              </div>
              <div
                className={`text-2xl font-bold ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                {profileData.engagementRate &&
                typeof profileData.engagementRate === "number"
                  ? profileData.engagementRate.toFixed(1)
                  : enhancedCreator?.engagementRate &&
                    typeof enhancedCreator.engagementRate === "number"
                  ? enhancedCreator.engagementRate.toFixed(1)
                  : "N/A"}
                %
              </div>
            </div>

            <div
              className={`p-4 rounded-xl ${
                isDark
                  ? "bg-gray-800 border border-gray-700"
                  : "bg-white border border-gray-200"
              } shadow-lg`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="w-5 h-5 text-purple-500" />
                <span
                  className={`text-sm font-medium ${
                    isDark ? "text-gray-400" : "text-gray-600"
                  }`}
                >
                  Posts
                </span>
              </div>
              <div
                className={`text-2xl font-bold ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                {formatNumber(
                  Array.isArray(profileData.posts)
                    ? profileData.posts.length
                    : profileData.posts?.edges?.length || profileData.postsCount
                )}
              </div>
            </div>

            <div
              className={`p-4 rounded-xl ${
                isDark
                  ? "bg-gray-800 border border-gray-700"
                  : "bg-white border border-gray-200"
              } shadow-lg`}
            >
              <div className="flex items-center gap-2 mb-2">
                <UserPlus className="w-5 h-5 text-blue-500" />
                <span
                  className={`text-sm font-medium ${
                    isDark ? "text-gray-400" : "text-gray-600"
                  }`}
                >
                  Following
                </span>
              </div>
              <div
                className={`text-2xl font-bold ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                {formatNumber(profileData.following)}
              </div>
            </div>
          </div>

          {/* Comprehensive Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Engagement Metrics */}
            <div
              className={`p-6 rounded-xl ${
                isDark
                  ? "bg-gray-800 border border-gray-700"
                  : "bg-white border border-gray-200"
              } shadow-lg`}
            >
              <h3
                className={`text-lg font-semibold mb-4 ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                Engagement Insights
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-blue-500/20 to-purple-500/20">
                  <span
                    className={`text-sm ${
                      isDark ? "text-gray-300" : "text-gray-700"
                    }`}
                  >
                    Avg. Engagement Rate
                  </span>
                  <span
                    className={`font-bold ${
                      isDark ? "text-white" : "text-gray-900"
                    }`}
                  >
                    {(() => {
                      const rate = profileData.engagementRate;
                      if (rate === null || rate === undefined) return "N/A";

                      const numRate =
                        typeof rate === "string" ? parseFloat(rate) : rate;
                      if (isNaN(numRate)) return "N/A";

                      return `${numRate.toFixed(2)}%`;
                    })()}
                  </span>
                </div>

                {profileData.posts.length > 0 && (
                  <>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-green-500/20 to-blue-500/20">
                      <span
                        className={`text-sm ${
                          isDark ? "text-gray-300" : "text-gray-700"
                        }`}
                      >
                        Avg. Likes per Post
                      </span>
                      <span
                        className={`font-bold ${
                          isDark ? "text-white" : "text-gray-900"
                        }`}
                      >
                        {formatNumber(
                          profileData.posts.reduce((acc: number, post: any) => {
                            const postNode = post.node || post;
                            return (
                              acc +
                              (postNode.edge_liked_by?.count ||
                                postNode.like_count ||
                                0)
                            );
                          }, 0) / profileData.posts.length
                        )}
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-orange-500/20 to-red-500/20">
                      <span
                        className={`text-sm ${
                          isDark ? "text-gray-300" : "text-gray-700"
                        }`}
                      >
                        Avg. Comments per Post
                      </span>
                      <span
                        className={`font-bold ${
                          isDark ? "text-white" : "text-gray-900"
                        }`}
                      >
                        {(
                          profileData.posts.reduce((acc: number, post: any) => {
                            const postNode = post.node || post;
                            return (
                              acc +
                              (postNode.edge_media_to_comment?.count ||
                                postNode.comment_count ||
                                0)
                            );
                          }, 0) / profileData.posts.length
                        ).toFixed(2)}
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Content Analysis */}
            <div
              className={`p-6 rounded-xl ${
                isDark
                  ? "bg-gray-800 border border-gray-700"
                  : "bg-white border border-gray-200"
              } shadow-lg`}
            >
              <h3
                className={`text-lg font-semibold mb-4 ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                Content Analysis
              </h3>
              <div className="space-y-4">
                {profileData.posts.length > 0 && (
                  <>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-pink-500/20 to-orange-500/20">
                      <span
                        className={`text-sm ${
                          isDark ? "text-gray-300" : "text-gray-700"
                        }`}
                      >
                        Video Content
                      </span>
                      <span
                        className={`font-bold ${
                          isDark ? "text-white" : "text-gray-900"
                        }`}
                      >
                        {Math.round(
                          (profileData.posts.filter((post: any) => {
                            const postNode = post.node || post;
                            return (
                              postNode.is_video ||
                              postNode.product_type === "clips"
                            );
                          }).length /
                            profileData.posts.length) *
                            100
                        )}
                        %
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-teal-500/20 to-green-500/20">
                      <span
                        className={`text-sm ${
                          isDark ? "text-gray-300" : "text-gray-700"
                        }`}
                      >
                        Posting Frequency
                      </span>
                      <span
                        className={`font-bold ${
                          isDark ? "text-white" : "text-gray-900"
                        }`}
                      >
                        {profileData.posts.length > 1
                          ? (() => {
                              const sortedPosts = [...profileData.posts]
                                .filter(
                                  (post: any) =>
                                    (post.node || post).taken_at_timestamp
                                )
                                .sort(
                                  (a: any, b: any) =>
                                    (b.node || b).taken_at_timestamp -
                                    (a.node || a).taken_at_timestamp
                                );

                              if (sortedPosts.length < 2) return "N/A";

                              const daysDiff = Math.abs(
                                ((sortedPosts[0].node || sortedPosts[0])
                                  .taken_at_timestamp -
                                  (
                                    sortedPosts[sortedPosts.length - 1].node ||
                                    sortedPosts[sortedPosts.length - 1]
                                  ).taken_at_timestamp) /
                                  (60 * 60 * 24)
                              );

                              const avgDaysBetweenPosts =
                                daysDiff / (sortedPosts.length - 1);

                              if (avgDaysBetweenPosts < 1) return "Daily";
                              if (avgDaysBetweenPosts < 7)
                                return `${Math.round(
                                  avgDaysBetweenPosts
                                )} days`;
                              if (avgDaysBetweenPosts < 30)
                                return `${Math.round(
                                  avgDaysBetweenPosts / 7
                                )} weeks`;
                              return `${Math.round(
                                avgDaysBetweenPosts / 30
                              )} months`;
                            })()
                          : "N/A"}
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Additional Creator Details - fallback when platform data is not available */}
          {!creator.platform_data && (
            <div
              className={`p-6 rounded-xl ${
                isDark ? "bg-gray-800" : "bg-gray-50"
              }`}
            >
              <h3
                className={`text-lg font-semibold mb-4 ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                Creator Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-sm ${
                        isDark ? "text-gray-400" : "text-gray-600"
                      }`}
                    >
                      Platform
                    </span>
                    <span
                      className={`text-sm font-medium ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      {creator.platform}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-sm ${
                        isDark ? "text-gray-400" : "text-gray-600"
                      }`}
                    >
                      Verified
                    </span>
                    <span
                      className={`text-sm font-medium ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      {creator.verified ? "Yes" : "No"}
                    </span>
                  </div>
                  {creator.location && (
                    <div className="flex items-center justify-between">
                      <span
                        className={`text-sm ${
                          isDark ? "text-gray-400" : "text-gray-600"
                        }`}
                      >
                        Location
                      </span>
                      <span
                        className={`text-sm font-medium ${
                          isDark ? "text-white" : "text-gray-900"
                        }`}
                      >
                        {creator.location}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Posts Debug Info */}

          {/* Recent Posts */}
          {profileData.posts && profileData.posts.length > 0 ? (
            <div
              className={`p-6 rounded-xl ${
                isDark
                  ? "bg-gray-800 border border-gray-700"
                  : "bg-white border border-gray-200"
              } shadow-lg`}
            >
              <div className="flex items-center justify-between mb-4">
                <h3
                  className={`text-lg font-semibold ${
                    isDark ? "text-white" : "text-gray-900"
                  }`}
                >
                  Recent Posts ({profileData.posts.length})
                </h3>
                {profileData.posts.length > 6 && (
                  <button
                    onClick={() => setShowAllPosts(!showAllPosts)}
                    className={`flex items-center gap-2 px-3 py-1 rounded-lg text-sm transition-colors ${
                      isDark
                        ? "bg-gray-700 hover:bg-gray-600 text-gray-300"
                        : "bg-gray-100 hover:bg-gray-200 text-gray-700"
                    }`}
                  >
                    {showAllPosts ? (
                      <>
                        <ChevronUp className="w-4 h-4" />
                        Show Less
                      </>
                    ) : (
                      <>
                        <ChevronDown className="w-4 h-4" />
                        Show All ({profileData.posts.length})
                      </>
                    )}
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {profileData.posts
                  .slice(0, showAllPosts ? profileData.posts.length : 8)
                  .map((post: any, index: number) => {
                    // Handle both nested (node) and flat post structures
                    const postNode = post.node || post;
                    const postId = postNode.id || `post-${index}`;
                    const hasImageError = imageErrors.has(postId);

                    // Handle caption from different structures
                    const caption =
                      // Try nested Instagram API structure first
                      postNode.edge_media_to_caption?.edges?.[0]?.node?.text ||
                      // Try direct flat structure (Instagram/general)
                      postNode.caption ||
                      postNode.text ||
                      // Try TikTok structure
                      postNode.desc ||
                      // Fallback for flat structure
                      post.caption ||
                      post.text ||
                      post.desc ||
                      "";

                    // Debug likes/comments if they're missing for AI chatbot data
                    if (
                      (dataSourceFromState === "ai_search" ||
                        creatorFromState?.dataSource === "ai_search") &&
                      index < 3 &&
                      !(postNode.like_count || postNode.edge_liked_by?.count)
                    ) {
                      console.log(`🔍 Missing likes for post ${index}:`, {
                        postNode,
                        like_count: postNode.like_count,
                        edge_liked_by: postNode.edge_liked_by,
                        comment_count: postNode.comment_count,
                        edge_media_to_comment: postNode.edge_media_to_comment,
                      });
                    }

                    // Try multiple image sources - handle both Instagram and TikTok structures
                    const originalImage =
                      // Instagram sources
                      postNode.thumbnail_src ||
                      postNode.display_url ||
                      postNode.thumbnailSrc ||
                      // TikTok sources
                      postNode.cover_url ||
                      // Fallback for flat structure
                      post.thumbnail_src ||
                      post.display_url ||
                      post.cover_url;
                    const imageUrl = getImageUrl(originalImage, postId);

                    return (
                      <div
                        key={postId}
                        className={`h-[350px] flex flex-col rounded-xl overflow-hidden ${
                          isDark ? "bg-gray-800" : "bg-white"
                        } shadow-lg border ${
                          isDark ? "border-gray-700" : "border-gray-100"
                        } hover:shadow-xl hover:scale-[1.02] transition-all duration-300 group`}
                      >
                        {/* Image Container - Fixed Height */}
                        <div
                          className="h-48 relative cursor-pointer overflow-hidden"
                          onClick={() => handlePostClick(post)}
                        >
                          {hasImageError ? (
                            <div
                              className={`w-full h-full flex items-center justify-center ${
                                isDark ? "bg-gray-600" : "bg-gray-100"
                              }`}
                            >
                              <div className="text-center">
                                <ImageIcon
                                  className={`w-8 h-8 mx-auto mb-2 ${
                                    isDark ? "text-gray-400" : "text-gray-500"
                                  }`}
                                />
                                <p
                                  className={`text-xs ${
                                    isDark ? "text-gray-400" : "text-gray-500"
                                  }`}
                                >
                                  Image unavailable
                                </p>
                              </div>
                            </div>
                          ) : (
                            <img
                              src={imageUrl}
                              alt={`Post ${index + 1}`}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                              onError={() => handleImageError(postId)}
                              loading="lazy"
                            />
                          )}

                          {/* Overlay indicators */}
                          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />

                          {/* Video Play Button */}
                          {postNode.is_video && (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="bg-black/50 backdrop-blur-sm rounded-full p-3 transform group-hover:scale-110 transition-transform duration-300">
                                <Play className="w-6 h-6 text-white fill-white" />
                              </div>
                            </div>
                          )}

                          {/* Reel Badge */}
                          {(postNode.is_video ||
                            postNode.product_type === "clips") && (
                            <div className="absolute top-3 right-3 bg-pink-500 text-white px-2 py-1 rounded-md text-xs font-semibold">
                              Reel
                            </div>
                          )}

                          {/* Multiple Photos Indicator */}
                          {postNode.__typename === "GraphSidecar" && (
                            <div className="absolute top-3 right-3 bg-gray-900/80 text-white px-2 py-1 rounded-md text-xs font-medium">
                              Multiple
                            </div>
                          )}

                          {/* Click to Play Indicator for Videos */}
                          {(postNode.is_video ||
                            postNode.product_type === "clips") && (
                            <div className="absolute top-3 left-3 bg-blue-500/90 backdrop-blur-sm text-white px-2 py-1 rounded-md text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                              Click to Watch
                            </div>
                          )}
                        </div>

                        {/* Content Container - Fixed Structure */}
                        <div className="flex-1 flex flex-col p-4">
                          {/* Caption - Fixed Height with Scroll */}
                          <div className="flex-1 mb-3">
                            <p
                              className={`text-xs leading-relaxed line-clamp-3 ${
                                isDark ? "text-gray-300" : "text-gray-600"
                              }`}
                              title={caption || "No caption available"}
                            >
                              {caption || "No caption available"}
                            </p>
                          </div>

                          {/* Fixed Bottom Section */}
                          <div className="mt-auto space-y-2">
                            {/* Engagement Stats - Always Fixed Position */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                <span
                                  className={`flex items-center gap-1 text-xs ${
                                    isDark ? "text-gray-400" : "text-gray-500"
                                  }`}
                                >
                                  <Heart className="w-4 h-4 text-red-500" />
                                  {formatNumber(
                                    postNode.edge_liked_by?.count ||
                                      postNode.like_count ||
                                      0
                                  )}
                                </span>
                                <span
                                  className={`flex items-center gap-1 text-xs ${
                                    isDark ? "text-gray-400" : "text-gray-500"
                                  }`}
                                >
                                  <MessageCircle className="w-4 h-4 text-blue-500" />
                                  {formatNumber(
                                    postNode.edge_media_to_comment?.count ||
                                      postNode.comment_count ||
                                      0
                                  )}
                                </span>
                                {postNode.video_view_count && (
                                  <span
                                    className={`flex items-center gap-1 text-xs ${
                                      isDark ? "text-gray-400" : "text-gray-500"
                                    }`}
                                  >
                                    <Play className="w-4 h-4 text-green-500" />
                                    {formatNumber(postNode.video_view_count)}
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Post Date - Always at Bottom */}
                            {postNode.taken_at_timestamp && (
                              <p
                                className={`text-xs ${
                                  isDark ? "text-gray-500" : "text-gray-400"
                                }`}
                              >
                                {new Date(
                                  postNode.taken_at_timestamp * 1000
                                ).toLocaleDateString("en-US", {
                                  year: "numeric",
                                  month: "short",
                                  day: "numeric",
                                })}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>

              {/* Load More Button for large post counts */}
              {!showAllPosts && profileData.posts.length > 12 && (
                <div className="text-center mt-6">
                  <button
                    onClick={() => setShowAllPosts(true)}
                    className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                      isDark
                        ? "bg-gray-700 hover:bg-gray-600 text-gray-300"
                        : "bg-gray-100 hover:bg-gray-200 text-gray-700"
                    }`}
                  >
                    Load All {profileData.posts.length} Posts
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div
              className={`p-6 rounded-xl ${
                isDark
                  ? "bg-gray-800 border border-gray-700"
                  : "bg-white border border-gray-200"
              } shadow-lg`}
            >
              <h3
                className={`text-lg font-semibold ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                Recent Posts
              </h3>
              <p
                className={`mt-2 text-sm ${
                  isDark ? "text-gray-400" : "text-gray-600"
                }`}
              >
                No posts available. Posts found:{" "}
                {profileData.posts ? profileData.posts.length : 0}
              </p>
              <div className="mt-2 text-xs text-gray-500">
                <p>Debug info:</p>
                <p>
                  Posts array: {Array.isArray(profileData.posts) ? "Yes" : "No"}
                </p>
                <p>Posts length: {profileData.posts?.length || 0}</p>
                <p>Posts exists: {profileData.posts ? "Yes" : "No"}</p>
              </div>
            </div>
          )}

          {/* Hashtags */}
          {enhancedData?.hashtags && enhancedData.hashtags.length > 0 && (
            <div
              className={`p-6 rounded-xl ${
                isDark ? "bg-gray-800" : "bg-gray-50"
              }`}
            >
              <h3
                className={`text-lg font-semibold mb-4 ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                Popular Hashtags
              </h3>
              <div className="flex flex-wrap gap-2">
                {enhancedData.hashtags
                  .slice(0, 15)
                  .map((hashtag: string, index: number) => (
                    <span
                      key={index}
                      className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm ${
                        isDark
                          ? "bg-blue-900/30 text-blue-300"
                          : "bg-blue-100 text-blue-600"
                      }`}
                    >
                      <Hash className="w-3 h-3" />
                      {hashtag.replace("#", "")}
                    </span>
                  ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Post Modal */}
      {isModalOpen && selectedPost && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div
            className={`relative max-w-6xl w-full h-full max-h-[90vh] ${
              isDark ? "bg-gray-800" : "bg-white"
            } rounded-lg overflow-hidden flex flex-col`}
          >
            {/* Close Button */}
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black bg-opacity-50 text-white hover:bg-opacity-75 transition-all"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>

            <div className="flex flex-col lg:flex-row h-full">
              {/* Media Section */}
              <div className="flex-1 flex items-center justify-center bg-black">
                {selectedPost.is_video ? (
                  <video
                    controls
                    className="w-full h-full max-w-full max-h-full object-contain"
                    style={{ minWidth: "400px", minHeight: "400px" }}
                    poster={getImageUrl(
                      selectedPost.display_url,
                      "modal-video-poster"
                    )}
                    preload="metadata"
                  >
                    <source src={selectedPost.video_url} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                ) : (
                  <img
                    src={getImageUrl(selectedPost.display_url, "modal-image")}
                    alt="Post content"
                    className="w-full h-full max-w-full max-h-full object-contain"
                    style={{ minWidth: "400px", minHeight: "400px" }}
                    onError={() => handleImageError("modal-image")}
                  />
                )}
              </div>

              {/* Details Section */}
              <div
                className={`lg:w-96 p-6 overflow-y-auto ${
                  isDark ? "bg-gray-800" : "bg-white"
                }`}
              >
                {/* Post Header */}
                <div className="flex items-center space-x-3 mb-4">
                  <img
                    src={getImageUrl(
                      profileData.profilePicUrl,
                      "modal-profile-pic"
                    )}
                    alt={profileData.username}
                    className="w-8 h-8 rounded-full"
                    onError={() => handleImageError("modal-profile-pic")}
                  />
                  <span
                    className={`font-medium ${
                      isDark ? "text-white" : "text-gray-900"
                    }`}
                  >
                    {profileData.username}
                  </span>
                </div>

                {/* Full Caption */}
                {(selectedPost.edge_media_to_caption?.edges?.[0]?.node?.text ||
                  selectedPost.caption) && (
                  <div className="mb-4">
                    <p
                      className={`text-sm leading-relaxed ${
                        isDark ? "text-gray-300" : "text-gray-700"
                      }`}
                    >
                      {selectedPost.edge_media_to_caption?.edges?.[0]?.node
                        ?.text || selectedPost.caption}
                    </p>
                  </div>
                )}

                {/* Post Stats */}
                <div className="flex items-center space-x-6 mb-4 text-sm">
                  {selectedPost.edge_media_preview_like && (
                    <div
                      className={`flex items-center space-x-1 ${
                        isDark ? "text-gray-400" : "text-gray-600"
                      }`}
                    >
                      <svg
                        className="w-4 h-4"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span>
                        {selectedPost.edge_media_preview_like.count?.toLocaleString()}
                      </span>
                    </div>
                  )}
                  {selectedPost.edge_media_to_comment && (
                    <div
                      className={`flex items-center space-x-1 ${
                        isDark ? "text-gray-400" : "text-gray-600"
                      }`}
                    >
                      <svg
                        className="w-4 h-4"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span>
                        {selectedPost.edge_media_to_comment.count?.toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>

                {/* Post Date */}
                {selectedPost.taken_at_timestamp && (
                  <p
                    className={`text-xs ${
                      isDark ? "text-gray-400" : "text-gray-500"
                    }`}
                  >
                    {new Date(
                      selectedPost.taken_at_timestamp * 1000
                    ).toLocaleDateString()}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreatorProfilePage;
