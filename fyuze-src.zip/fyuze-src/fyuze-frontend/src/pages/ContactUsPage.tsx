import React, { useState } from "react";
import {
  Mail,
  Phone,
  MapPin,
  Send,
  MessageCircle,
  Instagram,
  Youtube,
} from "lucide-react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTiktok } from "@fortawesome/free-brands-svg-icons";
import { useTheme } from "../contexts/ThemeContext";
import ChatBackground from "../components/chatInterface/ChatBackground";
import { addContactMessage } from "../lib/supabaseClient";
const ContactUsPage = () => {
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState("");
  const [isSuccess, setIsSuccess] = useState<boolean | null>(null);
  const { theme } = useTheme();
  const isDark = theme === "dark";

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitMessage("");
    setIsSuccess(null);

    try {
      const result = await addContactMessage({
        first_name: formData.first_name,
        last_name: formData.last_name,
        email: formData.email,
        subject: formData.subject,
        message: formData.message,
      });

      if (result.status === "success") {
        setSubmitMessage(result.message);
        setIsSuccess(true);
        setFormData({
          first_name: "",
          last_name: "",
          email: "",
          subject: "",
          message: "",
        });
      } else {
        setSubmitMessage(result.message);
        setIsSuccess(false);
      }
    } catch (error) {
      console.error("Error submitting contact form:", error);
      setSubmitMessage("An error occurred. Please try again later.");
      setIsSuccess(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className={`min-h-screen transition-all duration-500 ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      } flex items-center justify-center p-4 relative overflow-hidden`}
    >
      <ChatBackground isDark={isDark} />

      <div className="w-full max-w-6xl relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <div
            className={`rounded-3xl shadow-2xl p-8 transition-all duration-500 transform hover:scale-[1.01] ${
              isDark
                ? "bg-gray-900/80 backdrop-blur-xl border border-gray-700/50"
                : "bg-white/80 backdrop-blur-xl border border-white/50"
            }`}
          >
            {/* Header */}
            <div className="text-center mb-8">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="absolute inset-0 rounded-2xl opacity-75 animate-pulse"></div>
                  <div className="relative p-4 rounded-2xl">
                    <img
                      src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
                      alt="Fyuze Logo"
                      className="w-15 h-15"
                    />
                  </div>
                </div>
              </div>
              <h1
                className={`text-4xl font-bold mb-3 ${
                  isDark ? "text-orange-400" : "text-purple-600"
                }`}
              >
                Contact Us
              </h1>
              <p
                className={`${
                  isDark ? "text-gray-300" : "text-gray-600"
                } text-lg`}
              >
                We'd love to hear from you! Send us a message and we'll respond
                as soon as possible.
              </p>
            </div>

            {/* Contact Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label
                    className={`block text-sm font-semibold ${
                      isDark ? "text-gray-200" : "text-gray-700"
                    }`}
                  >
                    First Name
                  </label>
                  <input
                    type="text"
                    name="first_name"
                    value={formData.first_name}
                    onChange={handleInputChange}
                    required
                    className={`w-full px-4 py-4 rounded-xl transition-all duration-300 focus:scale-[1.02] ${
                      isDark
                        ? "bg-gray-800/50 border-2 border-gray-700 text-white focus:border-orange-500 focus:bg-gray-800/70"
                        : "bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70"
                    } focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm`}
                    placeholder="Enter your first name"
                  />
                </div>

                <div className="space-y-2">
                  <label
                    className={`block text-sm font-semibold ${
                      isDark ? "text-gray-200" : "text-gray-700"
                    }`}
                  >
                    Last Name
                  </label>
                  <input
                    type="text"
                    name="last_name"
                    value={formData.last_name}
                    onChange={handleInputChange}
                    required
                    className={`w-full px-4 py-4 rounded-xl transition-all duration-300 focus:scale-[1.02] ${
                      isDark
                        ? "bg-gray-800/50 border-2 border-gray-700 text-white focus:border-orange-500 focus:bg-gray-800/70"
                        : "bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70"
                    } focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm`}
                    placeholder="Enter your last name"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label
                  className={`block text-sm font-semibold ${
                    isDark ? "text-gray-200" : "text-gray-700"
                  }`}
                >
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-4 py-4 rounded-xl transition-all duration-300 focus:scale-[1.02] ${
                    isDark
                      ? "bg-gray-800/50 border-2 border-gray-700 text-white focus:border-orange-500 focus:bg-gray-800/70"
                      : "bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70"
                  } focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm`}
                  placeholder="Enter your email"
                />
              </div>

              <div className="space-y-2">
                <label
                  className={`block text-sm font-semibold ${
                    isDark ? "text-gray-200" : "text-gray-700"
                  }`}
                >
                  Subject
                </label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  required
                  className={`w-full px-4 py-4 rounded-xl transition-all duration-300 focus:scale-[1.02] ${
                    isDark
                      ? "bg-gray-800/50 border-2 border-gray-700 text-white focus:border-orange-500 focus:bg-gray-800/70"
                      : "bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70"
                  } focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm`}
                  placeholder="What's this about?"
                />
              </div>

              <div className="space-y-2">
                <label
                  className={`block text-sm font-semibold ${
                    isDark ? "text-gray-200" : "text-gray-700"
                  }`}
                >
                  Message
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  rows={5}
                  className={`w-full px-4 py-4 rounded-xl transition-all duration-300 focus:scale-[1.02] resize-none ${
                    isDark
                      ? "bg-gray-800/50 border-2 border-gray-700 text-white focus:border-orange-500 focus:bg-gray-800/70"
                      : "bg-white/50 border-2 border-gray-200 text-gray-900 focus:border-orange-500 focus:bg-white/70"
                  } focus:ring-4 focus:ring-orange-500/20 backdrop-blur-sm`}
                  placeholder="Tell us more about your inquiry..."
                />
              </div>

              {submitMessage && (
                <div
                  className={`text-sm text-center p-4 rounded-xl backdrop-blur-sm ${
                    isSuccess === false
                      ? "text-red-400 bg-red-500/10 border border-red-500/20"
                      : "text-green-400 bg-green-500/10 border border-green-500/20"
                  }`}
                >
                  {submitMessage}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 px-6 rounded-xl font-bold text-white transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed focus:ring-4 focus:ring-orange-500/50 relative overflow-hidden group bg-orange-600 hover:bg-orange-700 shadow-xl hover:shadow-2xl"
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Sending...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      <span>Send Message</span>
                    </>
                  )}
                </span>
                <div className="absolute inset-0 bg-orange-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Contact Details */}
            <div
              className={`rounded-3xl shadow-2xl p-8 transition-all duration-500 ${
                isDark
                  ? "bg-gray-900/80 backdrop-blur-xl border border-gray-700/50"
                  : "bg-white/80 backdrop-blur-xl border border-white/50"
              }`}
            >
              <h2
                className={`text-2xl font-bold mb-6 ${
                  isDark ? "text-orange-400" : "text-purple-600"
                }`}
              >
                Get In Touch
              </h2>

              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div
                    className={`p-3 rounded-xl ${
                      isDark ? "bg-orange-500/20" : "bg-purple-100"
                    }`}
                  >
                    <Mail
                      className={`w-6 h-6 ${
                        isDark ? "text-orange-400" : "text-purple-600"
                      }`}
                    />
                  </div>
                  <div>
                    <h3
                      className={`font-semibold ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      Email Us
                    </h3>
                    <p
                      className={`${
                        isDark ? "text-gray-300" : "text-gray-600"
                      }`}
                    >
                      hello@fyuze.com
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div
                    className={`p-3 rounded-xl ${
                      isDark ? "bg-orange-500/20" : "bg-purple-100"
                    }`}
                  >
                    <Phone
                      className={`w-6 h-6 ${
                        isDark ? "text-orange-400" : "text-purple-600"
                      }`}
                    />
                  </div>
                  <div>
                    <h3
                      className={`font-semibold ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      Call Us
                    </h3>
                    <p
                      className={`${
                        isDark ? "text-gray-300" : "text-gray-600"
                      }`}
                    >
                      +1 (555) 123-4567
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div
                    className={`p-3 rounded-xl ${
                      isDark ? "bg-orange-500/20" : "bg-purple-100"
                    }`}
                  >
                    <MapPin
                      className={`w-6 h-6 ${
                        isDark ? "text-orange-400" : "text-purple-600"
                      }`}
                    />
                  </div>
                  <div>
                    <h3
                      className={`font-semibold ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      Visit Us
                    </h3>
                    <p
                      className={`${
                        isDark ? "text-gray-300" : "text-gray-600"
                      }`}
                    >
                      123 Creator Street
                      <br />
                      Content City, CC 12345
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Media */}
            <div
              className={`rounded-3xl shadow-2xl p-8 transition-all duration-500 ${
                isDark
                  ? "bg-gray-900/80 backdrop-blur-xl border border-gray-700/50"
                  : "bg-white/80 backdrop-blur-xl border border-white/50"
              }`}
            >
              <h2
                className={`text-2xl font-bold mb-6 ${
                  isDark ? "text-orange-400" : "text-purple-600"
                }`}
              >
                Follow Us
              </h2>

              <div className="grid grid-cols-2 gap-4">
                <a
                  href="#"
                  className={`flex items-center justify-center gap-3 p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                    isDark
                      ? "border-gray-700 bg-gray-800/50 text-gray-200 hover:bg-gray-700/50"
                      : "border-gray-200 bg-white/50 text-gray-700 hover:bg-white/70"
                  } backdrop-blur-sm group`}
                >
                  <Instagram className="w-5 h-5 text-pink-500 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">Instagram</span>
                </a>

                <a
                  href="#"
                  className={`flex items-center justify-center gap-3 p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                    isDark
                      ? "border-gray-700 bg-gray-800/50 text-gray-200 hover:bg-gray-700/50"
                      : "border-gray-200 bg-white/50 text-gray-700 hover:bg-white/70"
                  } backdrop-blur-sm group`}
                >
                  <FontAwesomeIcon
                    icon={faTiktok}
                    className="w-5 h-5 text-black group-hover:scale-110 transition-transform"
                  />
                  <span className="font-medium">TikTok</span>
                </a>

                <a
                  href="#"
                  className={`flex items-center justify-center gap-3 p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                    isDark
                      ? "border-gray-700 bg-gray-800/50 text-gray-200 hover:bg-gray-700/50"
                      : "border-gray-200 bg-white/50 text-gray-700 hover:bg-white/70"
                  } backdrop-blur-sm group`}
                >
                  <Youtube className="w-5 h-5 text-red-500 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">YouTube</span>
                </a>

                <a
                  href="#"
                  className={`flex items-center justify-center gap-3 p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 ${
                    isDark
                      ? "border-gray-700 bg-gray-800/50 text-gray-200 hover:bg-gray-700/50"
                      : "border-gray-200 bg-white/50 text-gray-700 hover:bg-white/70"
                  } backdrop-blur-sm group`}
                >
                  <MessageCircle className="w-5 h-5 text-blue-500 group-hover:scale-110 transition-transform" />
                  <span className="font-medium">Twitter</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUsPage;
