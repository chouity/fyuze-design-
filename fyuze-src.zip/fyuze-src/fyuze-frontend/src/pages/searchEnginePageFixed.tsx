import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  Search,
  Globe,
  Clock,
  ExternalLink,
  MapPin,
  RefreshCw,
} from "lucide-react";
import { useTheme } from "../contexts/ThemeContext";
import { useSearchEngine } from "../hooks/useSearchEngine";
import { useGeolocation } from "../hooks/useGeolocation";
import { LoadingSpinner } from "../components/common";

import SearchForm from "../Layout/searchengineinput";

import type { ForwardedRef } from "react";
import type { SearchFormProps } from "../Layout/searchengineinput";

// Move this outside the component to avoid remounting
const SearchFormComponent = React.forwardRef<
  HTMLTextAreaElement,
  SearchFormProps & { isCompact?: boolean }
>(
  (
    {
      query,
      setQuery,
      isCompact = false,
      isDark,
      isLoading,
      handleSubmit,
      handleKeyPress,
      animatedPlaceholder,
    },
    ref: ForwardedRef<HTMLTextAreaElement>
  ) => (
    <SearchForm
      ref={ref}
      query={query}
      setQuery={setQuery}
      isCompact={isCompact}
      isDark={isDark}
      isLoading={isLoading}
      handleSubmit={handleSubmit}
      handleKeyPress={handleKeyPress}
      animatedPlaceholder={animatedPlaceholder}
    />
  )
);

const SearchEnginePage: React.FC = () => {
  const { isDark } = useTheme();
  const { data, isLoading, error, searchEngine, reset } = useSearchEngine();
  const { location, countryCode, refetchLocation } = useGeolocation();
  const [query, setQuery] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [animatedPlaceholder, setAnimatedPlaceholder] =
    useState("Search the web...");

  const hasResults = (data && data.length > 0) || isLoading || error;

  // Animated placeholder effect
  useEffect(() => {
    const placeholders = [
      "Search the web...",
      "Find restaurants, hotels, services...",
      "Discover creators and influencers...",
      "Explore Lebanon and beyond...",
      "Ask anything, get instant results...",
    ];

    let currentIndex = 0;
    const interval = setInterval(() => {
      currentIndex = (currentIndex + 1) % placeholders.length;
      setAnimatedPlaceholder(placeholders[currentIndex]);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Focus textarea when component mounts
  useEffect(() => {
    if (textareaRef.current && !hasResults) {
      textareaRef.current.focus();
    }
  }, [hasResults]);

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      if (!query.trim()) return;
      await searchEngine(query.trim(), countryCode);
    },
    [query, countryCode, searchEngine]
  );

  const handleKeyPress = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSubmit(e);
      }
    },
    [handleSubmit]
  );

  const handleReset = () => {
    reset();
    setQuery("");
  };

  const getImageUrl = (originalUrl: string) => {
    if (!originalUrl) return "/default-avatar.png";
    return `https://images.weserv.nl/?url=${encodeURIComponent(
      originalUrl
    )}&w=200&h=200&fit=cover`;
  };

  const formatTime = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleString();
    } catch {
      return dateString;
    }
  };

  return (
    <div
      className={`min-h-screen transition-all duration-500 ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div
          className={`absolute top-20 left-20 w-72 h-72 rounded-full opacity-20 animate-pulse ${
            isDark
              ? "bg-gradient-to-r from-blue-500 to-purple-500"
              : "bg-gradient-to-r from-orange-400 to-red-400"
          } blur-3xl`}
        />
        <div
          className={`absolute bottom-20 right-20 w-96 h-96 rounded-full opacity-10 animate-pulse ${
            isDark
              ? "bg-gradient-to-r from-purple-500 to-pink-500"
              : "bg-gradient-to-r from-red-400 to-pink-400"
          } blur-3xl`}
          style={{ animationDelay: "2s" }}
        />
      </div>

      {!hasResults ? (
        <div className="relative z-10 flex flex-col justify-center min-h-screen px-4">
          <div className="max-w-4xl mx-auto w-full text-center">
            {/* Brand Header */}
            <div className="mb-12">
              <h1
                className={`text-6xl md:text-8xl font-bold mb-4 ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                <span
                  className={`text-transparent bg-clip-text ${
                    isDark
                      ? "bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400"
                      : "bg-gradient-to-r from-orange-600 via-red-600 to-pink-600"
                  } animate-pulse`}
                >
                  Search with Fyuze
                </span>
              </h1>
              <p
                className={`text-xl md:text-2xl font-medium ${
                  isDark ? "text-gray-300" : "text-gray-600"
                }`}
              >
                Search the web with intelligence
              </p>
            </div>

            {/* Main Search Form */}
            <div className="mb-8">
              <SearchFormComponent
                ref={textareaRef}
                query={query}
                setQuery={setQuery}
                isDark={isDark}
                isLoading={isLoading}
                handleSubmit={handleSubmit}
                handleKeyPress={handleKeyPress}
                animatedPlaceholder={animatedPlaceholder}
              />

              {/* Location Indicator */}
              {location && (
                <div className="flex items-center justify-center gap-3 mt-4 text-sm">
                  <div
                    className={`flex items-center gap-2 px-3 py-2 rounded-full ${
                      isDark
                        ? "bg-gray-800/50 text-gray-300 border border-gray-700/50"
                        : "bg-white/50 text-gray-600 border border-gray-300/50"
                    } backdrop-blur-sm`}
                  >
                    <MapPin className="w-4 h-4" />
                    <span>Searching from: {location.country}</span>
                  </div>
                  <button
                    onClick={refetchLocation}
                    className={`p-2 rounded-full transition-all duration-300 hover:scale-110 ${
                      isDark
                        ? "bg-gray-800/50 text-gray-400 hover:text-white border border-gray-700/50"
                        : "bg-white/50 text-gray-500 hover:text-gray-700 border border-gray-300/50"
                    } backdrop-blur-sm`}
                    title="Refresh location"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        // Results Layout - Google-like with search on top
        <div className="relative z-10">
          {/* Top Search Bar - Sticky */}
          <div className={`transition-all duration-300 `}>
            <div className="max-w-7xl mx-auto px-4 py-6 ">
              {/* Centered Layout */}
              <div className="flex flex-col items-center gap-6">
                {/* Logo Row */}
                <div className="flex items-center justify-center gap-3">
                  <button
                    onClick={handleReset}
                    className={`flex items-center gap-3 hover:opacity-80 transition-all duration-300 ${
                      isDark ? "text-white" : "text-gray-900"
                    }`}
                  >
                    <div
                      className={`p-2 rounded-full ${
                        isDark
                          ? "bg-gradient-to-r from-blue-600 to-purple-600"
                          : "bg-gradient-to-r from-orange-600 to-red-600"
                      }`}
                    >
                      <Search className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-2xl font-bold">
                      Search with Fyuze
                    </span>
                  </button>
                </div>

                {/* Centered Search Form */}
                <div className="w-full max-w-2xl">
                  <SearchFormComponent
                    ref={textareaRef}
                    query={query}
                    setQuery={setQuery}
                    isCompact={true}
                    isDark={isDark}
                    isLoading={isLoading}
                    handleSubmit={handleSubmit}
                    handleKeyPress={handleKeyPress}
                    animatedPlaceholder={animatedPlaceholder}
                  />

                  {/* Compact Location Indicator */}
                  {location && (
                    <div className="flex items-center justify-center gap-2 mt-3 text-xs">
                      <div
                        className={`flex items-center gap-1 px-2 py-1 rounded-full ${
                          isDark
                            ? "bg-gray-800/30 text-gray-400"
                            : "bg-white/30 text-gray-500"
                        } backdrop-blur-sm`}
                      >
                        <MapPin className="w-3 h-3" />
                        <span>{location.country}</span>
                      </div>
                      <button
                        onClick={refetchLocation}
                        className={`p-1 rounded-full transition-all duration-300 hover:scale-110 ${
                          isDark
                            ? "text-gray-500 hover:text-gray-300"
                            : "text-gray-400 hover:text-gray-600"
                        }`}
                        title="Refresh location"
                      >
                        <RefreshCw className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Results Container */}
          <div className="max-w-4xl mx-auto px-4 py-8">
            {/* Error State */}
            {error && (
              <div
                className={`p-6 mb-8 rounded-2xl border ${
                  isDark
                    ? "bg-red-900/20 border-red-700/50 text-red-300"
                    : "bg-red-50 border-red-200 text-red-700"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <p className="font-semibold">Search Error</p>
                </div>
                <p className="text-sm mt-2 opacity-80">{error}</p>
              </div>
            )}

            {/* Loading State */}
            {isLoading && (
              <div
                className={`flex flex-col items-center justify-center py-20 rounded-3xl ${
                  isDark
                    ? "bg-gradient-to-br from-gray-800/50 to-purple-900/20"
                    : "bg-gradient-to-br from-white/80 to-orange-50/80"
                } backdrop-blur-sm`}
              >
                <div className="relative">
                  <LoadingSpinner />
                  <div
                    className={`absolute inset-0 rounded-full animate-ping ${
                      isDark ? "bg-blue-500/20" : "bg-orange-500/20"
                    }`}
                  ></div>
                </div>
                <p
                  className={`mt-6 text-lg font-medium ${
                    isDark ? "text-gray-300" : "text-gray-700"
                  }`}
                >
                  Searching the web...
                </p>
                <p
                  className={`text-sm ${
                    isDark ? "text-gray-400" : "text-gray-500"
                  }`}
                >
                  Finding the best results for you
                </p>
              </div>
            )}

            {/* Results */}
            {data && data.length > 0 && (
              <div className="space-y-8">
                {/* Results Grid */}
                <div className="space-y-6">
                  {data.map((result, index) => (
                    <article
                      key={index}
                      className={`group p-8 rounded-3xl transition-all duration-500 transform hover:scale-[1.02] ${
                        isDark
                          ? "bg-gray-800/60 backdrop-blur-sm border border-gray-700/50 hover:bg-gray-800/80 hover:border-gray-600"
                          : "bg-white/80 backdrop-blur-sm border border-gray-200/50 hover:bg-white/90 hover:border-gray-300"
                      } shadow-xl hover:shadow-2xl`}
                    >
                      <div className="flex items-start gap-6">
                        {/* Thumbnail */}
                        {result.pagemap?.cse_thumbnail?.[0] && (
                          <div className="flex-shrink-0">
                            <div className="relative overflow-hidden rounded-2xl group-hover:scale-105 transition-transform duration-300">
                              <img
                                src={getImageUrl(
                                  result.pagemap.cse_thumbnail[0].src
                                )}
                                alt={result.title}
                                className="w-24 h-24 object-cover"
                                onError={(e) => {
                                  const target = e.target as HTMLImageElement;
                                  target.style.display = "none";
                                }}
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                            </div>
                          </div>
                        )}

                        <div className="flex-1 min-w-0">
                          {/* Title and Meta */}
                          <div className="flex items-start justify-between gap-6 mb-4">
                            <div className="flex-1">
                              <h3 className="text-xl font-bold mb-2 group-hover:scale-[1.01] transition-transform duration-300">
                                <a
                                  href={result.link}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className={`hover:underline transition-colors duration-200 ${
                                    isDark
                                      ? "text-blue-400 hover:text-blue-300"
                                      : "text-blue-600 hover:text-blue-800"
                                  }`}
                                  dangerouslySetInnerHTML={{
                                    __html: result.html_title,
                                  }}
                                />
                              </h3>
                              <div className="flex items-center gap-3 text-sm mb-3">
                                <span
                                  className={`flex items-center gap-2 px-3 py-1 rounded-full ${
                                    isDark
                                      ? "bg-gray-700/50 text-gray-300"
                                      : "bg-gray-100 text-gray-600"
                                  }`}
                                >
                                  <Globe className="w-3 h-3" />
                                  {result.display_link}
                                </span>
                                <span
                                  className={`flex items-center gap-2 px-3 py-1 rounded-full ${
                                    isDark
                                      ? "bg-gray-700/50 text-gray-300"
                                      : "bg-gray-100 text-gray-600"
                                  }`}
                                >
                                  <Clock className="w-3 h-3" />
                                  {formatTime(new Date().toISOString())}
                                </span>
                              </div>
                            </div>
                            <div
                              className={`p-3 rounded-full transition-all duration-300 group-hover:scale-110 ${
                                isDark ? "bg-gray-700/50" : "bg-gray-100"
                              }`}
                            >
                              <ExternalLink
                                className={`w-5 h-5 ${
                                  isDark ? "text-gray-400" : "text-gray-500"
                                }`}
                              />
                            </div>
                          </div>

                          {/* Snippet */}
                          <p
                            className={`text-base leading-relaxed mb-4 ${
                              isDark ? "text-gray-300" : "text-gray-700"
                            }`}
                            dangerouslySetInnerHTML={{
                              __html: result.html_snippet,
                            }}
                          />

                          {/* Meta Tags */}
                          {result.pagemap?.metatags?.[0] && (
                            <div className="flex flex-wrap gap-2">
                              {result.pagemap.metatags[0]["og:type"] && (
                                <span
                                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                                    isDark
                                      ? "bg-blue-900/30 text-blue-300 border border-blue-700/50"
                                      : "bg-blue-100 text-blue-800 border border-blue-200"
                                  }`}
                                >
                                  📄 {result.pagemap.metatags[0]["og:type"]}
                                </span>
                              )}
                              {result.pagemap.metatags[0]["article:author"] && (
                                <span
                                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                                    isDark
                                      ? "bg-green-900/30 text-green-300 border border-green-700/50"
                                      : "bg-green-100 text-green-800 border border-green-200"
                                  }`}
                                >
                                  ✍️{" "}
                                  {result.pagemap.metatags[0]["article:author"]}
                                </span>
                              )}
                              {result.pagemap.metatags[0]["twitter:site"] && (
                                <span
                                  className={`px-3 py-1 rounded-full text-xs font-medium ${
                                    isDark
                                      ? "bg-purple-900/30 text-purple-300 border border-purple-700/50"
                                      : "bg-purple-100 text-purple-800 border border-purple-200"
                                  }`}
                                >
                                  🐦{" "}
                                  {result.pagemap.metatags[0]["twitter:site"]}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              </div>
            )}

            {/* No Results */}
            {data && data.length === 0 && !isLoading && !error && (
              <div
                className={`text-center py-20 rounded-3xl ${
                  isDark
                    ? "bg-gradient-to-br from-gray-800/30 to-purple-900/10"
                    : "bg-gradient-to-br from-white/60 to-orange-50/60"
                } backdrop-blur-sm`}
              >
                <div
                  className={`w-16 h-16 mx-auto mb-6 rounded-full flex items-center justify-center ${
                    isDark ? "bg-gray-700/50" : "bg-gray-100"
                  }`}
                >
                  <Search
                    className={`w-8 h-8 ${
                      isDark ? "text-gray-400" : "text-gray-500"
                    }`}
                  />
                </div>
                <h3
                  className={`text-2xl font-bold mb-3 ${
                    isDark ? "text-white" : "text-gray-900"
                  }`}
                >
                  No results found
                </h3>
                <p
                  className={`text-lg ${
                    isDark ? "text-gray-400" : "text-gray-600"
                  }`}
                >
                  Try adjusting your search terms or check the spelling
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchEnginePage;
