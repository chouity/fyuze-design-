import React, { useState, useEffect } from "react";
import {
  Check,
  Clock,
  Star,
  Zap,
  Users,
  Crown,
  ArrowRight,
} from "lucide-react";
import { useTheme } from "../contexts/ThemeContext";
import { useAuth } from "../contexts/AuthContext";
import { SubscriptionService } from "../services/SubscriptionService";
import type {
  SubscriptionPlan,
  CurrentSubscription,
} from "../types/subscription";
import { useNavigate } from "react-router-dom";

const SubscriptionPlansPage: React.FC = () => {
  const { isDark } = useTheme();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [currentSubscription, setCurrentSubscription] =
    useState<CurrentSubscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">(
    "monthly"
  );
  const [choosingPlan, setChoosingPlan] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, [user]);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError("");
      if (!user) {
        setError("Please sign in to view subscription plans");
        setLoading(false);
        return;
      }

      const [plansResponse, currentSubResponse] = await Promise.all([
        SubscriptionService.getSubscriptionPlans(),
        SubscriptionService.getCurrentSubscription(),
      ]);

      if (plansResponse.data) {
        setPlans(plansResponse.data);
      }

      if (currentSubResponse.subscription) {
        setCurrentSubscription(currentSubResponse.subscription);
      }
    } catch (err: any) {
      if (err.message?.includes("authenticated")) {
        setError("Please sign in to view subscription plans");
      } else {
        setError("Failed to load subscription plans");
      }
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleChoosePlan = async (planCode: string) => {
    if (!user) return;

    try {
      setChoosingPlan(planCode);
      const response = await SubscriptionService.chooseSubscriptionPlan(
        planCode
      );

      if (response.status === "success") {
        // Refresh current subscription data
        await fetchData();
        // Navigate back to main app
        navigate("/app");
      }
    } catch (err: any) {
      if (err.message?.includes("authenticated")) {
        setError("Please sign in to choose a subscription plan");
      } else {
        setError("Failed to choose subscription plan");
      }
      console.error(err);
    } finally {
      setChoosingPlan(null);
    }
  };

  const getPlanIcon = (planCode: string) => {
    const code = planCode.toLowerCase();
    if (code.includes("free") || code.includes("trial")) return Clock;
    if (code.includes("pro") || code.includes("premium")) return Star;
    if (code.includes("ent") || code.includes("enterprise")) return Crown;
    return Zap;
  };



  // Show sign-in message if user is not authenticated
  if (!user && !loading) {
    return (
      <div
        className={`min-h-screen transition-all duration-500 ${
          isDark
            ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
            : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
        }  
     flex items-center justify-center p-4`}
      >
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <img
              src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
              alt="Fyuze Logo"
              className="w-16 h-16"
            />
          </div>
          <h1
            className={`text-3xl font-bold mb-4 ${
              isDark ? "text-white" : "text-gray-900"
            }`}
          >
            Sign In Required
          </h1>
          <p
            className={`text-lg mb-8 ${
              isDark ? "text-gray-300" : "text-gray-600"
            }`}
          >
            Please sign in to view and manage your subscription plans.
          </p>
          <button
            onClick={() => navigate("/")}
            className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-xl font-bold transition-all duration-300 transform hover:scale-105"
          >
            Go to Sign In
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div
        className={`min-h-screen transition-all duration-500 ${
          isDark
            ? "bg-gradient-to-br from-gray-900 to-purple-900"
            : "bg-gradient-to-br from-orange-50 to-red-50"
        } flex items-center justify-center p-4`}
      >
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className={isDark ? "text-gray-300" : "text-gray-600"}>
            Loading subscription plans...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen transition-all duration-500 ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }
     relative overflow-hidden`}
    >
      {/* Background Animation */}
      <div className="absolute inset-0 overflow-hidden">
        <div
          className={`absolute -top-40 -right-40 w-96 h-96 ${
            isDark ? "bg-blue-500/20" : "bg-indigo-300/30"
          } rounded-full mix-blend-multiply filter blur-3xl animate-pulse`}
        ></div>
        <div
          className={`absolute -bottom-40 -left-40 w-96 h-96 ${
            isDark ? "bg-purple-500/20" : "bg-purple-300/30"
          } rounded-full mix-blend-multiply filter blur-3xl animate-pulse`}
        ></div>
        <div
          className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 ${
            isDark ? "bg-orange-500/10" : "bg-orange-200/20"
          } rounded-full mix-blend-multiply filter blur-3xl animate-pulse`}
        ></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <img
                src="https://uvkmqudmpsvalegqlqod.supabase.co/storage/v1/object/public/public_images/fyuzelogo.png"
                alt="Fyuze Logo"
                className="w-16 h-16"
              />
            </div>
          </div>
          {/* Platform Pricing Badge */}
          <div className="inline-block mb-6">
            <div
              className={`px-4 py-2 rounded-full text-sm font-semibold ${
                isDark
                  ? "bg-blue-900/50 text-blue-300 border border-blue-700/50"
                  : "bg-blue-100 text-blue-700 border border-blue-200"
              }`}
            >
              Platform Pricing
            </div>
          </div>

          <h1
            className={`text-4xl md:text-6xl font-bold mb-6 leading-tight ${
              isDark ? "text-white" : "text-gray-900"
            }`}
          >
            Get AI-matched leads flowing with
            <br />
            <span className="bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">
              25% extra credits
            </span>{" "}
            <span className={isDark ? "text-gray-400" : "text-gray-600"}>
              on annual plans
            </span>
          </h1>

          {/* Countdown Timer */}
          <div className="mb-12">
            <div
              className={`inline-flex items-center px-6 py-3 rounded-xl ${
                isDark
                  ? "bg-gray-800/50 text-gray-300"
                  : "bg-white/70 text-gray-700"
              } backdrop-blur-sm border ${
                isDark ? "border-gray-700/50" : "border-white/50"
              }`}
            >
              <Clock className="w-5 h-5 mr-2" />
              Offer ends in 20 days 9h 53m
            </div>
          </div>

          <p
            className={`text-lg mb-8 ${
              isDark ? "text-gray-300" : "text-gray-600"
            }`}
          >
            Find the perfect plan for your needs
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center mb-8">
            <div
              className={`flex p-1 rounded-xl ${
                isDark ? "bg-gray-800" : "bg-white"
              } shadow-lg`}
            >
              <button
                onClick={() => setBillingCycle("monthly")}
                className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 ${
                  billingCycle === "monthly"
                    ? isDark
                      ? "bg-gray-700 text-white"
                      : "bg-gray-100 text-gray-900"
                    : isDark
                    ? "text-gray-400 hover:text-white"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingCycle("annual")}
                className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 relative ${
                  billingCycle === "annual"
                    ? isDark
                      ? "bg-orange-600 text-white"
                      : "bg-orange-600 text-white"
                    : isDark
                    ? "text-gray-400 hover:text-white"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Annual - Save 25%
                {billingCycle === "annual" && (
                  <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded-full">
                    Save 25%
                  </div>
                )}
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="text-center mb-8">
            <div className="text-red-400 bg-red-500/10 border border-red-500/20 p-4 rounded-xl backdrop-blur-sm inline-block">
              {error}
            </div>
          </div>
        )}

        {/* Current Subscription Banner */}
        {currentSubscription && (
          <div className="text-center mb-8">
            <div
              className={`inline-flex items-center gap-2 px-6 py-3 rounded-xl ${
                isDark
                  ? "bg-green-900/30 border border-green-500/30 text-green-400"
                  : "bg-green-50 border border-green-200 text-green-700"
              }`}
            >
              <Check className="w-5 h-5" />
              <span className="font-semibold">
                Current Plan: {currentSubscription.plan_name}
              </span>
            </div>
          </div>
        )}

        {/* Plans Grid */}
        <div className="flex justify-center items-center min-h-[700px] py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto px-4">
            {plans.slice(0, 3).map((plan) => {
              const PlanIcon = getPlanIcon(plan.code);
              const isPopular =
                plan.code.toLowerCase().includes("pro") ||
                plan.code.toLowerCase().includes("premium");
              const isCurrentPlan =
                currentSubscription?.plan_name === plan.name;
              const isChoosing = choosingPlan === plan.code;
              const isFree =
                plan.code.toLowerCase().includes("free") ||
                plan.code.toLowerCase().includes("trial");
              const isEnterprise =
                plan.code.toLowerCase().includes("ent") ||
                plan.code.toLowerCase().includes("enterprise");

              return (
                <div
                  key={plan.id}
                  className={`relative rounded-3xl transition-all duration-500 transform hover:scale-[1.02] hover:shadow-3xl ${
                    isPopular
                      ? `${
                          isDark
                            ? "bg-gradient-to-br from-gray-800/90 via-blue-900/90 to-purple-900/90 border-2 border-blue-400/50"
                            : "bg-gradient-to-br from-white via-blue-50/80 to-purple-50/80 border-2 border-blue-400/50"
                        } 
                         shadow-2xl shadow-blue-500/20 scale-[1.05] z-10`
                      : isFree
                      ? `${
                          isDark
                            ? "bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-600/50"
                            : "bg-gradient-to-br from-white to-gray-50/80 border border-gray-200/50"
                        } 
                         shadow-lg`
                      : isEnterprise
                      ? `${
                          isDark
                            ? "bg-gradient-to-br from-gray-800/80 via-orange-900/30 to-red-900/30 border border-orange-500/50"
                            : "bg-gradient-to-br from-white via-orange-50/80 to-red-50/80 border border-orange-300/50"
                        } 
                         shadow-lg`
                      : `${
                          isDark
                            ? "bg-gradient-to-br from-gray-800/80 to-gray-900/80 border border-gray-600/50"
                            : "bg-gradient-to-br from-white to-gray-50/80 border border-gray-200/50"
                        } 
                         shadow-lg`
                  } backdrop-blur-xl ${
                    isCurrentPlan ? "ring-2 ring-green-400/50" : ""
                  }`}
                  style={{
                    minHeight: isPopular ? "640px" : "600px",
                    padding: isPopular ? "2.5rem" : "2rem",
                  }}
                >
                  {/* Popular Badge */}
                  {isPopular && (
                    <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 z-20 bg-gradient-to-r from-orange-500 to-pink-500 text-white  px-8 py-2 rounded-full text-sm font-bold shadow-xl ">
                      Most Popular
                    </div>
                  )}

                  {/* Save 25% Badge for Annual */}
                  {billingCycle === "annual" && !isFree && (
                    <div className="absolute -top-3 -right-3 z-20">
                      <div className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs px-3 py-1 rounded-full font-bold shadow-lg animate-pulse">
                        Save 25%
                      </div>
                    </div>
                  )}

                  {/* Plan Name and Icon */}
                  <div className="text-center mb-8">
                    <div className="flex justify-center mb-4">
                      <div
                        className={`p-4 rounded-2xl transition-all duration-300 ${
                          isPopular
                            ? "bg-gradient-to-br from-blue-500/10 to-purple-500/10"
                            : isFree
                            ? isDark
                              ? "bg-gray-700/30"
                              : "bg-gray-100/50"
                            : isDark
                            ? "bg-gray-700/30"
                            : "bg-gray-100/50"
                        }`}
                      >
                        <PlanIcon
                          className={`w-8 h-8 ${
                            isPopular
                              ? "text-blue-500"
                              : isFree
                              ? isDark
                                ? "text-gray-400"
                                : "text-gray-500"
                              : isDark
                              ? "text-purple-400"
                              : "text-purple-600"
                          }`}
                        />
                      </div>
                    </div>

                    <h3
                      className={`text-3xl font-bold mb-3 ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      {plan.name}
                    </h3>

                    <p
                      className={`text-lg mb-6 ${
                        isDark ? "text-gray-300" : "text-gray-600"
                      } max-w-xs mx-auto`}
                    >
                      {plan.description}
                    </p>
                  </div>

                  {/* Price */}
                  <div className="text-center mb-8">
                    {billingCycle === "annual" && plan.price > 0 && (
                      <div className="mb-2">
                        <span
                          className={`text-lg line-through ${
                            isDark ? "text-gray-500" : "text-gray-400"
                          }`}
                        >
                          ${Math.round(plan.price * 1.25)}/month
                        </span>
                      </div>
                    )}
                    <div className="mb-2">
                      <span
                        className={`text-6xl font-bold ${
                          isDark ? "text-white" : "text-gray-900"
                        }`}
                      >
                        {plan.price === 0
                          ? "$0"
                          : `$${
                              billingCycle === "annual"
                                ? Math.floor(plan.price * 0.75)
                                : plan.price
                            }`}
                      </span>
                    </div>
                    {plan.price > 0 && (
                      <div
                        className={`text-lg ${
                          isDark ? "text-gray-400" : "text-gray-500"
                        }`}
                      >
                        Per month -{" "}
                        {billingCycle === "annual"
                          ? "annual billing"
                          : "monthly billing"}
                      </div>
                    )}
                    {plan.price === 0 && (
                      <div
                        className={`text-lg ${
                          isDark ? "text-gray-400" : "text-gray-500"
                        }`}
                      >
                        No credit card required
                      </div>
                    )}
                  </div>

                  {/* Credits */}
                  <div className="text-center mb-8">
                    <div
                      className={`text-3xl font-bold mb-2 bg-gradient-to-r ${
                        isPopular
                          ? "from-blue-500 to-purple-600 bg-clip-text text-transparent"
                          : isDark
                          ? "text-white"
                          : "text-gray-900"
                      }`}
                    >
                      {billingCycle === "annual" && plan.price > 0
                        ? Math.floor(
                            plan.monthly_points + plan.monthly_points * 0.25
                          ).toLocaleString()
                        : plan.monthly_points?.toLocaleString()}{" "}
                      credits
                    </div>
                    <div
                      className={`text-sm ${
                        isDark ? "text-gray-400" : "text-gray-600"
                      }`}
                    >
                      / year
                    </div>
                    {billingCycle === "annual" && plan.price > 0 && (
                      <div
                        className={`text-sm mt-2 font-semibold ${
                          isDark ? "text-green-400" : "text-green-600"
                        }`}
                      >
                        +{" "}
                        {Math.floor(
                          plan.monthly_points * 0.25
                        ).toLocaleString()}{" "}
                        bonus credits
                      </div>
                    )}
                    <div className="flex items-center justify-center mt-4 text-sm gap-2">
                      <span
                        className={`px-3 py-1 rounded-full ${
                          isDark
                            ? "bg-gray-700/50 text-gray-300"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        ≈ {Math.floor(plan.monthly_points / 30)} emails
                      </span>
                      <span
                        className={`px-3 py-1 rounded-full ${
                          isDark
                            ? "bg-gray-700/50 text-gray-300"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {Math.floor(plan.monthly_points / 200)} phones
                      </span>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="space-y-3 mb-8">
                    {/* Example features - you can expand this based on your features data */}
                    <div className="flex items-center gap-3">
                      <Check
                        className={`w-5 h-5 ${
                          isDark ? "text-green-400" : "text-green-600"
                        }`}
                      />
                      <span
                        className={`text-sm ${
                          isDark ? "text-gray-300" : "text-gray-600"
                        }`}
                      >
                        AI-powered search
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Check
                        className={`w-5 h-5 ${
                          isDark ? "text-green-400" : "text-green-600"
                        }`}
                      />
                      <span
                        className={`text-sm ${
                          isDark ? "text-gray-300" : "text-gray-600"
                        }`}
                      >
                        Creator analytics
                      </span>
                    </div>
                    {plan.code.toLowerCase().includes("pro") && (
                      <div className="flex items-center gap-3">
                        <Check
                          className={`w-5 h-5 ${
                            isDark ? "text-green-400" : "text-green-600"
                          }`}
                        />
                        <span
                          className={`text-sm ${
                            isDark ? "text-gray-300" : "text-gray-600"
                          }`}
                        >
                          Priority support
                        </span>
                      </div>
                    )}
                    {plan.code.toLowerCase().includes("ent") && (
                      <div className="flex items-center gap-3">
                        <Check
                          className={`w-5 h-5 ${
                            isDark ? "text-green-400" : "text-green-600"
                          }`}
                        />
                        <span
                          className={`text-sm ${
                            isDark ? "text-gray-300" : "text-gray-600"
                          }`}
                        >
                          Dedicated support
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Action Button */}
                  <div className="mt-auto">
                    <button
                      onClick={() => handleChoosePlan(plan.code)}
                      disabled={isCurrentPlan || isChoosing}
                      className={`w-full py-4 px-6 rounded-2xl font-bold text-lg transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed relative overflow-hidden group ${
                        isCurrentPlan
                          ? "bg-green-600 text-white shadow-lg"
                          : isPopular
                          ? "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-2xl hover:shadow-blue-500/25"
                          : isFree
                          ? isDark
                            ? "bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white"
                            : "bg-gradient-to-r from-gray-800 to-gray-900 hover:from-gray-700 hover:to-gray-800 text-white"
                          : isDark
                          ? "bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-500 hover:to-gray-600 text-white"
                          : "bg-gray-900 hover:bg-gray-800 text-white"
                      } shadow-lg hover:shadow-xl`}
                    >
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        {isChoosing ? (
                          <>
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                            <span>Please wait...</span>
                          </>
                        ) : isCurrentPlan ? (
                          <>
                            <Check className="w-5 h-5" />
                            <span>Current Plan</span>
                          </>
                        ) : (
                          <>
                            <span>Choose plan</span>
                            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                          </>
                        )}
                      </span>
                      {!isCurrentPlan && !isChoosing && isPopular && (
                        <div className="absolute inset-0 bg-gradient-to-r from-blue-700 to-purple-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl"></div>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Custom Plan */}
        <div className="mt-12 text-center">
          <div
            className={`inline-flex items-center gap-4 p-8 rounded-3xl ${
              isDark
                ? "bg-gray-900/80 border border-gray-700/50"
                : "bg-white/80 border border-gray-200"
            } backdrop-blur-xl shadow-2xl`}
          >
            <div
              className={`p-4 rounded-2xl ${
                isDark ? "bg-gray-800/50" : "bg-gray-100"
              }`}
            >
              <Users
                className={`w-8 h-8 ${
                  isDark ? "text-orange-400" : "text-orange-600"
                }`}
              />
            </div>
            <div className="text-left">
              <h3
                className={`text-2xl font-bold mb-2 ${
                  isDark ? "text-orange-400" : "text-orange-600"
                }`}
              >
                Custom
              </h3>
              <p
                className={`${isDark ? "text-gray-300" : "text-gray-600"} mb-4`}
              >
                For agencies, enterprises, or advanced needs
              </p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Check
                    className={`w-4 h-4 ${
                      isDark ? "text-green-400" : "text-green-600"
                    }`}
                  />
                  <span className={isDark ? "text-gray-300" : "text-gray-600"}>
                    Unlimited seats
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Check
                    className={`w-4 h-4 ${
                      isDark ? "text-green-400" : "text-green-600"
                    }`}
                  />
                  <span className={isDark ? "text-gray-300" : "text-gray-600"}>
                    All credits upfront
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Check
                    className={`w-4 h-4 ${
                      isDark ? "text-green-400" : "text-green-600"
                    }`}
                  />
                  <span className={isDark ? "text-gray-300" : "text-gray-600"}>
                    Dedicated CSM
                  </span>
                </div>
              </div>
            </div>
            <div className="text-center">
              <div
                className={`text-4xl font-bold mb-4 ${
                  isDark ? "text-white" : "text-gray-900"
                }`}
              >
                Let's talk
              </div>
              <p
                className={`text-sm mb-6 ${
                  isDark ? "text-gray-400" : "text-gray-600"
                }`}
              >
                Custom pricing
              </p>
              <button
                onClick={() => navigate("/contactus")}
                className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-3 rounded-xl font-bold transition-all duration-300 transform hover:scale-105"
              >
                Choose plan
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12">
          <button
            onClick={() => navigate("/app")}
            className={`${
              isDark
                ? "text-purple-400 hover:text-purple-300"
                : "text-purple-600 hover:text-purple-700"
            } font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer`}
          >
            ← Back to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPlansPage;
