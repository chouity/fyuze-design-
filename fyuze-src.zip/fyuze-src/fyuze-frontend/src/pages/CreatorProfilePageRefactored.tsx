/**
 * CREATOR PROFILE PAGE - PLATFORM AGNOSTIC
 *
 * Refactored to use the platform abstraction layer for dynamic
 * handling of different social media platforms.
 *
 * @author Fyuze Team
 * @version 2.0.0
 */

import React, { useState, useCallback, useMemo } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { useTheme } from "../contexts/ThemeContext";
import { useCreator } from "../hooks";
import { LoadingSpinner } from "../components/common";
import { platformService } from "../services/PlatformService";
import type {
  PlatformCreatorProfile,
  DataSourceType,
} from "../types/platform.types";

// UI Components
import {
  ProfileHeader,
  ProfileStats,
  ProfilePosts,
  ProfileInsights,
} from "../components/profile";

// Icons
import { ArrowLeft, AlertCircle } from "lucide-react";

interface LocationState {
  creator?: any;
  dataSource?: DataSourceType;
}

const CreatorProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { isDark } = useTheme();

  // State management
  const [selectedPost, setSelectedPost] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Get creator data from navigation state
  const locationState = location.state as LocationState;
  const creatorFromState = locationState?.creator;
  const dataSourceFromState = locationState?.dataSource;

  // Fetch creator data if not provided via navigation state
  const {
    data: creatorData,
    isLoading: loading,
    error,
  } = useCreator(id || "", {
    enabled: !creatorFromState,
  });

  // Process creator data using platform service
  const profileData = useMemo((): PlatformCreatorProfile | null => {
    const rawCreator =
      creatorFromState ||
      (creatorData &&
      typeof creatorData === "object" &&
      "status" in creatorData &&
      (creatorData as any).status === "success"
        ? (creatorData as any).data?.rows?.[0]
        : null);

    if (!rawCreator) return null;

    // Detect platform
    const platform =
      platformService.detectPlatform(rawCreator) || rawCreator.platform;
    if (!platform) {
      console.error("Could not detect platform for creator:", rawCreator);
      return null;
    }

    // Determine data source
    const dataSource: DataSourceType =
      dataSourceFromState ||
      creatorFromState?.dataSource ||
      (creatorFromState ? "ai_search" : "database");

    // Extract profile using platform service
    const result = platformService.extractCreatorProfile(
      rawCreator,
      platform,
      dataSource
    );

    if (!result.success) {
      console.error("Failed to extract creator profile:", result.errors);
      return null;
    }

    return result.profile;
  }, [creatorFromState, creatorData, dataSourceFromState]);

  // Event handlers
  const handlePostClick = useCallback((post: any) => {
    setSelectedPost(post);
    setIsModalOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedPost(null);
  }, []);

  // Loading state
  if (loading && !creatorFromState) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center ${
          isDark
            ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
            : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
        }`}
      >
        <LoadingSpinner
          size="lg"
          text="Loading creator profile..."
          fullScreen
        />
      </div>
    );
  }

  // Error state
  if (error && !creatorFromState) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center ${
          isDark
            ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
            : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
        }`}
      >
        <div className="text-center">
          <AlertCircle
            className={`w-8 h-8 mx-auto mb-4 ${
              isDark ? "text-red-400" : "text-red-600"
            }`}
          />
          <p
            className={`text-lg mb-4 ${
              isDark ? "text-gray-300" : "text-gray-700"
            }`}
          >
            Failed to load creator profile
          </p>
          <p
            className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}
          >
            {error.message || "Please try again later"}
          </p>
          <button
            onClick={() => navigate(-1)}
            className={`mt-4 px-4 py-2 rounded-lg font-medium transition-colors ${
              isDark
                ? "bg-gray-700 hover:bg-gray-600 text-gray-300"
                : "bg-gray-200 hover:bg-gray-300 text-gray-700"
            }`}
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  // No creator found state
  if (!profileData) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center ${
          isDark
            ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
            : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
        }`}
      >
        <div className="text-center">
          <AlertCircle
            className={`w-8 h-8 mx-auto mb-4 ${
              isDark ? "text-red-400" : "text-red-600"
            }`}
          />
          <p
            className={`text-lg mb-4 ${
              isDark ? "text-gray-300" : "text-gray-700"
            }`}
          >
            Creator not found
          </p>
          <p
            className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}
          >
            The creator you're looking for doesn't exist or has been removed.
          </p>
          <button
            onClick={() => navigate(-1)}
            className={`mt-4 px-4 py-2 rounded-lg font-medium transition-colors ${
              isDark
                ? "bg-gray-700 hover:bg-gray-600 text-gray-300"
                : "bg-gray-200 hover:bg-gray-300 text-gray-700"
            }`}
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`min-h-full ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => navigate(-1)}
            className={`p-2 rounded-lg transition-colors ${
              isDark
                ? "hover:bg-gray-700 text-gray-300 hover:text-white"
                : "hover:bg-gray-100 text-gray-600 hover:text-gray-900"
            }`}
            title="Go Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1
              className={`text-2xl font-bold ${
                isDark ? "text-white" : "text-gray-900"
              }`}
            >
              Creator Profile
            </h1>
            <p
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              }`}
            >
              {profileData.platform.charAt(0).toUpperCase() +
                profileData.platform.slice(1)}{" "}
              • Detailed information and analytics
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="space-y-8">
          {/* Profile Header */}
          <ProfileHeader profile={profileData} />

          {/* Stats Grid */}
          <ProfileStats profile={profileData} />

          {/* Engagement Insights */}
          <ProfileInsights profile={profileData} />

          {/* Recent Posts */}
          <ProfilePosts profile={profileData} onPostClick={handlePostClick} />
        </div>
      </div>

      {/* Post Modal */}
      {isModalOpen && selectedPost && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div
            className={`max-w-4xl w-full max-h-[90vh] overflow-auto rounded-lg ${
              isDark ? "bg-gray-800" : "bg-white"
            }`}
          >
            {/* Modal content would go here */}
            <div className="p-6">
              <button
                onClick={closeModal}
                className="float-right text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
              <h3 className="text-lg font-semibold mb-4">Post Details</h3>
              {/* Post content */}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreatorProfilePage;
