import { useState, useEffect } from "react";
import { Check, Info } from "lucide-react";
import { useTheme } from "../contexts/ThemeContext";
import { useAuth } from "../contexts/AuthContext";
import { SubscriptionService } from "../services/SubscriptionService";
import type {
  SubscriptionPlan,
  CurrentSubscription,
} from "../types/subscription";
import { useNavigate } from "react-router-dom";

export default function PricingPage() {
  const { isDark } = useTheme();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [currentSubscription, setCurrentSubscription] =
    useState<CurrentSubscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [isAnnual, setIsAnnual] = useState(true);
  const [sliderValue, setSliderValue] = useState(2);
  const [choosingPlan, setChoosingPlan] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, [user]);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError("");
      if (!user) {
        setError("Please sign in to view subscription plans");
        setLoading(false);
        return;
      }

      const [plansResponse, currentSubResponse] = await Promise.all([
        SubscriptionService.getSubscriptionPlans(),
        SubscriptionService.getCurrentSubscription(),
      ]);

      if (plansResponse.data) {
        setPlans(plansResponse.data);
      }

      if (currentSubResponse.subscription) {
        setCurrentSubscription(currentSubResponse.subscription);
      }
    } catch (err: any) {
      if (err.message?.includes("authenticated")) {
        setError("Please sign in to view subscription plans");
      } else {
        setError("Failed to load subscription plans");
      }
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleChoosePlan = async (planCode: string) => {
    if (!user) return;

    try {
      setChoosingPlan(planCode);
      const response = await SubscriptionService.chooseSubscriptionPlan(
        planCode
      );

      if (response.status === "success") {
        // Refresh current subscription data
        await fetchData();
        // Navigate back to main app
        navigate("/app");
      }
    } catch (err: any) {
      if (err.message?.includes("authenticated")) {
        setError("Please sign in to choose a subscription plan");
      } else {
        setError("Failed to choose subscription plan");
      }
      console.error(err);
    } finally {
      setChoosingPlan(null);
    }
  };

  const activeIndex = Math.min(sliderValue, plans.length - 1);
  return (
    <div
      className={`relative flex flex-col w-full min-h-screen transition-all duration-500 overflow-auto ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      {/* Header */}
      <div className="text-center pt-16 pb-8 px-4">
        <div
          className={`text-sm font-medium mb-4 ${
            isDark ? "text-purple-300" : "text-orange-700"
          }`}
        >
          Platform Pricing
        </div>
        <h1
          className={`text-4xl md:text-6xl font-bold mb-4 ${
            isDark ? "text-white" : "text-gray-900"
          }`}
        >
          Get AI-matched leads flowing with
        </h1>
        <div className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-orange-400 to-pink-500 bg-clip-text text-transparent mb-6">
          25% extra credits
        </div>
        <div
          className={`text-xl ${isDark ? "text-gray-300" : "text-gray-700"}`}
        >
          Offer ends in 17 days 10h 16m
        </div>
      </div>

      {/* Billing Toggle */}
      <div className="flex justify-center mb-12 relative">
        <div
          className={`flex gap-2 p-1 rounded-lg ${
            isDark ? "bg-gray-800/50" : "bg-white/50"
          } backdrop-blur-sm`}
        >
          <button
            onClick={() => setIsAnnual(false)}
            className={`px-6 py-2 rounded-md transition-all ${
              !isAnnual
                ? "bg-white text-gray-900 shadow-lg"
                : isDark
                ? "text-gray-300"
                : "text-gray-700"
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => setIsAnnual(true)}
            className={`px-6 py-2 rounded-md transition-all ${
              isAnnual
                ? "bg-blue-500 text-white shadow-lg"
                : isDark
                ? "text-gray-300"
                : "text-gray-700"
            }`}
          >
            Annual – Save 25%
          </button>
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center py-16">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className={isDark ? "text-gray-300" : "text-gray-600"}>
              Loading subscription plans...
            </p>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && !loading && (
        <div className="text-center mb-8">
          <div className="text-red-400 bg-red-500/10 border border-red-500/20 p-4 rounded-xl backdrop-blur-sm inline-block">
            {error}
          </div>
        </div>
      )}

      {/* Current Subscription Banner */}
      {currentSubscription && !loading && (
        <div className="text-center mb-8">
          <div
            className={`inline-flex items-center gap-2 px-6 py-3 rounded-xl ${
              isDark
                ? "bg-green-900/30 border border-green-500/30 text-green-400"
                : "bg-green-50 border border-green-200 text-green-700"
            }`}
          >
            <Check className="w-5 h-5" />
            <span className="font-semibold">
              Current Plan: {currentSubscription.plan_name}
            </span>
          </div>
        </div>
      )}

      {/* Interactive Slider */}
      {!loading && !error && (
        <div className="px-8 md:px-16 mb-12">
          <div className="flex justify-between items-center mb-4">
            <div
              className={`text-lg font-medium ${
                isDark ? "text-white" : "text-gray-900"
              }`}
            >
              Find the perfect plan for your needs
            </div>
            <button
              className={`text-sm ${
                isDark ? "text-gray-400" : "text-gray-600"
              } flex items-center gap-1`}
            >
              How our credits work <Info size={16} />
            </button>
          </div>
          <div className="relative">
            <input
              type="range"
              min="0"
              max={Math.max(0, plans.length - 1)}
              step="1"
              value={sliderValue}
              onChange={(e) => setSliderValue(Number(e.target.value))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
              style={{
                background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${
                  plans.length > 0
                    ? (sliderValue / (plans.length - 1)) * 100
                    : 0
                }%, #374151 ${
                  plans.length > 0
                    ? (sliderValue / (plans.length - 1)) * 100
                    : 0
                }%, #374151 100%)`,
              }}
            />
            <div className="flex justify-between mt-2">
              {plans.map((plan, idx) => (
                <div
                  key={plan.id}
                  className={`text-sm transition-all ${
                    idx === sliderValue
                      ? isDark
                        ? "text-blue-400 font-bold"
                        : "text-orange-600 font-bold"
                      : isDark
                      ? "text-gray-500"
                      : "text-gray-600"
                  }`}
                >
                  {plan.name}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Pricing Cards */}
      {!loading && !error && (
        <div className="flex justify-center">
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-10 px-8 md:px-16 pb-16">
            {plans.map((plan, idx) => {
              const isActive = idx === activeIndex;
              const isFocused = Math.abs(idx - activeIndex) <= 0;
              const isChoosing = choosingPlan === plan.code;

              return (
                <div
                  key={plan.id}
                  className={`relative rounded-2xl p-6 transition-all duration-500 transform ${
                    isActive
                      ? isDark
                        ? "bg-gradient-to-br from-blue-900/50 to-purple-900/50 border-2 border-blue-500 scale-105 shadow-2xl shadow-blue-500/50"
                        : "bg-gradient-to-br from-orange-200 to-pink-200 border-2 border-orange-500 scale-105 shadow-2xl shadow-orange-500/50"
                      : isDark
                      ? "bg-gray-800/40 border border-gray-700"
                      : "bg-white/40 border border-gray-300"
                  } ${
                    isFocused ? "opacity-100" : "opacity-60"
                  } backdrop-blur-sm`}
                >
                  {/* Plan Name */}
                  <div
                    className={`text-2xl font-bold mb-2 ${
                      isDark ? "text-white" : "text-gray-900"
                    }`}
                  >
                    {plan.name}
                  </div>

                  {/* Price */}
                  <div className="mb-4">
                    <span
                      className={`text-4xl font-bold ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      ${plan.price}
                    </span>
                    <span
                      className={`text-sm ml-2 ${
                        isDark ? "text-gray-400" : "text-gray-600"
                      }`}
                    >
                      Per {plan.billing_cycle}
                    </span>
                  </div>

                  {/* Credits */}
                  <div
                    className={`text-sm mb-4 ${
                      isDark ? "text-gray-400" : "text-gray-600"
                    }`}
                  >
                    {plan.monthly_points.toLocaleString()} credits / month
                  </div>

                  {/* Description */}
                  <p
                    className={`text-sm mb-6 ${
                      isDark ? "text-gray-400" : "text-gray-600"
                    }`}
                  >
                    {plan.description}
                  </p>

                  {/* Choose Plan Button */}
                  <button
                    onClick={() => handleChoosePlan(plan.code)}
                    disabled={isChoosing}
                    className={`w-full py-3 rounded-lg font-medium transition-all mb-6 ${
                      isActive
                        ? "bg-blue-500 text-white hover:bg-blue-600 shadow-lg"
                        : isDark
                        ? "bg-gray-700 text-white hover:bg-gray-600"
                        : "bg-gray-200 text-gray-900 hover:bg-gray-300"
                    } ${isChoosing ? "opacity-50 cursor-not-allowed" : ""}`}
                  >
                    {isChoosing ? "Choosing..." : "Choose plan →"}
                  </button>

                  {/* Features */}
                  <div className="space-y-3">
                    {Object.entries(plan.features).map(
                      ([key, value], featureIdx) => (
                        <div
                          key={featureIdx}
                          className={`flex items-start gap-2 text-sm ${
                            isDark ? "text-gray-300" : "text-gray-700"
                          }`}
                        >
                          <Check
                            size={16}
                            className={`mt-0.5 flex-shrink-0 ${
                              isActive ? "text-blue-400" : "text-gray-500"
                            }`}
                          />
                          <span>
                            {key}: {String(value)}
                          </span>
                        </div>
                      )
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <style>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #3b82f6;
          cursor: pointer;
          box-shadow: 0 0 10px rgba(59, 130, 246, 0.5);
        }

        .slider::-moz-range-thumb {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: #3b82f6;
          cursor: pointer;
          border: none;
          box-shadow: 0 0 10px rgba(59, 130, 246, 0.5);
        }
      `}</style>
    </div>
  );
}
