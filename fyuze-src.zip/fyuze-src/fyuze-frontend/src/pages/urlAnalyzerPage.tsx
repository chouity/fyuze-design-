import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import { useTheme } from "../contexts/ThemeContext";
import { useUrlAnalyzer } from "../hooks";
import { LoadingSpinner } from "../components/common";
import {
  Globe,
  Search,
  ExternalLink,
  Building,
  Target,
  Phone,
  FileText,
  ArrowRight,
  CheckCircle,
  AlertCircle,
} from "lucide-react";

const UrlAnalyzerPage: React.FC = () => {
  const { isDark } = useTheme();
  const { data, isLoading, error, analyzeUrl, reset } = useUrlAnalyzer();
  const [url, setUrl] = useState("");

  // Helper to normalize URL for submission with smart protocol and www handling
  function normalizeUrl(input: string): string {
    let trimmed = input.trim();

    if (trimmed.length === 0) return "";

    // If already has protocol, return as is
    if (/^https?:\/\//i.test(trimmed)) {
      return trimmed;
    }

    // If starts with www., just add https://
    if (trimmed.startsWith("www.")) {
      return `https://${trimmed}`;
    }

    // For plain domain names, add https://www.
    // First ensure it doesn't already have www.
    if (!trimmed.startsWith("www.")) {
      return `https://www.${trimmed}`;
    }

    // Fallback - just add https://
    return `https://${trimmed}`;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      analyzeUrl(normalizeUrl(url));
    }
  };

  const handleReset = () => {
    setUrl("");
    reset();
  };

  return (
    <div
      className={`min-h-screen p-4 md:p-6 relative overflow-hidden ${
        isDark
          ? "bg-gradient-to-t from-gray-900 via-purple-900 to-black"
          : "bg-gradient-to-t from-orange-100 via-red-100 to-orange-100"
      }`}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-indigo-400/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div>
              <h1
                className={`text-4xl md:text-5xl font-bold mb-2 py-4 bg-gradient-to-r ${
                  isDark
                    ? "from-white via-blue-100 to-purple-100"
                    : "from-gray-900 via-blue-800 to-purple-800"
                } bg-clip-text text-transparent`}
              >
                URL Analyzer
              </h1>
            </div>
          </div>
          <div
            className={`text-xl md:text-2xl leading-relaxed max-w-3xl mx-auto ${
              isDark ? "text-gray-300" : "text-gray-600"
            }`}
          >
            <ReactMarkdown>
              {`Transform any website into actionable business intelligence for your campaigns`}
            </ReactMarkdown>
          </div>
        </div>

        {/* URL Input Form */}
        <div className="mb-8 animate-slide-up">
          <div
            className={`rounded-2xl shadow-2xl backdrop-blur-xl border p-8 transform hover:scale-[1.02] transition-all duration-300 ${
              isDark
                ? "bg-gray-800/80 border-gray-700/50 shadow-purple-500/10"
                : "bg-white/90 border-gray-200/50 shadow-blue-500/10"
            }`}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label
                  className={`block text-lg font-semibold mb-3 ${
                    isDark ? "text-gray-200" : "text-gray-800"
                  }`}
                >
                  Enter Website URL
                </label>
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1 relative group">
                    <div
                      className={`absolute left-4 top-1/2 transform -translate-y-1/2 transition-colors ${
                        isDark
                          ? "text-gray-400 group-focus-within:text-blue-400"
                          : "text-gray-500 group-focus-within:text-blue-500"
                      }`}
                    >
                      <Globe className="w-6 h-6" />
                    </div>
                    <input
                      type="text"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      placeholder="https://www.example.com"
                      className={`w-full pl-12 pr-6 py-4 text-lg rounded-xl border-2 transition-all duration-300 ${
                        isDark
                          ? "bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500 focus:bg-gray-700/70"
                          : "bg-gray-50/50 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-blue-500 focus:bg-white"
                      } focus:outline-none focus:ring-4 focus:ring-blue-500/20 focus:shadow-lg`}
                      disabled={isLoading}
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={!url.trim() || isLoading}
                    className={`px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 active:scale-95 shadow-lg hover:shadow-xl cursor-pointer ${
                      !url.trim() || isLoading
                        ? "bg-gray-400 cursor-not-allowed"
                        : "bg-amber-700 text-white shadow-blue-500/25"
                    } flex items-center justify-center gap-3 min-w-[160px]`}
                  >
                    {isLoading ? (
                      <>
                        <LoadingSpinner size="sm" />
                        <span>Analyzing...</span>
                      </>
                    ) : (
                      <>
                        <Search className="w-6 h-6" />
                        <span>Analyze</span>
                        <ArrowRight className="w-5 h-5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>

            {error && (
              <div className="mt-6 p-4 rounded-xl border-l-4 border-red-500 bg-red-50/50 backdrop-blur-sm animate-slide-in">
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                  <div
                    className={`text-sm font-medium ${
                      isDark ? "text-red-300" : "text-red-700"
                    }`}
                  >
                    <ReactMarkdown>{error}</ReactMarkdown>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="animate-fade-in ">
            <div
              className={` rounded-2xl shadow-2xl backdrop-blur-xl border p-12 text-center transform hover:scale-[1.02] transition-all duration-300  ${
                isDark
                  ? "bg-gray-800/80 border-gray-700/50 shadow-purple-500/10"
                  : "bg-white/90 border-gray-200/50 shadow-blue-500/10"
              }`}
            >
              <div className="mb-6">
                <LoadingSpinner size="xl" text="Analyzing website..." />
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce delay-200"></div>
                </div>
                <p
                  className={`text-lg font-medium ${
                    isDark ? "text-gray-300" : "text-gray-600"
                  }`}
                >
                  Extracting business intelligence...
                </p>
                <p
                  className={`text-sm ${
                    isDark ? "text-gray-400" : "text-gray-500"
                  }`}
                >
                  This usually takes 5-10 seconds
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Results */}
        {data && !isLoading && (
          <div className="animate-slide-up space-y-6">
            {/* Header Card */}
            <div
              className={`rounded-2xl shadow-2xl backdrop-blur-xl border overflow-hidden transform hover:scale-[1.01] transition-all duration-300 ${
                isDark
                  ? "bg-gray-800/80 border-gray-700/50 shadow-purple-500/10"
                  : "bg-white/90 border-gray-200/50 shadow-blue-500/10"
              }`}
            >
              <div
                className={`p-8 border-b ${
                  isDark ? "border-gray-700/50" : "border-gray-200/50"
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <CheckCircle className="w-8 h-8 text-green-500" />
                      <h2
                        className={`text-3xl font-bold ${
                          isDark ? "text-white" : "text-gray-900"
                        }`}
                      >
                        {data.name}
                      </h2>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 mb-4">
                      <span
                        className={`px-4 py-2 rounded-full text-sm font-semibold shadow-lg ${
                          isDark
                            ? "bg-gradient-to-r from-blue-600/20 to-purple-600/20 text-blue-300 border border-blue-500/30"
                            : "bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 border border-blue-300/50"
                        }`}
                      >
                        {data.type}
                      </span>
                      <div
                        className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${
                          isDark
                            ? "bg-gray-700/50 text-gray-300 border border-gray-600/50"
                            : "bg-gray-100/50 text-gray-600 border border-gray-300/50"
                        }`}
                      >
                        <Building className="w-4 h-4" />
                        {data.industry}
                      </div>
                    </div>
                    <p
                      className={`text-sm ${
                        isDark ? "text-gray-400" : "text-gray-500"
                      }`}
                    >
                      Analysis completed • {new Date().toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <a
                      href={data.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`p-3 rounded-xl transition-all duration-300 transform hover:scale-110 shadow-lg hover:shadow-xl ${
                        isDark
                          ? "bg-gray-700/50 text-gray-300 hover:text-white hover:bg-gray-600 border border-gray-600/50"
                          : "bg-gray-100/50 text-gray-600 hover:text-gray-900 hover:bg-gray-200 border border-gray-300/50"
                      }`}
                    >
                      <ExternalLink className="w-6 h-6" />
                    </a>
                    <button
                      onClick={handleReset}
                      className={`px-6 py-3 rounded-xl border-2 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-semibold cursor-pointer ${
                        isDark
                          ? "border-gray-600 text-gray-300 hover:bg-gray-700 hover:border-gray-500"
                          : "border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400"
                      }`}
                    >
                      Analyze Another
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-8 space-y-8">
                {/* Mission */}
                <div className="group">
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className={`p-2 rounded-lg ${
                        isDark ? "bg-blue-600/20" : "bg-blue-100"
                      }`}
                    >
                      <Target
                        className={`w-6 h-6 ${
                          isDark ? "text-blue-400" : "text-blue-600"
                        }`}
                      />
                    </div>
                    <h3
                      className={`text-xl font-bold ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      Mission Statement
                    </h3>
                  </div>
                  <div
                    className={`p-6 rounded-xl border-l-4 transition-all duration-300 group-hover:shadow-lg ${
                      isDark
                        ? "bg-gray-700/30 border-blue-500 text-gray-300"
                        : "bg-blue-50/50 border-blue-500 text-gray-700"
                    }`}
                  >
                    <div className="leading-relaxed text-lg">
                      <ReactMarkdown>{data.mission}</ReactMarkdown>
                    </div>
                  </div>
                </div>

                {/* Services */}
                {data.services.length > 0 && (
                  <div className="group">
                    <div className="flex items-center gap-3 mb-4">
                      <div
                        className={`p-2 rounded-lg ${
                          isDark ? "bg-green-600/20" : "bg-green-100"
                        }`}
                      >
                        <FileText
                          className={`w-6 h-6 ${
                            isDark ? "text-green-400" : "text-green-600"
                          }`}
                        />
                      </div>
                      <h3
                        className={`text-xl font-bold ${
                          isDark ? "text-white" : "text-gray-900"
                        }`}
                      >
                        Services Offered
                      </h3>
                    </div>
                    <div
                      className={`p-6 rounded-xl transition-all duration-300 group-hover:shadow-lg ${
                        isDark ? "bg-gray-700/30" : "bg-green-50/50"
                      }`}
                    >
                      <div className="grid gap-3">
                        {data.services.map((service, index) => (
                          <div
                            key={index}
                            className={`flex items-start gap-3 p-3 rounded-lg transition-all duration-200 hover:scale-[1.02] ${
                              isDark
                                ? "hover:bg-gray-600/30"
                                : "hover:bg-white/50"
                            }`}
                          >
                            <CheckCircle
                              className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                                isDark ? "text-green-400" : "text-green-600"
                              }`}
                            />
                            <div
                              className={`leading-relaxed ${
                                isDark ? "text-gray-300" : "text-gray-700"
                              }`}
                            >
                              <ReactMarkdown>{service}</ReactMarkdown>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Contact Info */}
                <div className="group">
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className={`p-2 rounded-lg ${
                        isDark ? "bg-purple-600/20" : "bg-purple-100"
                      }`}
                    >
                      <Phone
                        className={`w-6 h-6 ${
                          isDark ? "text-purple-400" : "text-purple-600"
                        }`}
                      />
                    </div>
                    <h3
                      className={`text-xl font-bold ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      Contact Information
                    </h3>
                  </div>
                  <div
                    className={`p-6 rounded-xl border-l-4 transition-all duration-300 group-hover:shadow-lg ${
                      isDark
                        ? "bg-gray-700/30 border-purple-500 text-gray-300"
                        : "bg-purple-50/50 border-purple-500 text-gray-700"
                    }`}
                  >
                    <div className="leading-relaxed text-lg whitespace-pre-line">
                      <ReactMarkdown>{data.contact_info}</ReactMarkdown>
                    </div>
                  </div>
                </div>

                {/* Summary */}
                <div className="group">
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className={`p-2 rounded-lg ${
                        isDark ? "bg-indigo-600/20" : "bg-indigo-100"
                      }`}
                    >
                      <FileText
                        className={`w-6 h-6 ${
                          isDark ? "text-indigo-400" : "text-indigo-600"
                        }`}
                      />
                    </div>
                    <h3
                      className={`text-xl font-bold ${
                        isDark ? "text-white" : "text-gray-900"
                      }`}
                    >
                      Business Summary
                    </h3>
                  </div>
                  <div
                    className={`p-6 rounded-xl transition-all duration-300 group-hover:shadow-lg ${
                      isDark
                        ? "bg-gradient-to-br from-gray-700/30 to-gray-600/30 border border-gray-600/50"
                        : "bg-gradient-to-br from-indigo-50/50 to-purple-50/50 border border-indigo-200/50"
                    }`}
                  >
                    <div
                      className={`leading-relaxed text-lg ${
                        isDark ? "text-gray-300" : "text-gray-700"
                      }`}
                    >
                      <ReactMarkdown>{data.summary_markdown}</ReactMarkdown>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UrlAnalyzerPage;
