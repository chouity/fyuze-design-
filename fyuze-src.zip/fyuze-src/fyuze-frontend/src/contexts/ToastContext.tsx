import { createContext, useContext, useState, useCallback } from "react";
import type { ReactNode } from "react";

export type ToastType = "success" | "error" | "warning" | "info";

export interface Toast {
  id: string;
  message: string;
  type: ToastType;
  duration?: number;
  persistent?: boolean;
}

interface ToastContextValue {
  toasts: Toast[];
  showToast: (
    message: string,
    type: ToastType,
    options?: { duration?: number; persistent?: boolean }
  ) => string;
  hideToast: (id: string) => void;
  clearAllToasts: () => void;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

interface ToastProviderProps {
  children: ReactNode;
  defaultDuration?: number;
}

export function ToastProvider({
  children,
  defaultDuration = 5000,
}: ToastProviderProps) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback(
    (
      message: string,
      type: ToastType,
      options: { duration?: number; persistent?: boolean } = {}
    ): string => {
      console.log("[ToastContext] showToast called with:", {
        message,
        type,
        options,
      });

      const id = `toast-${Date.now()}-${Math.random()
        .toString(36)
        .substr(2, 9)}`;
      const duration = options.duration ?? defaultDuration;

      const newToast: Toast = {
        id,
        message,
        type,
        duration,
        persistent: options.persistent || false,
      };

      setToasts((prev) => [...prev, newToast]);

      // Auto-hide toast after duration (unless persistent)
      if (!options.persistent && duration > 0) {
        setTimeout(() => {
          hideToast(id);
        }, duration);
      }

      return id;
    },
    [defaultDuration]
  );

  const hideToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  }, []);

  const clearAllToasts = useCallback(() => {
    setToasts([]);
  }, []);

  const value: ToastContextValue = {
    toasts,
    showToast,
    hideToast,
    clearAllToasts,
  };

  return (
    <ToastContext.Provider value={value}>{children}</ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);

  if (context === undefined) {
    throw new Error("useToast must be used within a ToastProvider");
  }

  return context;
}

// Convenience hooks for different toast types
export function useToastActions() {
  const { showToast, hideToast, clearAllToasts } = useToast();

  return {
    success: (
      message: string,
      options?: { duration?: number; persistent?: boolean }
    ) => showToast(message, "success", options),
    error: (
      message: string,
      options?: { duration?: number; persistent?: boolean }
    ) => showToast(message, "error", options),
    warning: (
      message: string,
      options?: { duration?: number; persistent?: boolean }
    ) => showToast(message, "warning", options),
    info: (
      message: string,
      options?: { duration?: number; persistent?: boolean }
    ) => showToast(message, "info", options),
    hide: hideToast,
    clearAll: clearAllToasts,
  };
}
