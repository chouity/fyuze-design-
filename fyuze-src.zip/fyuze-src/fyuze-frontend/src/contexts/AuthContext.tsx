import React, {
  createContext,
  useContext,
  useState,
  type ReactNode,
  useEffect,
} from "react";
import { supabase } from "../lib/supabaseClient";

interface User {
  id: string;
  email: string;
  name?: string;
  emailConfirmed?: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string, name: string) => Promise<boolean>;
  logout: () => Promise<void>;
  isLoading: boolean;
  isInitializing: boolean;
  requestPasswordReset: (email: string, redirectTo?: string) => Promise<any>;
  updateUserPassword: (newPassword: string) => Promise<any>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error || !data.user) return false;
      setUser({
        id: data.user.id,
        email: data.user.email || "",
        name:
          data.user.user_metadata?.name || data.user.email?.split("@")[0] || "",
        emailConfirmed: !!data.user.email_confirmed_at,
      });
      return true;
    } catch (error) {
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (
    email: string,
    password: string,
    name: string
  ): Promise<boolean> => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { name } },
      });

      if (error) {
        return false;
      }

      if (!data.user) {
        return false;
      }


      // Check if email confirmation is required
      const emailConfirmed = !!data.user.email_confirmed_at;

      // Only set user if email is confirmed (auto-confirm) or if session is created
      if (emailConfirmed || data.session) {
        setUser({
          id: data.user.id,
          email: data.user.email || "",
          name: name,
          emailConfirmed: emailConfirmed,
        });
      } else {
        // Email confirmation is required, don't set user yet
        // The user will be set when they confirm their email
        setUser(null); // Make sure user is null
      }

      return true;
    } catch (error) {
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };
  const requestPasswordReset = async (email: string, redirectTo?: string) => {
    return supabase.auth.resetPasswordForEmail(email, {
      redirectTo: redirectTo || window.location.origin + "/reset-password",
    });
  };
  const updateUserPassword = async (newPassword: string) => {
    return supabase.auth.updateUser({ password: newPassword });
  };
  useEffect(() => {
    // Check for existing session on mount
    const checkSession = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      const sessionUser = session?.user;
      if (sessionUser) {
        setUser({
          id: sessionUser.id,
          email: sessionUser.email || "",
          name:
            sessionUser.user_metadata?.name ||
            sessionUser.email?.split("@")[0] ||
            "",
          emailConfirmed: !!sessionUser.email_confirmed_at,
        });
      }
      setIsInitializing(false);
    };

    checkSession();

    const { data: listener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        const sessionUser = session?.user;
        if (sessionUser) {
          setUser({
            id: sessionUser.id,
            email: sessionUser.email || "",
            name:
              sessionUser.user_metadata?.name ||
              sessionUser.email?.split("@")[0] ||
              "",
            emailConfirmed: !!sessionUser.email_confirmed_at,
          });
        } else {
          setUser(null);
        }
        setIsInitializing(false);
      }
    );
    return () => {
      listener?.subscription.unsubscribe();
    };
  }, []);

  const value = {
    user,
    login,
    signup,
    logout,
    isLoading,
    isInitializing,
    requestPasswordReset,
    updateUserPassword,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
