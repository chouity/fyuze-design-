import React, {
  createContext,
  useContext,
  useState,
  type ReactNode,
} from "react";

export interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  timestamp: Date;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  updatedAt: Date;
}

interface ChatContextType {
  conversations: Conversation[];
  currentConversationId: string | null;
  currentConversation: Conversation | null;
  createNewConversation: () => string;
  selectConversation: (id: string) => void;
  sendMessage: (content: string) => Promise<void>;
  deleteConversation: (id: string) => void;
  isLoading: boolean;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
};

interface ChatProviderProps {
  children: ReactNode;
}

export const ChatProvider: React.FC<ChatProviderProps> = ({ children }) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<
    string | null
  >(null);
  const [isLoading, setIsLoading] = useState(false);

  const currentConversation =
    conversations.find((c) => c.id === currentConversationId) || null;

  const createNewConversation = (): string => {
    const newId = Date.now().toString();
    const newConversation: Conversation = {
      id: newId,
      title: "New Chat",
      messages: [],
      updatedAt: new Date(),
    };

    setConversations((prev) => [newConversation, ...prev]);
    setCurrentConversationId(newId);
    return newId;
  };

  const selectConversation = (id: string) => {
    setCurrentConversationId(id);
  };

  const generateTitle = (firstMessage: string): string => {
    const words = firstMessage.split(" ").slice(0, 5);
    return words.join(" ") + (firstMessage.split(" ").length > 5 ? "..." : "");
  };

  const sendMessage = async (content: string): Promise<void> => {
    if (!currentConversationId) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: "user",
      timestamp: new Date(),
    };

    // Add user message
    setConversations((prev) =>
      prev.map((conv) => {
        if (conv.id === currentConversationId) {
          const updatedMessages = [...conv.messages, userMessage];
          const title =
            conv.messages.length === 0 ? generateTitle(content) : conv.title;
          return {
            ...conv,
            messages: updatedMessages,
            title,
            updatedAt: new Date(),
          };
        }
        return conv;
      })
    );

    setIsLoading(true);

    try {
      // Simulate AI response
      await new Promise((resolve) =>
        setTimeout(resolve, 1000 + Math.random() * 2000)
      );

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: generateAIResponse(content),
        role: "assistant",
        timestamp: new Date(),
      };

      // Add assistant message
      setConversations((prev) =>
        prev.map((conv) => {
          if (conv.id === currentConversationId) {
            return {
              ...conv,
              messages: [...conv.messages, assistantMessage],
              updatedAt: new Date(),
            };
          }
          return conv;
        })
      );
    } catch (error) {
    } finally {
      setIsLoading(false);
    }
  };

  const deleteConversation = (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (currentConversationId === id) {
      setCurrentConversationId(null);
    }
  };

  // Mock AI response generator
  const generateAIResponse = (userMessage: string): string => {
    const responses = [
      `I understand you're asking about "${userMessage}". That's an interesting question! Let me help you with that.`,
      `Thank you for your message about "${userMessage}". Here's what I think about this topic...`,
      `Great question! Regarding "${userMessage}", I'd like to share some insights with you.`,
      `I see you're interested in "${userMessage}". This is actually a fascinating subject that I'd be happy to explore with you.`,
      `Your question about "${userMessage}" touches on some important concepts. Let me break this down for you.`,
    ];

    return responses[Math.floor(Math.random() * responses.length)];
  };

  const value = {
    conversations,
    currentConversationId,
    currentConversation,
    createNewConversation,
    selectConversation,
    sendMessage,
    deleteConversation,
    isLoading,
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
};
