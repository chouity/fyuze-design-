# ThemeContext Documentation

The ThemeContext provides a robust theming system for your React application with automatic persistence, system preference detection, and utility functions.

## ✅ Features

- **Automatic Persistence**: Theme preference is saved to localStorage
- **System Preference Detection**: Automatically detects user's system dark/light mode preference
- **SSR Safe**: Handles server-side rendering without issues
- **Error Handling**: Graceful fallbacks if localStorage is unavailable
- **Utility Functions**: Helper functions for common theme operations
- **Type Safety**: Full TypeScript support

## 🚀 Basic Usage

### 1. Using the Theme Hook

```tsx
import { useTheme } from "../contexts/ThemeContext";

function MyComponent() {
  const { theme, toggleTheme, isDark, isLight, setTheme } = useTheme();

  return (
    <div
      className={`p-4 ${
        isDark ? "bg-gray-900 text-white" : "bg-white text-gray-900"
      }`}
    >
      <h1>Current theme: {theme}</h1>
      <button onClick={toggleTheme}>
        Switch to {isDark ? "light" : "dark"} mode
      </button>

      {/* Direct theme setting */}
      <button onClick={() => setTheme("dark")}>Force Dark</button>
      <button onClick={() => setTheme("light")}>Force Light</button>
    </div>
  );
}
```

### 2. Using Theme Utilities

```tsx
import { useThemeUtils } from "../contexts/ThemeContext";

function UtilityExample() {
  const { getThemeClass, applyTheme, isDark } = useThemeUtils();

  return (
    <div
      className={getThemeClass(
        "bg-white border-gray-200",
        "bg-gray-800 border-gray-700"
      )}
    >
      <h2 className={getThemeClass("text-gray-900", "text-white")}>
        Utility Example
      </h2>

      {/* Conditional logic */}
      {isDark && <p>Dark mode specific content</p>}

      <button onClick={() => applyTheme("light")}>Switch to Light</button>
    </div>
  );
}
```

## 🎨 Tailwind CSS Integration

The ThemeContext automatically adds/removes the `dark` class to the document root, enabling Tailwind's dark mode:

```tsx
// This will automatically work with the theme
<div className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
  Content that adapts to theme
</div>
```

## ⚙️ Configuration

### Tailwind CSS Setup

Make sure your `tailwind.config.js` has dark mode enabled:

```js
module.exports = {
  darkMode: "class", // Enable class-based dark mode
  // ... rest of your config
};
```

### CSS Variables (Optional)

You can also use CSS custom properties for theming:

```css
:root {
  --color-bg: #ffffff;
  --color-text: #000000;
}

.dark {
  --color-bg: #1a1a1a;
  --color-text: #ffffff;
}

.themed-element {
  background-color: var(--color-bg);
  color: var(--color-text);
}
```

## 🔧 API Reference

### useTheme()

Returns the main theme context with the following properties:

| Property      | Type                     | Description                    |
| ------------- | ------------------------ | ------------------------------ |
| `theme`       | `'light' \| 'dark'`      | Current theme value            |
| `toggleTheme` | `() => void`             | Toggles between light and dark |
| `setTheme`    | `(theme: Theme) => void` | Sets specific theme            |
| `isDark`      | `boolean`                | True if current theme is dark  |
| `isLight`     | `boolean`                | True if current theme is light |

### useThemeUtils()

Returns utility functions for theme operations:

| Property        | Type                                      | Description                    |
| --------------- | ----------------------------------------- | ------------------------------ |
| `theme`         | `'light' \| 'dark'`                       | Current theme value            |
| `isDark`        | `boolean`                                 | True if current theme is dark  |
| `isLight`       | `boolean`                                 | True if current theme is light |
| `applyTheme`    | `(theme: Theme) => void`                  | Apply specific theme           |
| `getThemeClass` | `(light: string, dark: string) => string` | Get class based on theme       |

## 🎯 Advanced Usage

### Theme-aware Components

```tsx
import { useTheme } from "../contexts/ThemeContext";

function ThemeAwareIcon() {
  const { isDark } = useTheme();

  return isDark ? <MoonIcon /> : <SunIcon />;
}
```

### Conditional Rendering

```tsx
function ConditionalContent() {
  const { isDark } = useTheme();

  return (
    <div>
      {isDark ? <DarkModeSpecificComponent /> : <LightModeSpecificComponent />}
    </div>
  );
}
```

### Custom Theme Logic

```tsx
function CustomThemeLogic() {
  const { theme, setTheme } = useTheme();

  const handleSystemSync = () => {
    const systemPrefersDark = window.matchMedia(
      "(prefers-color-scheme: dark)"
    ).matches;
    setTheme(systemPrefersDark ? "dark" : "light");
  };

  return (
    <button onClick={handleSystemSync}>Sync with System Preference</button>
  );
}
```

## 🛠️ Troubleshooting

### Common Issues

1. **Theme not persisting**: Check if localStorage is available in your environment
2. **Flashing on page load**: This is normal and minimal due to SSR safety measures
3. **Styles not updating**: Ensure Tailwind's dark mode is configured correctly

### Error Handling

The ThemeContext includes built-in error handling:

- Graceful fallback if localStorage fails
- Console warnings for debugging
- SSR-safe initialization

### Browser Support

- **localStorage**: Required for persistence (fallback: session-only themes)
- **matchMedia**: Required for system preference detection (fallback: manual only)
- **classList**: Required for DOM manipulation (universal support)

## 📱 Examples in Your App

Your app already uses the ThemeContext in:

1. **AuthPage**: Theme toggle button
2. **App**: Theme provider wrapper
3. **All components**: Automatic dark/light mode styles

The ThemeContext is production-ready and handles all edge cases!
