# Updated Creator Data Parser Usage

## Single File Solution

The `useCreatorsParsing.ts` now handles both data sources:

### 1. AI Search Data (with platform_data array)

```typescript
// AI search response structure:
const aiSearchResponse = {
  platform_data: [
    {
      id: "123",
      username: "creator1",
      platform_data: {
        /* rich Instagram data */
      },
      // ... other fields
    },
  ],
};

// Parse AI search data
const creators = CreatorDataParser.parseCreatorData(
  aiSearchResponse,
  "ai_search"
);
```

### 2. Get Creators Data (with data.rows)

```typescript
// Get creators response structure:
const getCreatorsResponse = {
  data: {
    rows: [
      {
        id: "123",
        username: "creator1",
        platform_data: "{ /* JSON string */ }",
        // ... other fields
      },
    ],
  },
};

// Parse get creators data
const creators = CreatorDataParser.parseCreatorData(
  getCreatorsResponse,
  "get_creators"
);
```

### 3. Auto-Detection (Recommended)

```typescript
// Parser auto-detects the data source
const creators = CreatorDataParser.parseCreatorData(apiResponse);
```

## Enhanced Creator Structure

Each creator now has:

```typescript
interface EnhancedCreator {
  // Table-compatible fields
  id: string;
  name: string;
  username: string;
  platform: string;
  followers: number;
  engagement_rate: string;
  // ... other basic fields

  // Rich profile data (same as CreatorProfilePage)
  profileData: {
    // Basic info
    id: string;
    username: string;
    fullName: string;
    bio?: string;
    profilePicUrl?: string;

    // Social metrics
    followers: number;
    following: number;
    postsCount: number;

    // Verification
    isVerified: boolean;
    isBusinessAccount?: boolean;

    // Links and contact
    links: string[];
    contactEmail?: string;

    // Posts with captions, images, videos
    posts: InstagramPost[];

    // Business info
    businessCategory?: string;
    highlightReelCount?: number;

    // ... all the rich data
  };

  dataSource: "ai_search" | "get_creators";
  rawData: any;
}
```

## Usage Examples

### In Table Components

```typescript
const creators = CreatorDataParser.parseCreatorData(apiResponse);

// Use directly in table - all required fields are present
<CreatorTable creators={creators} />;
```

### In Profile Page

```typescript
const creator = CreatorDataParser.getCreatorById(creators, id);

// Access rich data
const profileData = creator.profileData;
const posts = profileData.posts;
const engagement = CreatorDataParser.calculateEngagementMetrics(creator);
```

### Calculate Metrics

```typescript
const engagement = CreatorDataParser.calculateEngagementMetrics(creator);
// Returns: { averageLikes: 1234.56, averageComments: 67.89, engagementRate: 3.45, totalPosts: 25 }

const hashtags = CreatorDataParser.extractHashtags(creator);
// Returns: ["#fashion", "#lifestyle", "#ootd"]
```

## Key Benefits

1. **Single Source of Truth** - One file handles all creator data processing
2. **Unified Interface** - Same structure for AI search and get_creators
3. **Rich Data Extraction** - All the comprehensive data from CreatorProfilePage
4. **Table Compatible** - Works with existing table components
5. **Auto-Detection** - Automatically detects data source format
6. **Type Safe** - Full TypeScript support with proper interfaces

## Migration

Replace this:

```typescript
// OLD - Multiple files
import { useCreatorDataNormalization } from "./useCreatorDataNormalization";
import { CreatorDataParser } from "./useCreatorsParsing";

const { normalizedCreators } = useCreatorDataNormalization({
  creators,
  dataSource,
});
```

With this:

```typescript
// NEW - Single file
import { CreatorDataParser } from "./useCreatorsParsing";

const creators = CreatorDataParser.parseCreatorData(apiResponse);
```
