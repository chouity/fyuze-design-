# Fyuze Creator Platform - Dynamic Multi-Platform Architecture

## 🚀 Project Overview

Fyuze is a modern React-based creator discovery and analytics platform that dynamically handles multiple social media platforms through a sophisticated abstraction layer. The platform enables seamless integration of new social media platforms while maintaining clean, reusable code.

### 🎯 Key Features

- **Dynamic Platform Support**: Easily extensible architecture for Instagram, TikTok, and future platforms
- **Platform Abstraction Layer**: Unified data processing across different social media APIs
- **Component-Based Architecture**: Reusable UI components that work across all platforms
- **AI-Powered Search**: Advanced creator discovery using natural language processing
- **Real-time Analytics**: Engagement metrics and performance insights
- **Clean Code Architecture**: Modular, maintainable, and scalable codebase

## 🏗️ Architecture Overview

### Platform Abstraction System

The core innovation of this project is the platform abstraction layer that enables dynamic handling of different social media platforms:

```
┌─────────────────────────────────────────────────────────────┐
│                     UI Components Layer                     │
├─────────────────────────────────────────────────────────────┤
│                   Platform Service Layer                    │
├─────────────────────────────────────────────────────────────┤
│              Platform Adapters (Instagram, TikTok)          │
├─────────────────────────────────────────────────────────────┤
│                   Data Sources Layer                        │
└─────────────────────────────────────────────────────────────┘
```

### Directory Structure

```
src/
├── components/           # Reusable UI components
│   ├── profile/         # Creator profile components
│   ├── dashboard/       # Dashboard components
│   ├── creators/        # Creator search components
│   └── common/          # Shared components
├── services/            # Platform abstraction services
│   ├── PlatformService.ts
│   └── adapters/        # Platform-specific adapters
├── types/               # TypeScript type definitions
│   └── platform.types.ts
├── hooks/               # Custom React hooks
├── pages/               # Main application pages
├── config/              # Platform configurations
└── utils/               # Utility functions
```

## 🔧 Platform Abstraction Layer

### Core Types

```typescript
// Platform-agnostic creator profile
interface PlatformCreatorProfile {
  id: string;
  username: string;
  displayName: string;
  platform: PlatformType;
  bio: string;
  avatarUrl: string;
  isVerified: boolean;
  followers: number;
  following: number;
  postsCount: number;
  engagementRate: number;
  posts: PlatformPost[];
  // ... additional fields
}

// Unified post structure
interface PlatformPost {
  id: string;
  caption: string;
  thumbnail: string;
  likes: number;
  comments: number;
  views?: number;
  type: "image" | "video" | "carousel";
  platform: PlatformType;
}
```

### Platform Service

The `PlatformService` is the central orchestrator that manages platform-specific operations:

```typescript
class PlatformService {
  // Detect platform from raw data
  detectPlatform(data: any): PlatformType | null;

  // Extract creator profile using appropriate adapter
  extractCreatorProfile(
    rawData: any,
    platform: PlatformType,
    dataSource: DataSourceType
  ): PlatformDataExtractionResult;

  // Process multiple creators
  processCreators(data: any[]): PlatformCreatorProfile[];
}
```

### Platform Adapters

Each platform has its own adapter that implements the `PlatformAdapter` interface:

```typescript
interface PlatformAdapter {
  platform: PlatformType;
  extractProfile(rawData: any, dataSource: string): PlatformCreatorProfile;
  extractPosts(rawData: any): PlatformPost[];
  normalizeEngagementRate(rate: any): number;
  validateData(data: any): boolean;
}
```

#### Instagram Adapter

- Handles Instagram-specific field mappings
- Normalizes follower counts and engagement rates
- Extracts image/video posts and carousel data

#### TikTok Adapter

- Processes TikTok video-centric data structure
- Handles view counts and video-specific metrics
- Normalizes TikTok engagement calculations

## 🧩 Component Architecture

### Profile Components

**ProfileHeader**

- Platform-agnostic creator header
- Displays avatar, verification badge, contact info
- Handles platform-specific styling

**ProfileStats**

- Unified metrics display (followers, engagement, posts)
- Number formatting utilities
- Responsive grid layout

**ProfilePosts**

- Platform-agnostic posts grid
- Supports images, videos, and carousels
- Hover interactions and engagement display

**ProfileInsights**

- Advanced analytics and performance metrics
- Best-performing content identification
- Platform-specific engagement calculations

### Dashboard Components

**DashboardHeader**

- AI search integration
- Platform selection and filtering
- Results mode switching

**DashboardFilters**

- Advanced creator filtering options
- Platform-specific filter handling
- Real-time search with debouncing

**DashboardResults**

- Unified creator results display
- Table and card view modes
- Pagination and sorting

**AISearchModal**

- Natural language creator search
- Platform-specific AI queries
- Interactive search parameters

## 📊 Data Flow

### Creator Profile Flow

```
Raw Data → Platform Detection → Adapter Selection → Data Extraction → UI Components
```

1. **Data Source**: Database, API endpoint, or AI search
2. **Platform Detection**: Automatic platform identification
3. **Adapter Processing**: Platform-specific data extraction
4. **Component Rendering**: Unified UI display

### Dashboard Flow

```
Search Query → Data Fetching → Platform Processing → Results Display
```

1. **User Input**: Search terms, filters, AI queries
2. **Data Retrieval**: Supabase queries or AI search
3. **Platform Abstraction**: Unified data processing
4. **Results Rendering**: Table/card views with pagination

## 🚀 Getting Started

### Prerequisites

- Node.js 18+
- npm or yarn
- Supabase account and configuration
- Environment variables setup

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd fyuze-frontend

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your Supabase credentials

# Start development server
npm run dev
```

### Environment Variables

```env
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
```

### Database Setup

For regenerating the database types:

```bash
npx supabase gen types typescript --project-id "uvkmqudmpsvalegqlqod" --schema public > database.types.ts
```

## 🔌 Adding New Platforms

The platform abstraction layer makes adding new social media platforms straightforward:

### Step 1: Create Platform Adapter

```typescript
// src/services/adapters/YouTubeAdapter.ts
export class YouTubeAdapter implements PlatformAdapter {
  platform: PlatformType = "youtube";

  extractProfile(rawData: any, dataSource: string): PlatformCreatorProfile {
    return {
      id: rawData.channel_id,
      username: rawData.username,
      displayName: rawData.channel_name,
      platform: "youtube",
      // ... YouTube-specific field mappings
    };
  }

  extractPosts(rawData: any): PlatformPost[] {
    // YouTube video extraction logic
  }

  normalizeEngagementRate(rate: any): number {
    // YouTube engagement calculation
  }

  validateData(data: any): boolean {
    // YouTube data validation
  }
}
```

### Step 2: Register Adapter

```typescript
// src/services/PlatformService.ts
private initializeAdapters(): void {
  this.adapters.set('instagram', new InstagramAdapter());
  this.adapters.set('tiktok', new TikTokAdapter());
  this.adapters.set('youtube', new YouTubeAdapter()); // Add here
}
```

### Step 3: Update Types

```typescript
// src/types/platform.types.ts
export type PlatformType = "instagram" | "tiktok" | "youtube";
```

### Step 4: Add Platform Configuration

```typescript
// src/config/platforms.ts
export const platformConfig = {
  youtube: {
    name: "YouTube",
    icon: "youtube",
    color: "#FF0000",
    gradient: "from-red-500 to-red-600",
  },
};
```

## 🛠️ Development Guidelines

### Code Standards

- TypeScript strict mode
- ESLint configuration with React rules
- Prettier code formatting
- Consistent naming conventions

### Component Guidelines

- Platform-agnostic design
- Reusable and composable
- Proper prop typing
- Performance optimization

### Platform Adapter Guidelines

- Implement full PlatformAdapter interface
- Handle edge cases gracefully
- Provide comprehensive data validation
- Maintain consistent data structures

## 🚀 Deployment

### Build Process

```bash
# Production build
npm run build

# Preview build locally
npm run preview

# Lint and type checking
npm run lint
npm run type-check
```

## 🎉 Success Metrics

This refactoring has achieved:

- **90% Code Reduction**: Creator profile page reduced from 2092 to 280 lines
- **Platform Extensibility**: New platforms can be added in ~100 lines of code
- **Component Reusability**: UI components work across all platforms
- **Maintainability**: Clean separation of concerns and modular architecture
- **Type Safety**: Comprehensive TypeScript coverage
- **Performance**: Optimized rendering and data processing

The platform abstraction layer provides a solid foundation for scaling to any number of social media platforms while maintaining clean, maintainable code.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.
