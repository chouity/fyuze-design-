export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      admin_recommendations: {
        Row: {
          admin_id: string | null
          categories: string[] | null
          created_at: string | null
          creator_id: string | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          priority_score: number | null
          reason: string | null
          recommendation_type: string
          updated_at: string | null
        }
        Insert: {
          admin_id?: string | null
          categories?: string[] | null
          created_at?: string | null
          creator_id?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          priority_score?: number | null
          reason?: string | null
          recommendation_type: string
          updated_at?: string | null
        }
        Update: {
          admin_id?: string | null
          categories?: string[] | null
          created_at?: string | null
          creator_id?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          priority_score?: number | null
          reason?: string | null
          recommendation_type?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_recommendations_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_recommendations_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "creators"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_endpoints: {
        Row: {
          cost_points: number
          created_at: string
          description: string | null
          endpoint_key: string
          endpoint_url: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          cost_points: number
          created_at?: string
          description?: string | null
          endpoint_key: string
          endpoint_url?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          cost_points?: number
          created_at?: string
          description?: string | null
          endpoint_key?: string
          endpoint_url?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      ai_queries: {
        Row: {
          created_at: string | null
          id: string
          query_text: string
          response_text: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          query_text: string
          response_text?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          query_text?: string
          response_text?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ai_queries_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      campaign_applications: {
        Row: {
          campaign_id: string | null
          creator_id: string | null
          deliverables: Json | null
          id: string
          message: string | null
          proposed_rate: number | null
          status: string | null
          submitted_at: string | null
          timeline: Json | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          campaign_id?: string | null
          creator_id?: string | null
          deliverables?: Json | null
          id?: string
          message?: string | null
          proposed_rate?: number | null
          status?: string | null
          submitted_at?: string | null
          timeline?: Json | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          campaign_id?: string | null
          creator_id?: string | null
          deliverables?: Json | null
          id?: string
          message?: string | null
          proposed_rate?: number | null
          status?: string | null
          submitted_at?: string | null
          timeline?: Json | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "campaign_applications_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaign_applications_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "creators"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "campaign_applications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      campaigns: {
        Row: {
          applications_count: number | null
          brand: string | null
          budget: number | null
          budget_per_creator: number | null
          category: string | null
          created_at: string | null
          creator_count: number | null
          deliverables: string[] | null
          description: string | null
          id: string
          metrics: Json | null
          name: string
          platforms: string[] | null
          requirements: Json | null
          status: string | null
          target_audience: Json | null
          timeline: Json | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          applications_count?: number | null
          brand?: string | null
          budget?: number | null
          budget_per_creator?: number | null
          category?: string | null
          created_at?: string | null
          creator_count?: number | null
          deliverables?: string[] | null
          description?: string | null
          id?: string
          metrics?: Json | null
          name: string
          platforms?: string[] | null
          requirements?: Json | null
          status?: string | null
          target_audience?: Json | null
          timeline?: Json | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          applications_count?: number | null
          brand?: string | null
          budget?: number | null
          budget_per_creator?: number | null
          category?: string | null
          created_at?: string | null
          creator_count?: number | null
          deliverables?: string[] | null
          description?: string | null
          id?: string
          metrics?: Json | null
          name?: string
          platforms?: string[] | null
          requirements?: Json | null
          status?: string | null
          target_audience?: Json | null
          timeline?: Json | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "campaigns_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      contact_messages: {
        Row: {
          created_at: string | null
          email: string | null
          first_name: string
          id: string
          last_name: string
          message: string
          status: Database["public"]["Enums"]["contact_message_status"]
          subject: string
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          email?: string | null
          first_name: string
          id?: string
          last_name: string
          message: string
          status?: Database["public"]["Enums"]["contact_message_status"]
          subject: string
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string | null
          first_name?: string
          id?: string
          last_name?: string
          message?: string
          status?: Database["public"]["Enums"]["contact_message_status"]
          subject?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_contact_user"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          campaign_id: string | null
          created_at: string | null
          creator_id: string | null
          id: string
          last_message_at: string | null
          status: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          campaign_id?: string | null
          created_at?: string | null
          creator_id?: string | null
          id?: string
          last_message_at?: string | null
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          campaign_id?: string | null
          created_at?: string | null
          creator_id?: string | null
          id?: string
          last_message_at?: string | null
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "conversations_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversations_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "creators"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversations_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      countries: {
        Row: {
          created_at: string | null
          id: string
          level: string
          name: string
          parent_id: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          level: string
          name: string
          parent_id?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          level?: string
          name?: string
          parent_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "countries_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "countries"
            referencedColumns: ["id"]
          },
        ]
      }
      creator_promotions: {
        Row: {
          amount_paid: number
          created_at: string | null
          creator_id: string | null
          expires_at: string | null
          id: string
          package_id: string | null
          payment_status: string | null
          performance_metrics: Json | null
          placement_score: number | null
          starts_at: string | null
          status: string | null
          target_categories: string[] | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          amount_paid: number
          created_at?: string | null
          creator_id?: string | null
          expires_at?: string | null
          id?: string
          package_id?: string | null
          payment_status?: string | null
          performance_metrics?: Json | null
          placement_score?: number | null
          starts_at?: string | null
          status?: string | null
          target_categories?: string[] | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          amount_paid?: number
          created_at?: string | null
          creator_id?: string | null
          expires_at?: string | null
          id?: string
          package_id?: string | null
          payment_status?: string | null
          performance_metrics?: Json | null
          placement_score?: number | null
          starts_at?: string | null
          status?: string | null
          target_categories?: string[] | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "creator_promotions_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "creators"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creator_promotions_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "promotional_packages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creator_promotions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      creator_search_logs: {
        Row: {
          creator_name: string
          id: string
          platform: string
          searched_at: string | null
          user_id: string | null
        }
        Insert: {
          creator_name: string
          id?: string
          platform: string
          searched_at?: string | null
          user_id?: string | null
        }
        Update: {
          creator_name?: string
          id?: string
          platform?: string
          searched_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "creator_search_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      creator_views: {
        Row: {
          action: string
          creator_id: string | null
          id: string
          user_id: string | null
          viewed_at: string | null
        }
        Insert: {
          action: string
          creator_id?: string | null
          id?: string
          user_id?: string | null
          viewed_at?: string | null
        }
        Update: {
          action?: string
          creator_id?: string | null
          id?: string
          user_id?: string | null
          viewed_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "creator_views_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "creators"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creator_views_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      creators: {
        Row: {
          audience_demographics: Json | null
          avatar_url: string | null
          bio: string | null
          category: string | null
          contact_email: string | null
          content_categories: string[] | null
          created_at: string | null
          engagement_rate: number | null
          followers: number | null
          id: string
          is_active: boolean | null
          languages: string[] | null
          location: string | null
          match_reason: string | null
          match_score: number | null
          name: string
          platform: string
          platform_data: Json | null
          rate_per_post: number | null
          rate_per_reel: number | null
          rate_per_story: number | null
          recent_posts: Json | null
          scraped_at: string | null
          updated_at: string | null
          username: string
          verified: boolean | null
        }
        Insert: {
          audience_demographics?: Json | null
          avatar_url?: string | null
          bio?: string | null
          category?: string | null
          contact_email?: string | null
          content_categories?: string[] | null
          created_at?: string | null
          engagement_rate?: number | null
          followers?: number | null
          id: string
          is_active?: boolean | null
          languages?: string[] | null
          location?: string | null
          match_reason?: string | null
          match_score?: number | null
          name: string
          platform: string
          platform_data?: Json | null
          rate_per_post?: number | null
          rate_per_reel?: number | null
          rate_per_story?: number | null
          recent_posts?: Json | null
          scraped_at?: string | null
          updated_at?: string | null
          username: string
          verified?: boolean | null
        }
        Update: {
          audience_demographics?: Json | null
          avatar_url?: string | null
          bio?: string | null
          category?: string | null
          contact_email?: string | null
          content_categories?: string[] | null
          created_at?: string | null
          engagement_rate?: number | null
          followers?: number | null
          id?: string
          is_active?: boolean | null
          languages?: string[] | null
          location?: string | null
          match_reason?: string | null
          match_score?: number | null
          name?: string
          platform?: string
          platform_data?: Json | null
          rate_per_post?: number | null
          rate_per_reel?: number | null
          rate_per_story?: number | null
          recent_posts?: Json | null
          scraped_at?: string | null
          updated_at?: string | null
          username?: string
          verified?: boolean | null
        }
        Relationships: []
      }
      media_mentions: {
        Row: {
          collected_at: string | null
          context: string | null
          creator_id: string | null
          id: string
          keyword: string
          mention_type: string
          mentioned_at: string | null
          platform: string
        }
        Insert: {
          collected_at?: string | null
          context?: string | null
          creator_id?: string | null
          id?: string
          keyword: string
          mention_type: string
          mentioned_at?: string | null
          platform: string
        }
        Update: {
          collected_at?: string | null
          context?: string | null
          creator_id?: string | null
          id?: string
          keyword?: string
          mention_type?: string
          mentioned_at?: string | null
          platform?: string
        }
        Relationships: [
          {
            foreignKeyName: "media_mentions_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "creators"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          attachments: Json | null
          content: string
          conversation_id: string | null
          created_at: string | null
          id: string
          message_type: string | null
          read_at: string | null
          recipient_id: string | null
          recipient_type: string
          sender_id: string | null
          sender_type: string
          sent_at: string | null
        }
        Insert: {
          attachments?: Json | null
          content: string
          conversation_id?: string | null
          created_at?: string | null
          id?: string
          message_type?: string | null
          read_at?: string | null
          recipient_id?: string | null
          recipient_type: string
          sender_id?: string | null
          sender_type: string
          sent_at?: string | null
        }
        Update: {
          attachments?: Json | null
          content?: string
          conversation_id?: string | null
          created_at?: string | null
          id?: string
          message_type?: string | null
          read_at?: string | null
          recipient_id?: string | null
          recipient_type?: string
          sender_id?: string | null
          sender_type?: string
          sent_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      point_ledger: {
        Row: {
          delta: number
          id: number
          meta: Json
          occurred_at: string
          reason: string
          reference_id: string | null
          reference_type: string | null
          user_id: string
        }
        Insert: {
          delta: number
          id?: number
          meta?: Json
          occurred_at?: string
          reason: string
          reference_id?: string | null
          reference_type?: string | null
          user_id: string
        }
        Update: {
          delta?: number
          id?: number
          meta?: Json
          occurred_at?: string
          reason?: string
          reference_id?: string | null
          reference_type?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "point_ledger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      promotional_analytics: {
        Row: {
          clicks: number | null
          conversions: number | null
          created_at: string | null
          date: string
          id: string
          promotion_id: string | null
          revenue: number | null
          views: number | null
        }
        Insert: {
          clicks?: number | null
          conversions?: number | null
          created_at?: string | null
          date: string
          id?: string
          promotion_id?: string | null
          revenue?: number | null
          views?: number | null
        }
        Update: {
          clicks?: number | null
          conversions?: number | null
          created_at?: string | null
          date?: string
          id?: string
          promotion_id?: string | null
          revenue?: number | null
          views?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "promotional_analytics_promotion_id_fkey"
            columns: ["promotion_id"]
            isOneToOne: false
            referencedRelation: "creator_promotions"
            referencedColumns: ["id"]
          },
        ]
      }
      promotional_packages: {
        Row: {
          analytics_included: boolean | null
          category_targeting: boolean | null
          created_at: string | null
          description: string | null
          duration_days: number
          features: Json | null
          highlighted: boolean | null
          id: string
          is_active: boolean | null
          name: string
          placement_boost: number | null
          price: number
          priority_support: boolean | null
          updated_at: string | null
        }
        Insert: {
          analytics_included?: boolean | null
          category_targeting?: boolean | null
          created_at?: string | null
          description?: string | null
          duration_days: number
          features?: Json | null
          highlighted?: boolean | null
          id?: string
          is_active?: boolean | null
          name: string
          placement_boost?: number | null
          price: number
          priority_support?: boolean | null
          updated_at?: string | null
        }
        Update: {
          analytics_included?: boolean | null
          category_targeting?: boolean | null
          created_at?: string | null
          description?: string | null
          duration_days?: number
          features?: Json | null
          highlighted?: boolean | null
          id?: string
          is_active?: boolean | null
          name?: string
          placement_boost?: number | null
          price?: number
          priority_support?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      saved_creators: {
        Row: {
          creator_id: string | null
          id: string
          notes: string | null
          saved_at: string | null
          tags: string[] | null
          user_id: string | null
        }
        Insert: {
          creator_id?: string | null
          id?: string
          notes?: string | null
          saved_at?: string | null
          tags?: string[] | null
          user_id?: string | null
        }
        Update: {
          creator_id?: string | null
          id?: string
          notes?: string | null
          saved_at?: string | null
          tags?: string[] | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "saved_creators_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "creators"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "saved_creators_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_search_filters: {
        Row: {
          created_at: string | null
          filters: Json
          id: string
          name: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          filters: Json
          id?: string
          name: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          filters?: Json
          id?: string
          name?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "saved_search_filters_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          billing_cycle: string
          code: string
          created_at: string
          currency: string
          description: string | null
          duration_months: number | null
          features: Json
          id: string
          is_active: boolean
          monthly_points: number | null
          name: string
          price: number
          updated_at: string
        }
        Insert: {
          billing_cycle?: string
          code: string
          created_at?: string
          currency?: string
          description?: string | null
          duration_months?: number | null
          features?: Json
          id?: string
          is_active?: boolean
          monthly_points?: number | null
          name: string
          price?: number
          updated_at?: string
        }
        Update: {
          billing_cycle?: string
          code?: string
          created_at?: string
          currency?: string
          description?: string | null
          duration_months?: number | null
          features?: Json
          id?: string
          is_active?: boolean
          monthly_points?: number | null
          name?: string
          price?: number
          updated_at?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          auto_renew: boolean
          created_at: string
          end_date: string | null
          external_ref: string | null
          id: string
          payment_metadata: Json
          plan_id: string
          start_date: string
          status: string
          trial_ends_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          auto_renew?: boolean
          created_at?: string
          end_date?: string | null
          external_ref?: string | null
          id?: string
          payment_metadata?: Json
          plan_id: string
          start_date?: string
          status?: string
          trial_ends_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          auto_renew?: boolean
          created_at?: string
          end_date?: string | null
          external_ref?: string | null
          id?: string
          payment_metadata?: Json
          plan_id?: string
          start_date?: string
          status?: string
          trial_ends_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      user_points: {
        Row: {
          balance: number
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_points_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      user_sessions: {
        Row: {
          created_at: string
          session_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          session_id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          session_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_sessions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      users: {
        Row: {
          admin_level: string | null
          avatar_url: string | null
          bio: string | null
          company_name: string | null
          created_at: string | null
          credits: number | null
          email: string
          full_name: string | null
          id: string
          industry: string | null
          is_admin: boolean | null
          last_active_at: string | null
          location: string | null
          notification_settings: Json | null
          onboarding_completed: boolean | null
          phone: string | null
          preferences: Json | null
          subscription_expires_at: string | null
          subscription_status: string | null
          subscription_tier: string | null
          timezone: string | null
          updated_at: string | null
          website: string | null
        }
        Insert: {
          admin_level?: string | null
          avatar_url?: string | null
          bio?: string | null
          company_name?: string | null
          created_at?: string | null
          credits?: number | null
          email: string
          full_name?: string | null
          id: string
          industry?: string | null
          is_admin?: boolean | null
          last_active_at?: string | null
          location?: string | null
          notification_settings?: Json | null
          onboarding_completed?: boolean | null
          phone?: string | null
          preferences?: Json | null
          subscription_expires_at?: string | null
          subscription_status?: string | null
          subscription_tier?: string | null
          timezone?: string | null
          updated_at?: string | null
          website?: string | null
        }
        Update: {
          admin_level?: string | null
          avatar_url?: string | null
          bio?: string | null
          company_name?: string | null
          created_at?: string | null
          credits?: number | null
          email?: string
          full_name?: string | null
          id?: string
          industry?: string | null
          is_admin?: boolean | null
          last_active_at?: string | null
          location?: string | null
          notification_settings?: Json | null
          onboarding_completed?: boolean | null
          phone?: string | null
          preferences?: Json | null
          subscription_expires_at?: string | null
          subscription_status?: string | null
          subscription_tier?: string | null
          timezone?: string | null
          updated_at?: string | null
          website?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      v_user_active_subscription: {
        Row: {
          end_date: string | null
          plan_code: string | null
          status: string | null
          user_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      add_admin_recommendations: {
        Args: { payload: Json }
        Returns: Json
      }
      add_campaign_applications: {
        Args: { payload: Json }
        Returns: Json
      }
      add_campaigns: {
        Args: { payload: Json }
        Returns: Json
      }
      add_contact_message: {
        Args: { payload: Json }
        Returns: Json
      }
      add_conversations: {
        Args: { payload: Json }
        Returns: Json
      }
      add_creator_promotions: {
        Args: { payload: Json }
        Returns: Json
      }
      add_creator_search_logs: {
        Args: { payload: Json }
        Returns: Json
      }
      add_creator_views: {
        Args: { payload: Json }
        Returns: Json
      }
      add_creators: {
        Args: { payload: Json }
        Returns: Json
      }
      add_media_mentions: {
        Args: { payload: Json }
        Returns: Json
      }
      add_messages: {
        Args: { payload: Json }
        Returns: Json
      }
      add_promotional_analytics: {
        Args: { payload: Json }
        Returns: Json
      }
      add_promotional_packages: {
        Args: { payload: Json }
        Returns: Json
      }
      add_saved_creators: {
        Args: { payload: Json }
        Returns: Json
      }
      add_saved_search_filters: {
        Args: { payload: Json }
        Returns: Json
      }
      add_subscription: {
        Args: { payload: Json }
        Returns: Json
      }
      add_subscription_plan: {
        Args: { payload: Json }
        Returns: Json
      }
      auto_update_creator_from_platform_data: {
        Args: { p_id?: string }
        Returns: undefined
      }
      bulk_upsert_creators: {
        Args: { p_payload: Json }
        Returns: Json
      }
      choose_subscription_plan: {
        Args: { p_plan_code?: string }
        Returns: Json
      }
      create_user_session: {
        Args: { payload?: Json }
        Returns: string
      }
      delete_contact_message: {
        Args: { payload: Json }
        Returns: Json
      }
      error_response: {
        Args: { code?: number; message: string }
        Returns: Json
      }
      expire_old_subscriptions: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      get_admin_recommendations: {
        Args: { payload: Json }
        Returns: Json
      }
      get_ai_queries: {
        Args: { payload: Json }
        Returns: Json
      }
      get_campaign_applications: {
        Args: { payload: Json }
        Returns: Json
      }
      get_campaigns: {
        Args: { payload: Json }
        Returns: Json
      }
      get_contact_messages: {
        Args: { payload: Json }
        Returns: Json
      }
      get_conversations: {
        Args: { payload: Json }
        Returns: Json
      }
      get_country_city_pairs: {
        Args: { payload: Json }
        Returns: Json
      }
      get_creator_categories: {
        Args: { payload?: Json }
        Returns: Json
      }
      get_creator_platforms: {
        Args: { payload?: Json }
        Returns: Json
      }
      get_creator_promotions: {
        Args: { payload: Json }
        Returns: Json
      }
      get_creator_search_logs: {
        Args: { payload: Json }
        Returns: Json
      }
      get_creator_views: {
        Args: { payload: Json }
        Returns: Json
      }
      get_creators: {
        Args: { payload: Json }
        Returns: Json
      }
      get_creators_by_usernames_platforms: {
        Args: { payload: Json }
        Returns: Json
      }
      get_current_subscription: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      get_locations: {
        Args: { payload: Json }
        Returns: Json
      }
      get_media_mentions: {
        Args: { payload: Json }
        Returns: Json
      }
      get_messages: {
        Args: { payload: Json }
        Returns: Json
      }
      get_promotional_analytics: {
        Args: { payload: Json }
        Returns: Json
      }
      get_promotional_packages: {
        Args: { payload: Json }
        Returns: Json
      }
      get_recent_platform_data: {
        Args: { p_input: Json }
        Returns: Json
      }
      get_saved_creators: {
        Args: { payload: Json }
        Returns: Json
      }
      get_saved_search_filters: {
        Args: { payload: Json }
        Returns: Json
      }
      get_subscription_plans: {
        Args: { input_json: Json }
        Returns: Json
      }
      get_subscriptions: {
        Args: { payload: Json }
        Returns: Json
      }
      insert_creator_from_payload: {
        Args:
          | {
              p_audience_demo?: Json
              p_avatar_url?: string
              p_bio?: string
              p_category?: string
              p_contact_email?: string
              p_content_categories?: string[]
              p_engagement_rate?: number
              p_followers?: number
              p_is_active?: boolean
              p_languages?: string[]
              p_location?: string
              p_match_reason?: string
              p_match_score?: number
              p_name?: string
              p_platform: string
              p_platform_data?: Json
              p_rate_per_post?: number
              p_rate_per_reel?: number
              p_rate_per_story?: number
              p_recent_posts?: Json
              p_scraped_at?: string
              p_username: string
              p_verified?: boolean
            }
          | { p_data: Json; p_platform: string; p_username: string }
        Returns: Json
      }
      search_contact_messages: {
        Args: { payload: Json }
        Returns: Json
      }
      success_response: {
        Args: { data?: Json; message: string }
        Returns: Json
      }
      update_contact_message_status: {
        Args: { payload: Json }
        Returns: Json
      }
    }
    Enums: {
      contact_message_status: "readed" | "unreaded" | "archived" | "deleted"
      platforms: "instagram" | "tiktok" | "youtube" | "facebook" | "twitter"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      contact_message_status: ["readed", "unreaded", "archived", "deleted"],
      platforms: ["instagram", "tiktok", "youtube", "facebook", "twitter"],
    },
  },
} as const
