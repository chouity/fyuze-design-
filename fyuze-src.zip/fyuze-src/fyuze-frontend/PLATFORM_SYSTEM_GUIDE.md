# Dynamic Platform System Documentation

## Overview

The Fyuze application now features a comprehensive dynamic platform system that makes it easy to add support for new social media platforms like X (Twitter), YouTube, Snapchat, Pinterest, and more. This system automatically handles platform detection, field mapping, data extraction, and UI rendering.

## Architecture

### Core Components

1. **Platform Configuration System** (`src/config/platforms.ts`)

   - Central configuration for all supported platforms
   - Defines field mappings, detection rules, visual settings
   - Type-safe platform definitions

2. **Dynamic Data Extractor** (`src/utils/platformDataExtractor.ts`)

   - Automatic platform detection from raw data
   - Dynamic field extraction based on platform configs
   - Unified data structure output

3. **Enhanced Parsing Hook** (`src/hooks/useCreatorsParsing.ts`)
   - React hook that uses the dynamic system
   - Backward compatibility with existing components
   - Source-aware data processing

## Currently Supported Platforms

- **Instagram** - Full support with rich data extraction
- **TikTok** - Full support with platform-specific fields
- **YouTube** - Configuration ready, field mapping implemented
- **Twitter/X** - Complete configuration and field mapping
- **Facebook** - Basic configuration with field mapping
- **LinkedIn** - Professional platform support
- **Snapchat** - Visual platform configuration
- **Pinterest** - Content discovery platform support
- **Twitch** - Live streaming platform support

## How to Add a New Platform

### Step 1: Add Platform Configuration

Edit `src/config/platforms.ts` and add your platform to the `PLATFORM_CONFIGS` object:

```typescript
// Example: Adding Discord platform
discord: {
  id: 'discord',
  name: 'Discord',
  displayName: 'Discord',

  // Visual configuration
  visual: {
    icon: faDiscord,
    primaryColor: '#7289da',
    backgroundColor: '#36393f',
    textColor: '#ffffff'
  },

  // Field mapping - map platform-specific fields to our unified structure
  fieldMapping: {
    id: ['user_id', 'discord_id', 'id'],
    username: ['username', 'discriminator', 'tag'],
    displayName: ['display_name', 'global_name', 'username'],
    bio: ['bio', 'about_me', 'status'],
    followers: ['followers_count', 'friend_count'],
    following: ['following_count', 'guild_count'],
    posts: ['message_count', 'post_count'],
    avatar: ['avatar_url', 'avatar'],
    verified: ['verified', 'premium', 'nitro'],

    // Platform-specific fields
    platformSpecific: {
      discriminator: ['discriminator'],
      guilds: ['guild_count', 'server_count'],
      badges: ['badges', 'user_flags'],
      premium: ['premium', 'nitro']
    }
  },

  // Detection rules - how to identify this platform from data
  detectionRules: {
    explicitIdentifiers: ['discord'],
    uniqueFields: ['discriminator', 'guild_count', 'nitro'],
    requiredFields: ['username']
  },

  // API endpoints (if applicable)
  endpoints: {
    profile: 'https://discord.com/api/users/{username}',
    posts: 'https://discord.com/api/users/{username}/messages'
  }
}
```

### Step 2: Add Platform Type

Update the `PlatformType` union in the same file:

```typescript
export type PlatformType =
  | "instagram"
  | "tiktok"
  | "youtube"
  | "twitter"
  | "x"
  | "facebook"
  | "linkedin"
  | "snapchat"
  | "pinterest"
  | "twitch"
  | "discord"; // Add your new platform here
```

### Step 3: Add FontAwesome Icon (Optional)

If you want a custom icon, import it in the platforms file:

```typescript
import {
  faInstagram,
  faYoutube,
  faTiktok,
  faTwitter,
  faFacebookF,
  faLinkedin,
  faSnapchat,
  faPinterest,
  faTwitch,
  faDiscord, // Add your icon import
} from "@fortawesome/free-brands-svg-icons";
```

### Step 4: Test Platform Detection

The system will automatically:

- Detect the platform from incoming data
- Extract fields using your mapping configuration
- Render the appropriate icon and colors
- Generate the correct profile URL

## Field Mapping Guide

### Core Fields (Required)

- **id**: Platform-specific user identifier
- **username**: Handle/username (@username)
- **displayName**: Full display name
- **bio**: Profile bio/description
- **followers**: Follower count
- **following**: Following count
- **posts**: Post/content count
- **avatar**: Profile picture URL
- **verified**: Verification status

### Platform-Specific Fields (Optional)

Use the `platformSpecific` object to map unique fields for your platform:

```typescript
platformSpecific: {
  custom_field: ['platform_specific_name', 'alternative_name'],
  special_metric: ['unique_metric_name']
}
```

## Detection Rules

### Explicit Identifiers

Platform names that directly identify the platform:

```typescript
explicitIdentifiers: ["discord", "Discord", "DISCORD"];
```

### Unique Fields

Fields that are unique to this platform:

```typescript
uniqueFields: ["discriminator", "guild_count", "nitro"];
```

### Required Fields

Fields that must be present for this platform:

```typescript
requiredFields: ["username", "discriminator"];
```

## Data Source Compatibility

The system works with multiple data sources:

### AI Search Results

```typescript
// Automatic detection and processing
const creators = parseCreatorData(aiSearchResponse, "ai_search");
```

### Database Queries

```typescript
// Handle database response format
const creators = parseCreatorData(databaseResponse, "get_creators");
```

### Direct API Endpoints

```typescript
// Process individual creator objects
const creators = parseCreatorData(creatorObject, "endpoint");
```

## Testing Your Platform

### 1. Add Test Data

Create test data that includes your platform's unique fields:

```typescript
const testDiscordCreator = {
  platform: "discord",
  username: "testuser",
  discriminator: "1234",
  display_name: "Test User",
  guild_count: 15,
  nitro: true,
};
```

### 2. Test Detection

```typescript
import { PlatformDetector } from "../utils/platformDataExtractor";

const detection = PlatformDetector.detectPlatform(testDiscordCreator);
console.log("Detected platform:", detection.platform); // Should be 'discord'
console.log("Confidence:", detection.confidence); // Should be high (0.8+)
```

### 3. Test Extraction

```typescript
import { PlatformDataExtractor } from "../utils/platformDataExtractor";

const extracted = PlatformDataExtractor.extractCreatorData(
  testDiscordCreator,
  "discord",
  "test"
);
console.log("Extracted data:", extracted);
```

## Advanced Configuration

### Custom Field Processors

For complex data transformation, you can extend the extractor:

```typescript
// In platformDataExtractor.ts, add custom processing
private static processDiscordSpecific(data: any): any {
  // Custom logic for Discord-specific data transformation
  if (data.discriminator) {
    data.fullTag = `${data.username}#${data.discriminator}`;
  }
  return data;
}
```

### Custom Icon Rendering

For platforms without FontAwesome icons:

```typescript
// In platforms.ts
visual: {
  icon: null, // No FontAwesome icon
  customIcon: '/assets/icons/custom-platform.svg',
  primaryColor: '#custom-color'
}
```

## Migration from Legacy System

### Before (Old System)

```typescript
// Hard-coded platform detection
if (creator.platform === "instagram") {
  // Instagram-specific logic
} else if (creator.platform === "tiktok") {
  // TikTok-specific logic
}
```

### After (Dynamic System)

```typescript
// Automatic platform handling
const creators = processCreatorsWithDetection(rawData, dataSource);
// All platforms handled automatically
```

## Performance Considerations

- **Caching**: Platform configurations are loaded once at startup
- **Detection**: Platform detection is optimized with early returns
- **Field Mapping**: Uses efficient object property access
- **Memory**: Minimal overhead, configurations stored as constants

## Troubleshooting

### Platform Not Detected

1. Check if platform name is in `explicitIdentifiers`
2. Verify `uniqueFields` are present in your data
3. Ensure field mapping covers the available data fields

### Wrong Field Values

1. Check field mapping array order (first match wins)
2. Verify data structure matches expected format
3. Add console logging to trace field extraction

### Missing Icons

1. Ensure FontAwesome icon is imported
2. Check visual configuration in platform config
3. Verify icon name matches FontAwesome export

## Future Enhancements

- **Dynamic Icon Loading**: Support for custom platform icons
- **Field Validation**: Automatic validation of extracted data
- **Platform Analytics**: Usage statistics per platform
- **Custom Renderers**: Platform-specific UI components

## Example: Complete Platform Addition

Here's a complete example of adding Reddit support:

```typescript
// 1. Add to PLATFORM_CONFIGS
reddit: {
  id: 'reddit',
  name: 'Reddit',
  displayName: 'Reddit',
  visual: {
    icon: faReddit,
    primaryColor: '#ff4500',
    backgroundColor: '#ffffff',
    textColor: '#1a1a1a'
  },
  fieldMapping: {
    id: ['user_id', 'id'],
    username: ['username', 'name'],
    displayName: ['display_name', 'username'],
    bio: ['public_description', 'description'],
    followers: ['subscribers', 'follower_count'],
    following: ['friends', 'following_count'],
    posts: ['link_karma', 'comment_karma', 'total_karma'],
    avatar: ['icon_img', 'avatar_url'],
    verified: ['is_verified', 'verified'],
    platformSpecific: {
      karma: ['link_karma', 'comment_karma'],
      cakeDay: ['created_utc'],
      gold: ['is_gold', 'premium']
    }
  },
  detectionRules: {
    explicitIdentifiers: ['reddit'],
    uniqueFields: ['link_karma', 'comment_karma', 'created_utc'],
    requiredFields: ['username']
  },
  endpoints: {
    profile: 'https://reddit.com/user/{username}/about.json'
  }
}

// 2. Add to PlatformType
export type PlatformType = '...' | 'reddit';

// 3. Import icon
import { faReddit } from '@fortawesome/free-brands-svg-icons';
```

That's it! The system will automatically handle Reddit creators with no additional code changes needed.

## Support

For questions or issues with the platform system:

1. Check this documentation first
2. Review existing platform configurations for examples
3. Test with small data samples before full implementation
4. Use console logging to debug detection and extraction
