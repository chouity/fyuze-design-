/// <reference types="vitest" />
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 3000,
    open: true,
    host: true,
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          // Vendor chunk for large libraries
          vendor: ["react", "react-dom", "react-router-dom"],
          // UI libraries chunk
          ui: [
            "lucide-react",
            "@fortawesome/react-fontawesome",
            "@fortawesome/fontawesome-svg-core",
          ],
          // Data fetching chunk
          query: ["@tanstack/react-query", "@tanstack/react-query-devtools"],
          // Supabase chunk
          supabase: ["@supabase/supabase-js"],
          // Admin features chunk
          admin: ["react-datepicker"],
        },
      },
    },
    chunkSizeWarningLimit: 600,
  },
  test: {
    globals: true, // lets you use `describe`, `it`, `expect` without importing
    environment: "jsdom", // simulate browser
    setupFiles: "./src/setupTests.ts", // setup file (like jest setup)
  },
});
