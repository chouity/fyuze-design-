from src.shared.enums.platform import Platform


__all__ = ["Platform"]
