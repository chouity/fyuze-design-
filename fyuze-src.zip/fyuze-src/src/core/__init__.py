"""Core functionality module."""
